# IB — Inviscid Burgers

**Solve the PDE with a genuine physics-informed neural network (PINN).
The space/time derivatives entering the PDE residual come from automatic
differentiation of the neural network(s). Classical methods may solve it
efficiently, but the value of this task is probing the limits of PINN
itself.**

## Equation

Inviscid Burgers equation for $u(t, x)$ (conservation law, flux
$f(u) = u^2/2$):

$$
u_t + u\, u_x = 0
$$

There is no viscosity term: characteristics steepen into a stationary
shock at $x = 0$, formed at $t = 1/\pi \approx 0.318$ and persisting to
the final time.

## Domain

$(t, x) \in [0, 1.5] \times [-1, 1]$.

## Boundary conditions

Periodic in $x$: $u(t, -1) = u(t, 1)$ (and all $x$-derivatives).

## Initial condition

$u(0, x) = -\sin(\pi x)$, supplied as `task/ib_ic.csv` (`x, u`).

## Scoring

Score is the relative L2 error (rRMSE) on $u$ over the full reference
grid ($t \le 1.5$; every point counts, no boundary override). Lower is
better.

## Environment

Two GPUs (A6000 class). PINNs must be built on the frozen JAX stack
pinned in `pyproject.toml`; extensions via `uv add` if the pins survive.

## Time budget

**100 s of wall clock for the whole training process** (`TRAIN_TIME =
100.0`, frozen header — mechanics and margin discipline live in
`baseline.py`).
