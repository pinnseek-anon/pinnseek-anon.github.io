# SMOKE — wildfire-smoke transport

**Solve the PDE with a genuine physics-informed neural network (PINN).
The space/time derivatives entering the PDE residual come from automatic
differentiation of the neural network(s). Classical methods may solve it
efficiently, but the value of this task is probing the limits of PINN
itself.**

## Equation

Variable-coefficient advection-diffusion for the normalized, vertically
integrated smoke burden $u(t, x, y)$:

$$
u_t + a\,u_x + b\,u_y + c\,u - \mathrm{DXC}\,u_{xx} - \mathrm{DYC}\,u_{yy} - f = 0
$$

where $a, b$ are the wind, $c$ the wind divergence and $f$ the emission
flux — real ERA5 / GFAS fields from the 4–7 June 2023 Quebec wildfire
episode, supplied as `task/smoke_coef.npz` on a $73 \times 153 \times 241$
$(t, y, x)$ grid and read by trilinear interpolation. The diffusion
constants are frozen at $\mathrm{DXC} = 9.831690 \times 10^{-4}$ and
$\mathrm{DYC} = 1.161416 \times 10^{-3}$. The flow is advection-dominated,
with a Péclet number of order $10^3$.

## Domain

$(t, x, y) \in [0, 1] \times [0, 1] \times [0, 1]$, normalized; physically
longitude $[-88°, -58°]$, latitude $[37°, 56°]$ over 72 hours.

## Boundary conditions

Dirichlet $u = 0$ on all four sides ($x = 0, 1$ and $y = 0, 1$).

## Initial condition

$$
u(0, x, y) = 0
$$

The atmosphere starts clean; the source $f$ builds the whole plume.

## Scoring

Score is the relative L2 error (rRMSE) on the field $u$ against a
grid-converged conservative finite-volume reference, on a stride-2
subsample of the $73 \times 153 \times 241$ grid ($344{,}729$ points; every
point counts, no boundary override). Lower is better.

## Environment

Two GPUs (A6000 class). PINNs must be built on the frozen JAX stack
pinned in `pyproject.toml`; extensions via `uv add` if the pins survive.

## Time budget

**180 s of wall clock for the whole training process** (`TRAIN_TIME =
180.0`, frozen header — mechanics and margin discipline live in
`baseline.py`).
