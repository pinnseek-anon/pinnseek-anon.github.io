# Generalization cases of BFS

The 4 new cases of BFS in Fig. 2 of the paper, one folder per case.

| File | Content |
|---|---|
| `problem.md` | problem statement of the case |
| `meta.json` | notes on the case and its reference solution |
| `ref_data.csv` | reference solution |
| `scorer.py` | `score(predict_fn, params)` returns the relative L2 error of a trained solver |
| `solver_retrained.py` | discovered solver of BFS with the problem definition changed to the case ("Retrained from scratch" in Fig. 2) |
| `solver_retrained.diff` | that change |

Cases: bfs_Re100, bfs_Re200, bfs_Re400, bfs_Re600.
