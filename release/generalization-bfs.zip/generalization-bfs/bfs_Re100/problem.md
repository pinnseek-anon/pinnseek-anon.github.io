# BFS — Backward-Facing Step

**Solve the PDE with a genuine physics-informed neural network (PINN).
The space/time derivatives entering the PDE residual come from automatic
differentiation of the neural network(s). Classical methods may solve it
efficiently, but the value of this task is probing the limits of PINN
itself.**

## Equation

2D steady incompressible Navier-Stokes for $u(x, y)$, $v(x, y)$, $p(x, y)$:

$$
\begin{aligned}
u \, u_x + v \, u_y + p_x - \nu (u_{xx} + u_{yy}) &= 0 \\
u \, v_x + v \, v_y + p_y - \nu (v_{xx} + v_{yy}) &= 0 \\
u_x + v_y &= 0
\end{aligned}
$$

where $u, v$ are the velocity components and $p$ the pressure (all
dimensionless), with $\nu = 1/\text{Re}$, $\text{Re} = 100$
($\nu = 0.01$), based on the channel height and the mean
inlet velocity.

## Domain

Channel downstream of the step: $(x, y) \in [0, 15] \times [-0.5, 0.5]$.
The step face is the lower half of the inlet plane ($x = 0$, $y \le 0$),
where the inflow profile vanishes; the expansion ratio is 2.

## Boundary conditions

| Boundary | $u$ | $v$ | $p$ |
|---|---|---|---|
| Inlet ($x = 0$) | $24 y (0.5 - y)$ for $y > 0$, else $0$ | $0$ | — |
| Top wall ($y = 0.5$) | $0$ | $0$ | — |
| Bottom wall ($y = -0.5$) | $0$ | $0$ | — |
| Outlet ($x = 15$) | — | — | $0$ |

## Initial condition

None (steady-state problem; no time variable).

## Scoring

Score is the relative L2 error (rRMSE) on the velocity field $[u; v]$
over the full reference grid (every point counts, no boundary override).
Lower is better.

## Environment

Two GPUs (A6000 class). PINNs must be built on the frozen JAX stack
pinned in `pyproject.toml`; extensions via `uv add` if the pins survive.

## Time budget

**180 s of wall clock for the whole training process** (`TRAIN_TIME =
180.0`, frozen header — mechanics and margin discipline live in
`baseline.py`).
