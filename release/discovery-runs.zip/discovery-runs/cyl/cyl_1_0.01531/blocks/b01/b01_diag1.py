"""Diagnostic: is the vortex street alive, and how big is the residual really?

For each trained candidate: (a) IC fit at t=0, (b) fluctuation about the time
mean over the scored region (x <= 1.7), (c) the rms magnitude of every
individual momentum term so the residual can be read as a *relative* error,
and (d) a velocity probe time series at (x, y) = (0.5, 0.205) — a live von
Karman street must oscillate there at ~3 Hz (St ~ 0.3, U ~ 1, D = 0.1).
"""
from __future__ import annotations

import pickle
import sys
import types
from pathlib import Path

import jax
import jax.numpy as jnp
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
CYL_X, CYL_Y, CYL_R, NU = 0.2, 0.2, 0.05, 1.0e-3
Y_MAX = 0.41
STEMS = ("b01_tm3", "b01_tm5")


def load(stem):
    code = (ROOT / "blocks/b01" / f"{stem}.py").read_text()
    mod = types.ModuleType("_c_" + stem)
    sys.modules["_c_" + stem] = mod
    exec(compile(code, stem, "exec"), mod.__dict__)
    with open(ROOT / "blocks/b01" / f"{stem}.pkl", "rb") as f:
        params = pickle.load(f)
    net = lambda Z: jnp.stack([mod.predict_fn(params, Z)[k] for k in "uvp"], -1)
    return mod, params, net


def main():
    ic = np.loadtxt(ROOT / "task/cyl_ic.csv", delimiter=",", skiprows=1)
    x_ic, y_ic, u_ic, v_ic = ic[:, 0], ic[:, 1], ic[:, 2], ic[:, 3]
    P_ic = jnp.array(np.stack([np.zeros_like(x_ic), x_ic, y_ic], 1), jnp.float32)

    xs = np.linspace(0.0, 1.7, 341)
    ys = np.linspace(0.0, 0.41, 83)
    X, Y = np.meshgrid(xs, ys, indexing="ij")
    fluid = (X - CYL_X) ** 2 + (Y - CYL_Y) ** 2 > CYL_R ** 2
    xg, yg = X[fluid], Y[fluid]
    ts = np.linspace(0.0, 1.2, 25)

    for stem in STEMS:
        mod, params, net = load(stem)

        pr = mod.predict_fn(params, P_ic)
        du = np.asarray(pr["u"]) - u_ic
        dv = np.asarray(pr["v"]) - v_ic
        ic_rel = float(np.linalg.norm(np.concatenate([du, dv]))
                       / np.linalg.norm(np.concatenate([u_ic, v_ic])))

        def stats(Z):
            ex = jnp.broadcast_to(jnp.array([0.0, 1.0, 0.0]), Z.shape)
            ey = jnp.broadcast_to(jnp.array([0.0, 0.0, 1.0]), Z.shape)
            et = jnp.broadcast_to(jnp.array([1.0, 0.0, 0.0]), Z.shape)
            fx = lambda W: jax.jvp(net, (W,), (ex,))
            (val, dx), (_, dxx) = jax.jvp(fx, (Z,), (ex,))
            fy = lambda W: jax.jvp(net, (W,), (ey,))
            (_, dy), (_, dyy) = jax.jvp(fy, (Z,), (ey,))
            _, dt = jax.jvp(net, (Z,), (et,))
            u, v = val[:, 0], val[:, 1]
            acc = dt[:, 0]
            conv = u * dx[:, 0] + v * dy[:, 0]
            visc = NU * (dxx[:, 0] + dyy[:, 0])
            div = dx[:, 0] + dy[:, 1]
            rmx = acc + conv + dx[:, 2] - visc
            rmy = (dt[:, 1] + u * dx[:, 1] + v * dy[:, 1] + dy[:, 2]
                   - NU * (dxx[:, 1] + dyy[:, 1]))
            rms = lambda a: jnp.sqrt(jnp.mean(a ** 2))
            return (val[:, :2], rms(div), rms(jnp.sqrt(rmx ** 2 + rmy ** 2)),
                    rms(acc), rms(conv), rms(dx[:, 2]), rms(visc))

        js = jax.jit(stats)
        F, D, R, A, C, G, Vi = [], [], [], [], [], [], []
        for t in ts:
            Z = jnp.array(np.stack([np.full_like(xg, t), xg, yg], 1), jnp.float32)
            f, d, r, a, c, g, vi = js(Z)
            F.append(np.asarray(f))
            for lst, s in ((D, d), (R, r), (A, a), (C, c), (G, g), (Vi, vi)):
                lst.append(float(s))
        F = np.stack(F)
        mean = F.mean(0, keepdims=True)
        rms_tot = float(np.sqrt((F ** 2).mean()))
        fluct = float(np.sqrt(((F - mean) ** 2).mean()) / (rms_tot + 1e-12))

        probe = np.stack([ts, np.full_like(ts, 0.5), np.full_like(ts, 0.205)], 1)
        pv = np.asarray(net(jnp.array(probe, jnp.float32)))

        print(f"\n=== {stem} ===  IC rel-L2 {ic_rel:.4f}   "
              f"fluct ratio {fluct:.4f} (truth 0.284)")
        print(f"  term rms: |u_t| {np.mean(A):.3f}  |u.grad u| {np.mean(C):.3f}"
              f"  |p_x| {np.mean(G):.3f}  |nu.lap u| {np.mean(Vi):.4f}"
              f"  -> |res| {np.mean(R):.3f}  |div| {np.mean(D):.3f}")
        print("  probe v(t) at (0.5, 0.205), t = 0 .. 1.2:")
        print("   " + " ".join(f"{pv[i,1]:+.2f}" for i in range(25)))
        print("  probe u(t):")
        print("   " + " ".join(f"{pv[i,0]:+.2f}" for i in range(25)))


if __name__ == "__main__":
    main()
