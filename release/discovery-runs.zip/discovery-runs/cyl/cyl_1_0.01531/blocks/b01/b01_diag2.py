"""Truth-free wake-phase diagnostic.

The IC snapshot is the truth at t = 0 and the flow is quasi-periodic with a
shedding period P ~ 0.48 s (the IC's own street wavelength is 0.46 m at a
convection speed ~1.0). So the correlation between a candidate's *fluctuation*
field at time t and the t = 0 fluctuation is a truth-free measure of wake phase
fidelity: a correct solver must show corr(t) dipping negative near t = P/2 and
recovering to a large positive value near t = P.

Fluctuations are taken about the candidate's own time mean over [0, 1.2],
restricted to fluid points with x <= 1.7 (the scored region). The IC grid and
the diagnostic grid share the same 0.005 spacing, so no interpolation is used.
"""
from __future__ import annotations

import pickle
import sys
import types
from pathlib import Path

import jax.numpy as jnp
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
CYL_X, CYL_Y, CYL_R = 0.2, 0.2, 0.05
STEMS = ("b01_tm6", "b01_tm8")


def load(stem):
    code = (ROOT / "blocks/b01" / f"{stem}.py").read_text()
    mod = types.ModuleType("_d_" + stem)
    sys.modules["_d_" + stem] = mod
    exec(compile(code, stem, "exec"), mod.__dict__)
    with open(ROOT / "blocks/b01" / f"{stem}.pkl", "rb") as f:
        params = pickle.load(f)
    return mod, params


def main():
    ic = np.loadtxt(ROOT / "task/cyl_ic.csv", delimiter=",", skiprows=1)
    ix = np.rint(ic[:, 0] / 0.005).astype(int)
    iy = np.rint(ic[:, 1] / 0.005).astype(int)
    keep = ix <= 340                                    # x <= 1.7
    ix, iy = ix[keep], iy[keep]
    xg = ix * 0.005
    yg = iy * 0.005
    uv_ic = np.stack([ic[keep, 2], ic[keep, 3]], 1)     # [N, 2] truth at t=0

    ts = np.linspace(0.0, 1.2, 25)
    P = np.stack([np.repeat(ts, len(xg)),
                  np.tile(xg, len(ts)), np.tile(yg, len(ts))], 1).astype(np.float32)

    for stem in STEMS:
        mod, params = load(stem)
        pr = mod.predict_fn(params, jnp.asarray(P))
        F = np.stack([np.asarray(pr["u"]), np.asarray(pr["v"])], 1)
        F = F.reshape(len(ts), len(xg), 2)

        M = F.mean(0)                                   # candidate time mean
        f_mod = F - M[None]
        f_ic = uv_ic - M                                # IC fluctuation, same mean
        n_ic = np.linalg.norm(f_ic)
        corr = np.array([float(np.sum(f_mod[i] * f_ic)
                               / (np.linalg.norm(f_mod[i]) * n_ic + 1e-12))
                         for i in range(len(ts))])
        amp = np.array([float(np.linalg.norm(f_mod[i]) / n_ic) for i in range(len(ts))])

        # IC-fit at t=0 over this same region, for scale
        e0 = float(np.linalg.norm(F[0] - uv_ic) / np.linalg.norm(uv_ic))
        print(f"\n=== {stem} ===  rel err vs truth at t=0: {e0:.4f}")
        print("  t     : " + " ".join(f"{t:5.2f}" for t in ts[::2]))
        print("  corr  : " + " ".join(f"{c:+5.2f}" for c in corr[::2]))
        print("  |f|/|f0|: " + " ".join(f"{a:5.2f}" for a in amp[::2]))


if __name__ == "__main__":
    main()
