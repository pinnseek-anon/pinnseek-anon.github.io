"""Diagnostic: how much of b03_dens's gradient budget goes to the soft handoff,
and how big the seam error actually is.

Per segment k of the champion pickle:
  * seam jump  ||u_k(t_k) - u_{k-1}(t_k)|| relative to the field's own
    fluctuation rms  -> how well the soft IC (W_IC = 350) is actually met;
  * the converged loss split  l_pde  vs  W_IC * l_ic  vs  W_OUT * l_out
    -> which term owns the gradient at the end of a segment;
  * l_ic split into the scored/trained box x <= X_OUT and the untrained
    tail x > X_OUT (the IC point set still spans the full channel);
  * rms momentum + continuity residual on the training sampler.
"""
from __future__ import annotations

import sys
import types
import pickle
from pathlib import Path

import numpy as np
import jax
import jax.numpy as jnp
from jax import random

ROOT = Path.cwd()
P = lambda *a: print(*a, flush=True)


def load(path, name):
    mod = types.ModuleType(name)
    sys.modules[name] = mod
    exec(compile(Path(path).read_text(), f"<{name}>", "exec"), mod.__dict__)
    return mod


C = load(ROOT / "blocks/b03/b03_dens.py", "_champ_")
with open(ROOT / "blocks/b03/b03_dens.pkl", "rb") as f:
    SP = pickle.load(f)                      # list of 12 param pytrees

SEG, N_SEG, NU = C.SEG, C.N_SEG, C.NU
X_OUT, W_IC, W_OUT, N_IC = C.X_OUT, C.W_IC, C.W_OUT, C.N_IC
net_mod = C.PINN()

xy_ic, uv_ic0 = C._load_ic()
xy_np = np.asarray(xy_ic)
in_box = xy_np[:, 0] <= X_OUT
P(f"IC points: {len(xy_np)} total, {in_box.sum()} with x <= {X_OUT} "
  f"({100 * (1 - in_box.mean()):.1f}% of the IC batch lands in the untrained tail)")


@jax.jit
def field(p, lo, hi, t):
    X = jnp.concatenate([jnp.full((len(xy_ic), 1), t), xy_ic], 1)
    return net_mod.apply(p, X, lo, hi)[:, :2]


@jax.jit
def resid(p, lo, hi, key):
    X, m = C._sample_col(key, lo, hi)
    f = lambda Z: net_mod.apply(p, Z, lo, hi)
    ex = jnp.broadcast_to(jnp.array([0.0, 1.0, 0.0]), X.shape)
    ey = jnp.broadcast_to(jnp.array([0.0, 0.0, 1.0]), X.shape)
    et = jnp.broadcast_to(jnp.array([1.0, 0.0, 0.0]), X.shape)
    fx = lambda Z: jax.jvp(f, (Z,), (ex,))
    (val, dx), (_, dxx) = jax.jvp(fx, (X,), (ex,))
    fy = lambda Z: jax.jvp(f, (Z,), (ey,))
    (_, dy), (_, dyy) = jax.jvp(fy, (X,), (ey,))
    _, dt = jax.jvp(f, (X,), (et,))
    u, v = val[:, 0], val[:, 1]
    r_c = dx[:, 0] + dy[:, 1]
    r_mx = dt[:, 0] + u * dx[:, 0] + v * dy[:, 0] + dx[:, 2] - NU * (dxx[:, 0] + dyy[:, 0])
    r_my = dt[:, 1] + u * dx[:, 1] + v * dy[:, 1] + dy[:, 2] - NU * (dxx[:, 1] + dyy[:, 1])
    w = m / jnp.sum(m)
    l_pde = jnp.sum(w * (r_c ** 2 + r_mx ** 2 + r_my ** 2))
    return (l_pde, jnp.sqrt(jnp.sum(w * r_c ** 2)), jnp.sqrt(jnp.sum(w * r_mx ** 2)),
            jnp.sqrt(jnp.sum(w * r_my ** 2)),
            jnp.sqrt(jnp.sum(w * (dt[:, 0] ** 2))),
            jnp.sqrt(jnp.sum(w * (u * dx[:, 0] + v * dy[:, 0]) ** 2)))


@jax.jit
def outlet_loss(p, lo, hi, key):
    b = C._sample_bc(key, lo, hi)
    return jnp.mean(net_mod.apply(p, b, lo, hi)[:, 2] ** 2)


# time-mean and fluctuation rms of the champion's own field (for scaling)
tavg = np.mean([np.asarray(field(SP[min(int(t / 0.1), N_SEG - 1)],
                                 SEG[min(int(t / 0.1), N_SEG - 1)],
                                 SEG[min(int(t / 0.1), N_SEG - 1) + 1], t))
                for t in np.linspace(0.025, 1.175, 24)], axis=0)

P("\n seg |  seam rms |  rel to fluct |   l_pde   | W_IC*l_ic |  l_ic(in) | l_ic(out) | W*l_out")
P("-" * 96)
key = random.PRNGKey(0)
for k in range(N_SEG):
    lo, hi = SEG[k], SEG[k + 1]
    key, k1, k2 = random.split(key, 3)
    lp, rc, rmx, rmy, rut, radv = [float(z) for z in resid(SP[k], lo, hi, k1)]
    lo_l = float(outlet_loss(SP[k], lo, hi, k2))
    if k == 0:
        tgt = np.asarray(uv_ic0)
    else:
        tgt = np.asarray(field(SP[k - 1], SEG[k - 1], SEG[k], lo))
    got = np.asarray(field(SP[k], lo, hi, lo))
    d2 = (got - tgt) ** 2
    seam = float(np.sqrt(d2[in_box].mean()))
    l_ic_in = float(d2[in_box].sum(1).mean())
    l_ic_out = float(d2[~in_box].sum(1).mean())
    l_ic_all = float(d2.sum(1).mean())
    fl = float(np.sqrt(((np.asarray(field(SP[k], lo, hi, lo)) - tavg)[in_box] ** 2).mean()))
    P(f" {k:3d} | {seam:9.5f} | {seam / max(fl, 1e-9):13.3f} | {lp:9.5f} | "
      f"{W_IC * l_ic_all:9.5f} | {l_ic_in:9.6f} | {l_ic_out:9.6f} | {W_OUT * lo_l:8.5f}")
    P(f"     |  residual rms: r_c {rc:.4f}  r_mx {rmx:.4f}  r_my {rmy:.4f} "
      f"| scale: u_t {rut:.3f} adv {radv:.3f}")
P("\nNote: seam rms is measured on the IC grid at x <= X_OUT; 'rel to fluct' "
  "divides by the rms deviation of that plane from the model's own time mean.")
