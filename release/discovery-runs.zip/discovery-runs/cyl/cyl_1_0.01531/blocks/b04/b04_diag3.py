"""Diagnostic: is the ADF boundary factor manufacturing a spurious stiff layer
at the inlet?

phi = tanh(rconj(walls, cylinder, inlet)/0.01); near x = 0 (away from the walls)
that is tanh(x/0.01), so nu*phi_xx*u_hat reaches ~2*nu/L^2 = 20*u_hat there —
a boundary-layer-scale structure imposed on a plane where the true flow has no
viscous layer at all. Here: the residual, the viscous term and |u_hat| in fine
x-bands next to the inlet, on a *uniform* sampler (no annulus/wake enrichment),
restricted to y in [0.10, 0.31] so the wall layers do not contaminate the bands.
"""
from __future__ import annotations

import sys
import types
import pickle
from pathlib import Path

import numpy as np
import jax
import jax.numpy as jnp
from jax import random

ROOT = Path.cwd()
P = lambda *a: print(*a, flush=True)


def load(path, name):
    mod = types.ModuleType(name)
    sys.modules[name] = mod
    exec(compile(Path(path).read_text(), f"<{name}>", "exec"), mod.__dict__)
    return mod


C = load(ROOT / "blocks/b03/b03_dens.py", "_champ_")
with open(ROOT / "blocks/b03/b03_dens.pkl", "rb") as f:
    SP = pickle.load(f)
SEG, NU = C.SEG, C.NU
net_mod = C.PINN()


@jax.jit
def probe(p, lo, hi, X):
    f = lambda Z: net_mod.apply(p, Z, lo, hi)
    ex = jnp.broadcast_to(jnp.array([0.0, 1.0, 0.0]), X.shape)
    ey = jnp.broadcast_to(jnp.array([0.0, 0.0, 1.0]), X.shape)
    et = jnp.broadcast_to(jnp.array([1.0, 0.0, 0.0]), X.shape)
    fx = lambda Z: jax.jvp(f, (Z,), (ex,))
    (val, dx), (_, dxx) = jax.jvp(fx, (X,), (ex,))
    fy = lambda Z: jax.jvp(f, (Z,), (ey,))
    (_, dy), (_, dyy) = jax.jvp(fy, (X,), (ey,))
    _, dt = jax.jvp(f, (X,), (et,))
    u, v = val[:, 0], val[:, 1]
    r_c = dx[:, 0] + dy[:, 1]
    r_mx = dt[:, 0] + u * dx[:, 0] + v * dy[:, 0] + dx[:, 2] - NU * (dxx[:, 0] + dyy[:, 0])
    r_my = dt[:, 1] + u * dx[:, 1] + v * dy[:, 1] + dy[:, 2] - NU * (dxx[:, 1] + dyy[:, 1])
    lap_u = NU * (dxx[:, 0] + dyy[:, 0])
    lift = C._lift_u(X)
    phi = C._phi(X)
    u_hat = (u - lift) / jnp.maximum(phi, 1e-6)
    return r_c, r_mx, r_my, lap_u, phi, u_hat, u, dx[:, 2]


key = random.PRNGKey(0)
edges = [0.0, 0.005, 0.01, 0.02, 0.04, 0.08, 0.15, 0.30, 0.60, 1.20, 1.80]
for k in (0, 7):
    lo, hi = SEG[k], SEG[k + 1]
    P(f"\n══ segment {k}  uniform sampler, y in [0.10, 0.31], "
      f"|r| and terms by x-band")
    P("   x-band        n    |r_c|  |r_mx|  |r_my|  nu*lap_u   p_x    phi   |u_hat|   |u|")
    for a, b in zip(edges[:-1], edges[1:]):
        key, k1, k2, k3 = random.split(key, 4)
        n = 4000
        x = random.uniform(k1, (n, 1), minval=a, maxval=b)
        y = random.uniform(k2, (n, 1), minval=0.10, maxval=0.31)
        t = random.uniform(k3, (n, 1), minval=lo, maxval=hi)
        X = jnp.concatenate([t, x, y], 1)
        m = np.asarray(((x[:, 0] - C.CYL_X) ** 2 + (y[:, 0] - C.CYL_Y) ** 2) > C.CYL_R ** 2)
        rc, rmx, rmy, lap, phi, uh, u, px = [np.asarray(z)[m] for z in probe(SP[k], lo, hi, X)]
        P(f"   [{a:.3f},{b:.3f}) {m.sum():5d} {np.abs(rc).mean():7.3f} "
          f"{np.abs(rmx).mean():7.3f} {np.abs(rmy).mean():7.3f} {np.abs(lap).mean():9.3f} "
          f"{np.abs(px).mean():7.3f} {phi.mean():6.3f} {np.abs(uh).mean():7.3f} "
          f"{np.abs(u).mean():6.3f}")
