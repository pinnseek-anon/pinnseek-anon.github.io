"""Diagnostic: anatomy of the champion's PDE residual — which points own it.

b04_diag1 showed l_pde outweighs the weighted handoff ~10x, so the residual is
the lever. Here: per-point squared-residual quantiles, the share carried by the
worst 0.1/1/5/10% of collocation points, a split by distance from the cylinder
(does the tanh(d/0.01) boundary factor put an unsatisfiable residual in a
sliver?), by x-station, and by normalised time inside the segment.
"""
from __future__ import annotations

import sys
import types
import pickle
from pathlib import Path

import numpy as np
import jax
import jax.numpy as jnp
from jax import random

ROOT = Path.cwd()
P = lambda *a: print(*a, flush=True)


def load(path, name):
    mod = types.ModuleType(name)
    sys.modules[name] = mod
    exec(compile(Path(path).read_text(), f"<{name}>", "exec"), mod.__dict__)
    return mod


C = load(ROOT / "blocks/b03/b03_dens.py", "_champ_")
with open(ROOT / "blocks/b03/b03_dens.pkl", "rb") as f:
    SP = pickle.load(f)

SEG, N_SEG, NU = C.SEG, C.N_SEG, C.NU
CYL_X, CYL_Y, CYL_R = C.CYL_X, C.CYL_Y, C.CYL_R
net_mod = C.PINN()


@jax.jit
def terms(p, lo, hi, key):
    X, m = C._sample_col(key, lo, hi)
    f = lambda Z: net_mod.apply(p, Z, lo, hi)
    ex = jnp.broadcast_to(jnp.array([0.0, 1.0, 0.0]), X.shape)
    ey = jnp.broadcast_to(jnp.array([0.0, 0.0, 1.0]), X.shape)
    et = jnp.broadcast_to(jnp.array([1.0, 0.0, 0.0]), X.shape)
    fx = lambda Z: jax.jvp(f, (Z,), (ex,))
    (val, dx), (_, dxx) = jax.jvp(fx, (X,), (ex,))
    fy = lambda Z: jax.jvp(f, (Z,), (ey,))
    (_, dy), (_, dyy) = jax.jvp(fy, (X,), (ey,))
    _, dt = jax.jvp(f, (X,), (et,))
    u, v = val[:, 0], val[:, 1]
    r_c = dx[:, 0] + dy[:, 1]
    r_mx = dt[:, 0] + u * dx[:, 0] + v * dy[:, 0] + dx[:, 2] - NU * (dxx[:, 0] + dyy[:, 0])
    r_my = dt[:, 1] + u * dx[:, 1] + v * dy[:, 1] + dy[:, 2] - NU * (dxx[:, 1] + dyy[:, 1])
    vis = NU * jnp.sqrt((dxx[:, 0] + dyy[:, 0]) ** 2 + (dxx[:, 1] + dyy[:, 1]) ** 2)
    return X, m, r_c ** 2 + r_mx ** 2 + r_my ** 2, vis, jnp.abs(r_c), jnp.abs(r_mx)


key = random.PRNGKey(0)
for k in (0, 3, 7, 11):
    lo, hi = SEG[k], SEG[k + 1]
    Xs, ms, rs, vs, rcs, rms_ = [], [], [], [], [], []
    for rep in range(6):                      # 6 fresh minibatches per segment
        key, sub = random.split(key)
        X, m, r2, vis, rc, rmx = terms(SP[k], lo, hi, sub)
        Xs.append(np.asarray(X)); ms.append(np.asarray(m)); rs.append(np.asarray(r2))
        vs.append(np.asarray(vis)); rcs.append(np.asarray(rc)); rms_.append(np.asarray(rmx))
    X = np.concatenate(Xs); m = np.concatenate(ms) > 0.5
    r2 = np.concatenate(rs)[m]; vis = np.concatenate(vs)[m]
    rc = np.concatenate(rcs)[m]; rmx = np.concatenate(rms_)[m]
    X = X[m]
    d = np.sqrt((X[:, 1] - CYL_X) ** 2 + (X[:, 2] - CYL_Y) ** 2) - CYL_R
    zt = (X[:, 0] - lo) / (hi - lo)
    tot = r2.sum()
    P(f"\n══ segment {k}  [{lo:.2f}, {hi:.2f}]   mean r2 = {r2.mean():.4f}   "
      f"n = {len(r2)}")
    q = np.quantile(r2, [0.5, 0.9, 0.99, 0.999])
    P(f"   quantiles of r2: median {q[0]:.4f}  p90 {q[1]:.4f}  p99 {q[2]:.4f}  "
      f"p999 {q[3]:.3f}  max {r2.max():.2f}")
    srt = np.sort(r2)[::-1]
    for frac in (0.001, 0.01, 0.05, 0.10):
        n = max(1, int(frac * len(r2)))
        P(f"   worst {100 * frac:5.1f}% of points carry {100 * srt[:n].sum() / tot:5.1f}% of l_pde")
    P("   by distance from the cylinder wall:")
    for a, b in ((0.0, 0.005), (0.005, 0.02), (0.02, 0.05), (0.05, 0.15), (0.15, 9.0)):
        s = (d >= a) & (d < b)
        if s.sum():
            P(f"     d in [{a:.3f},{b:.3f}) : {100 * s.mean():5.1f}% of pts, "
              f"{100 * r2[s].sum() / tot:5.1f}% of l_pde, mean r2 {r2[s].mean():8.4f}, "
              f"|r_c| {rc[s].mean():.3f}, |r_mx| {rmx[s].mean():.3f}, "
              f"nu*lap {vis[s].mean():.4f}")
    P("   by x station:")
    for a, b in ((0.0, 0.15), (0.15, 0.35), (0.35, 0.7), (0.7, 1.2), (1.2, 1.8)):
        s = (X[:, 1] >= a) & (X[:, 1] < b)
        if s.sum():
            P(f"     x in [{a:.2f},{b:.2f}) : {100 * s.mean():5.1f}% of pts, "
              f"{100 * r2[s].sum() / tot:5.1f}% of l_pde, mean r2 {r2[s].mean():8.4f}")
    P("   by normalised time in segment:")
    for a, b in ((0.0, 0.25), (0.25, 0.5), (0.5, 0.75), (0.75, 1.0)):
        s = (zt >= a) & (zt < b)
        P(f"     zt in [{a:.2f},{b:.2f}) : mean r2 {r2[s].mean():8.4f}")
