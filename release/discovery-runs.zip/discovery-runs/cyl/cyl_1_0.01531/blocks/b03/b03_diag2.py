"""Diagnostic: side-by-side dynamics error of b02_wic350 (VP) and b03_sv
(streamfunction-vorticity), measured identically from each model's velocity
field -- divergence, vorticity-transport residual, wake liveliness.
One jit per model (params passed in), so 12 segments cost one compile.
"""
from __future__ import annotations

import sys
import pickle
import types
from pathlib import Path
from functools import partial

import numpy as np
import jax
import jax.numpy as jnp

ROOT = Path.cwd()
EX = jnp.array([0.0, 1.0, 0.0])
EY = jnp.array([0.0, 0.0, 1.0])
ET = jnp.array([1.0, 0.0, 0.0])
P = partial(print, flush=True)


def load(path, name):
    mod = types.ModuleType(name)
    sys.modules[name] = mod
    exec(compile(Path(path).read_text(), f"<{name}>", "exec"), mod.__dict__)
    return mod


champ = load(ROOT / "blocks/b02/b02_wic350.py", "_champ_")
sv = load(ROOT / "blocks/b03/b03_sv.py", "_sv_")
NU = champ.NU
CYL_X, CYL_Y, CYL_R = champ.CYL_X, champ.CYL_Y, champ.CYL_R
SEG, N_SEG = champ.SEG, champ.N_SEG

_cnet, _snet = champ.PINN(), sv.PINN()


def vel_champ(p, X, lo, hi):
    return _cnet.apply(p, X, lo, hi)[:, :2]


def vel_sv(p, X, lo, hi):
    f = lambda Z: _snet.apply(p, Z, lo, hi)
    _, dx = jax.jvp(f, (X,), (jnp.broadcast_to(EX, X.shape),))
    _, dy = jax.jvp(f, (X,), (jnp.broadcast_to(EY, X.shape),))
    return jnp.stack([dy[:, 0], -dx[:, 0]], 1)


def make_stats(velfn):
    @jax.jit
    def stats(p, X, lo, hi):
        vel = lambda Z: velfn(p, Z, lo, hi)

        def omega(Z):
            _, dx = jax.jvp(vel, (Z,), (jnp.broadcast_to(EX, Z.shape),))
            _, dy = jax.jvp(vel, (Z,), (jnp.broadcast_to(EY, Z.shape),))
            return dx[:, 1] - dy[:, 0]

        ex = jnp.broadcast_to(EX, X.shape)
        ey = jnp.broadcast_to(EY, X.shape)
        et = jnp.broadcast_to(ET, X.shape)
        val, dx = jax.jvp(vel, (X,), (ex,))
        _, dy = jax.jvp(vel, (X,), (ey,))
        u, v = val[:, 0], val[:, 1]
        div = dx[:, 0] + dy[:, 1]
        gx = lambda Z: jax.jvp(omega, (Z,), (jnp.broadcast_to(EX, Z.shape),))
        (w, wx), (_, wxx) = jax.jvp(gx, (X,), (ex,))
        gy = lambda Z: jax.jvp(omega, (Z,), (jnp.broadcast_to(EY, Z.shape),))
        (_, wy), (_, wyy) = jax.jvp(gy, (X,), (ey,))
        _, wt = jax.jvp(omega, (X,), (et,))
        r_w = wt + u * wx + v * wy - NU * (wxx + wyy)
        return jnp.stack([u, v, div, w, wt, u * wx + v * wy, r_w], 1)
    return stats


def rms(a):
    return float(np.sqrt(np.mean(np.asarray(a) ** 2)))


NX, NY = 70, 22
xs = np.linspace(0.01, 1.7, NX)
ys = np.linspace(0.004, 0.406, NY)
XX, YY = np.meshgrid(xs, ys, indexing="ij")
keep = (XX - CYL_X) ** 2 + (YY - CYL_Y) ** 2 > (CYL_R + 0.004) ** 2
xk, yk = XX[keep], YY[keep]
wake = (xk > 0.3) & (xk < 1.5)
P(f"grid points per snapshot: {xk.size}")

KEYS = ["u", "v", "div", "w", "wt", "adv_w", "r_w"]

for lab, pkl, velfn in [("b02_wic350 (VP)", "blocks/b02/b02_wic350.pkl", vel_champ),
                        ("b03_sv (psi-omega)", "blocks/b03/b03_sv.pkl", vel_sv)]:
    pars = pickle.load(open(ROOT / pkl, "rb"))
    st = make_stats(velfn)
    rows, per = [], []
    for k in range(N_SEG):
        lo, hi = SEG[k], SEG[k + 1]
        t = 0.5 * (lo + hi)
        X = jnp.array(np.stack([np.full_like(xk, t), xk, yk], 1).astype(np.float32))
        s = np.asarray(st(pars[k], X, lo, hi))
        rows.append(s)
        per.append(s)
    S = np.concatenate(rows, 0)
    A = {k: S[:, i] for i, k in enumerate(KEYS)}
    wm = np.concatenate([wake] * N_SEG)
    P(f"\n=== {lab} ===")
    P(f"  u {rms(A['u']):.4f}  v {rms(A['v']):.4f}  omega {rms(A['w']):.2f}")
    P(f"  rms div      {rms(A['div']):.4f}   (wake {rms(A['div'][wm]):.4f})")
    P(f"  rms r_vort   {rms(A['r_w']):.2f}    (wake {rms(A['r_w'][wm]):.2f})")
    P(f"  rms w_t {rms(A['wt']):.2f}   adv {rms(A['adv_w']):.2f}")
    P(f"  r_vort/scale = {rms(A['r_w']) / rms(np.concatenate([A['wt'], A['adv_w']])):.4f}"
      f"   wake {rms(A['r_w'][wm]) / rms(np.concatenate([A['wt'][wm], A['adv_w'][wm]])):.4f}")
    P("  per-seg r_vort: " + " ".join(f"{rms(p[:, 6]):.0f}" for p in per))
    P("  per-seg rms v : " + " ".join(f"{rms(p[:, 1]):.3f}" for p in per))
    P("  per-seg rms dv: " + " ".join(f"{rms(p[:, 2]):.3f}" for p in per))
