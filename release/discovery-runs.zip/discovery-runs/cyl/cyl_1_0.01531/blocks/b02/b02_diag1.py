"""Why did hard BCs lose? Truth-free anatomy of three marched candidates.

Reports, for each (block, stem): the t=0 fit against the IC truth, the actual
boundary violations (cylinder / walls / inlet), the rms PDE residual and rms
divergence, the discontinuity of the marched field across each segment seam
(the handoff error that accumulates), and the b01_diag2 wake-phase metric.
"""
from __future__ import annotations

import pickle
import sys
import types
from pathlib import Path

import jax
import jax.numpy as jnp
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
CYL_X, CYL_Y, CYL_R = 0.2, 0.2, 0.05
Y_MAX, X_MAX = 0.41, 2.2
NU = 1.0e-3
MODELS = [("b01", "b01_tm14"), ("b02", "b02_hbc"), ("b02", "b02_ovl")]


def load(blk, stem):
    code = (ROOT / "blocks" / blk / f"{stem}.py").read_text()
    mod = types.ModuleType("_d_" + stem)
    sys.modules["_d_" + stem] = mod
    exec(compile(code, stem, "exec"), mod.__dict__)
    with open(ROOT / "blocks" / blk / f"{stem}.pkl", "rb") as f:
        params = pickle.load(f)
    return mod, params


def main():
    ic = np.loadtxt(ROOT / "task/cyl_ic.csv", delimiter=",", skiprows=1)
    r2 = (ic[:, 0] - CYL_X) ** 2 + (ic[:, 1] - CYL_Y) ** 2
    keep = (ic[:, 0] <= 1.7) & (r2 > CYL_R ** 2)
    xg, yg = ic[keep, 0], ic[keep, 1]
    uv_ic = np.stack([ic[keep, 2], ic[keep, 3]], 1)

    ts = np.linspace(0.0, 1.2, 25)
    Pfield = np.stack([np.repeat(ts, len(xg)),
                       np.tile(xg, len(ts)), np.tile(yg, len(ts))], 1).astype(np.float32)

    rng = np.random.default_rng(0)
    # boundary probe sets at 8 times spread over the window
    tb = np.linspace(0.05, 1.15, 8)
    th = rng.uniform(0, 2 * np.pi, 400)
    cyl = np.stack([np.repeat(tb, 400),
                    np.tile(CYL_X + CYL_R * np.cos(th), 8),
                    np.tile(CYL_Y + CYL_R * np.sin(th), 8)], 1).astype(np.float32)
    xw = rng.uniform(0, X_MAX, 400)
    yw = np.where(rng.random(400) < 0.5, 0.0, Y_MAX)
    wall = np.stack([np.repeat(tb, 400), np.tile(xw, 8), np.tile(yw, 8)], 1).astype(np.float32)
    yi = rng.uniform(0, Y_MAX, 400)
    inl = np.stack([np.repeat(tb, 400), np.zeros(3200), np.tile(yi, 8)], 1).astype(np.float32)

    # interior residual probe: uniform in the scored region, cylinder removed
    n = 6000
    xr = rng.uniform(0, 1.7, 3 * n)
    yr = rng.uniform(0, Y_MAX, 3 * n)
    ok = (xr - CYL_X) ** 2 + (yr - CYL_Y) ** 2 > (1.05 * CYL_R) ** 2
    xr, yr = xr[ok][:n], yr[ok][:n]
    tr = np.linspace(0.05, 1.15, 8)
    Pres = np.stack([np.repeat(tr, n), np.tile(xr, 8), np.tile(yr, 8)], 1).astype(np.float32)

    for blk, stem in MODELS:
        mod, params = load(blk, stem)
        pf = lambda X: mod.predict_fn(params, X)

        F = pf(jnp.asarray(Pfield))
        F = np.stack([np.asarray(F["u"]), np.asarray(F["v"])], 1).reshape(len(ts), len(xg), 2)
        e0 = float(np.linalg.norm(F[0] - uv_ic) / np.linalg.norm(uv_ic))

        b = pf(jnp.asarray(cyl))
        cyl_v = float(np.sqrt(np.mean(np.asarray(b["u"]) ** 2 + np.asarray(b["v"]) ** 2)))
        b = pf(jnp.asarray(wall))
        wall_v = float(np.sqrt(np.mean(np.asarray(b["u"]) ** 2 + np.asarray(b["v"]) ** 2)))
        b = pf(jnp.asarray(inl))
        tgt = 4.0 * 1.5 * np.sin(np.pi * (inl[:, 0] + 4.8) / 8.0) * inl[:, 2] * (Y_MAX - inl[:, 2]) / Y_MAX ** 2
        inl_v = float(np.sqrt(np.mean((np.asarray(b["u"]) - tgt) ** 2 + np.asarray(b["v"]) ** 2)))

        # residual + divergence via forward-mode AD of predict_fn
        def fvec(X):
            d = pf(X)
            return jnp.stack([d["u"], d["v"], d["p"]], 1)

        def dirs(X, e):
            return jnp.broadcast_to(jnp.asarray(e, jnp.float32), X.shape)

        X = jnp.asarray(Pres)
        ex, ey, et = dirs(X, [0., 1., 0.]), dirs(X, [0., 0., 1.]), dirs(X, [1., 0., 0.])
        (val, dx), (_, dxx) = jax.jvp(lambda Z: jax.jvp(fvec, (Z,), (ex,)), (X,), (ex,))
        (_, dy), (_, dyy) = jax.jvp(lambda Z: jax.jvp(fvec, (Z,), (ey,)), (X,), (ey,))
        _, dt = jax.jvp(fvec, (X,), (et,))
        u, v = val[:, 0], val[:, 1]
        div = dx[:, 0] + dy[:, 1]
        rmx = dt[:, 0] + u * dx[:, 0] + v * dy[:, 0] + dx[:, 2] - NU * (dxx[:, 0] + dyy[:, 0])
        rmy = dt[:, 1] + u * dx[:, 1] + v * dy[:, 1] + dy[:, 2] - NU * (dxx[:, 1] + dyy[:, 1])
        rms = lambda a: float(np.sqrt(np.mean(np.asarray(a) ** 2)))

        # segment seams: jump of the marched field across each usage boundary
        seams = np.array(mod.SEG[1:-1], dtype=np.float32)
        eps = 1e-4
        jumps = []
        for s in seams:
            A = np.stack([np.full(len(xg), s - eps), xg, yg], 1).astype(np.float32)
            B = np.stack([np.full(len(xg), s + eps), xg, yg], 1).astype(np.float32)
            fa, fb = pf(jnp.asarray(A)), pf(jnp.asarray(B))
            da = np.stack([np.asarray(fa["u"]), np.asarray(fa["v"])], 1)
            db = np.stack([np.asarray(fb["u"]), np.asarray(fb["v"])], 1)
            jumps.append(float(np.linalg.norm(da - db) / np.linalg.norm(da)))

        M = F.mean(0)
        f_mod, f_ic = F - M[None], uv_ic - M
        nic = np.linalg.norm(f_ic)
        corr = np.array([float(np.sum(f_mod[i] * f_ic) / (np.linalg.norm(f_mod[i]) * nic + 1e-12))
                         for i in range(len(ts))])
        amp = np.array([float(np.linalg.norm(f_mod[i]) / nic) for i in range(len(ts))])

        print(f"\n=== {stem} ===")
        print(f"  t=0 rel err vs IC truth : {e0:.4f}")
        print(f"  BC rms  cyl {cyl_v:.4f}   walls {wall_v:.4f}   inlet {inl_v:.4f}")
        print(f"  rms  div {rms(div):.4f}   r_mx {rms(rmx):.4f}   r_my {rms(rmy):.4f}")
        print("  seam jumps (rel): " + " ".join(f"{j:.3f}" for j in jumps))
        print("  t     : " + " ".join(f"{t:5.2f}" for t in ts[::2]))
        print("  corr  : " + " ".join(f"{c:+5.2f}" for c in corr[::2]))
        print("  amp   : " + " ".join(f"{a:5.2f}" for a in amp[::2]))


if __name__ == "__main__":
    main()
