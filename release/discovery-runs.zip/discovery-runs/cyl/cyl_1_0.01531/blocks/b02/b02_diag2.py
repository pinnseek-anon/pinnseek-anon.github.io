"""Term-by-term anatomy of the momentum/continuity residual of b01_tm14.

Reports the rms of every individual term entering r_mx, r_my and r_c (so the
residual can be read as a fraction of the terms it balances), split by region
(near cylinder / wake / far) and by time segment.
"""
from __future__ import annotations

import pickle
import sys
import types
from pathlib import Path

import jax
import jax.numpy as jnp
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
CYL_X, CYL_Y, CYL_R = 0.2, 0.2, 0.05
Y_MAX = 0.41
NU = 1.0e-3
MODELS = [("b01", "b01_tm14"), ("b02", "b02_hbc")]


def load(blk, stem):
    code = (ROOT / "blocks" / blk / f"{stem}.py").read_text()
    mod = types.ModuleType("_d2_" + stem)
    sys.modules["_d2_" + stem] = mod
    exec(compile(code, stem, "exec"), mod.__dict__)
    with open(ROOT / "blocks" / blk / f"{stem}.pkl", "rb") as f:
        return mod, pickle.load(f)


def main():
    rng = np.random.default_rng(1)
    n = 20000
    xr = rng.uniform(0, 1.7, 4 * n)
    yr = rng.uniform(0, Y_MAX, 4 * n)
    ok = (xr - CYL_X) ** 2 + (yr - CYL_Y) ** 2 > (1.05 * CYL_R) ** 2
    xr, yr = xr[ok][:n], yr[ok][:n]
    ts = np.linspace(0.05, 1.15, 12)
    P = np.stack([np.repeat(ts, n), np.tile(xr, 12), np.tile(yr, 12)], 1).astype(np.float32)

    d = np.sqrt((np.tile(xr, 12) - CYL_X) ** 2 + (np.tile(yr, 12) - CYL_Y) ** 2)
    xx = np.tile(xr, 12)
    reg = {"near(d<0.15)": d < 0.15,
           "wake(0.25<x<1.2)": (xx > 0.25) & (xx < 1.2) & (d >= 0.15),
           "far(x>1.2)": xx >= 1.2}
    seg_id = np.repeat(np.arange(12), n)

    rms = lambda a: float(np.sqrt(np.mean(np.asarray(a) ** 2)))

    for blk, stem in MODELS:
        mod, params = load(blk, stem)

        def fvec(X):
            o = mod.predict_fn(params, X)
            return jnp.stack([o["u"], o["v"], o["p"]], 1)

        X = jnp.asarray(P)
        b = lambda e: jnp.broadcast_to(jnp.asarray(e, jnp.float32), X.shape)
        ex, ey, et = b([0., 1., 0.]), b([0., 0., 1.]), b([1., 0., 0.])
        (val, dx), (_, dxx) = jax.jvp(lambda Z: jax.jvp(fvec, (Z,), (ex,)), (X,), (ex,))
        (_, dy), (_, dyy) = jax.jvp(lambda Z: jax.jvp(fvec, (Z,), (ey,)), (X,), (ey,))
        _, dt = jax.jvp(fvec, (X,), (et,))
        u, v = val[:, 0], val[:, 1]
        terms = {
            "u_t": dt[:, 0], "adv_u": u * dx[:, 0] + v * dy[:, 0], "p_x": dx[:, 2],
            "visc_u": -NU * (dxx[:, 0] + dyy[:, 0]),
            "v_t": dt[:, 1], "adv_v": u * dx[:, 1] + v * dy[:, 1], "p_y": dy[:, 2],
            "visc_v": -NU * (dxx[:, 1] + dyy[:, 1]),
            "u_x": dx[:, 0], "v_y": dy[:, 1],
        }
        rmx = terms["u_t"] + terms["adv_u"] + terms["p_x"] + terms["visc_u"]
        rmy = terms["v_t"] + terms["adv_v"] + terms["p_y"] + terms["visc_v"]
        rc = terms["u_x"] + terms["v_y"]

        print(f"\n=== {stem} ===")
        print("  term rms: " + "  ".join(f"{k} {rms(t):.3f}" for k, t in terms.items()))
        print(f"  residual rms: r_mx {rms(rmx):.3f}  r_my {rms(rmy):.3f}  r_c {rms(rc):.3f}")
        print(f"  |u| {rms(u):.3f}  |v| {rms(v):.3f}  |p| {rms(val[:, 2]):.3f}")
        for name, m in reg.items():
            print(f"    {name:18s} r_mx {rms(rmx[m]):.3f} r_my {rms(rmy[m]):.3f} "
                  f"r_c {rms(rc[m]):.3f}  adv_u {rms(terms['adv_u'][m]):.3f}")
        print("    per-segment r_mx: " + " ".join(f"{rms(rmx[seg_id == k]):.2f}" for k in range(12)))
        print("    per-segment r_c : " + " ".join(f"{rms(rc[seg_id == k]):.2f}" for k in range(12)))


if __name__ == "__main__":
    main()
