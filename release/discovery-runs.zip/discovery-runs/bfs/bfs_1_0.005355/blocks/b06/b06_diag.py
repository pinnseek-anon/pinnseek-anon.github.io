"""Free CPU/GPU diagnostic: structure + residual decomposition of the saved
b06 fields (and b05's champion for reference).  Reads only .pkl params — never
task/ref_data.csv.  Registered on GPU via `eval.py ... --diag`, but the whole
report also runs for free on CPU.
"""
from __future__ import annotations

import os, pickle, sys, types
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

import jax
import jax.numpy as jnp

NX, NY = 481, 65
XS = np.linspace(0.0, 15.0, NX)
YS = np.linspace(-0.5, 0.5, NY)
XG, YG = np.meshgrid(XS, YS)                      # [NY, NX]
PTS = jnp.array(np.stack([XG.ravel(), YG.ravel()], 1).astype(np.float32))
NU = 1.0 / 800.0


def load(pyfile: str):
    code = Path(ROOT / pyfile).read_text(encoding="utf-8")
    mod = types.ModuleType("m_" + Path(pyfile).stem)
    sys.modules[mod.__name__] = mod
    exec(compile(code, "<cand>", "exec"), mod.__dict__)
    with open(ROOT / pyfile.replace(".py", ".pkl"), "rb") as f:
        params = pickle.load(f)
    return mod, params


def fields(mod, params):
    out = mod.predict_fn(params, PTS)
    u = np.asarray(out["u"]).reshape(NY, NX)
    v = np.asarray(out["v"]).reshape(NY, NX)
    return u, v


def structure(tag, u, v):
    dy = YS[1] - YS[0]
    flux = np.trapezoid(u, YS, axis=0)
    # wall shear sign -> separation / reattachment
    bot = u[1, :]                       # first row above the bottom wall
    top = u[-2, :]
    def crossings(s):
        idx = np.where(np.sign(s[:-1]) != np.sign(s[1:]))[0]
        return [round(float(XS[i] + (XS[i + 1] - XS[i]) * abs(s[i]) /
                            (abs(s[i]) + abs(s[i + 1]))), 3) for i in idx]
    print(f"  [{tag}] u range [{u.min():+.3f},{u.max():+.3f}]  "
          f"v range [{v.min():+.3f},{v.max():+.3f}]")
    print(f"      flux mean {flux.mean():.4f} drift {100*(flux.max()-flux.min())/0.5:.2f}%  "
          f"| min bottom-row u {bot.min():+.4f}  min top-row u {top.min():+.4f}")
    print(f"      bottom-wall u sign changes at x = {crossings(bot)[:6]}")
    print(f"      top-wall    u sign changes at x = {crossings(top)[:6]}")


def ns_residual(u, v):
    """Steady NS residual of a *gridded* field by central differences — a
    formulation-independent yardstick (the training loss is autodiff-based)."""
    dx = XS[1] - XS[0]; dy = YS[1] - YS[0]
    ux = np.gradient(u, dx, axis=1); uy = np.gradient(u, dy, axis=0)
    vx = np.gradient(v, dx, axis=1); vy = np.gradient(v, dy, axis=0)
    uxx = np.gradient(ux, dx, axis=1); uyy = np.gradient(uy, dy, axis=0)
    vxx = np.gradient(vx, dx, axis=1); vyy = np.gradient(vy, dy, axis=0)
    rc = ux + vy
    # pressure-free check: curl of momentum = vorticity transport residual
    om = vx - uy
    omx = np.gradient(om, dx, axis=1); omy = np.gradient(om, dy, axis=0)
    omxx = np.gradient(omx, dx, axis=1); omyy = np.gradient(omy, dy, axis=0)
    rw = u * omx + v * omy - NU * (omxx + omyy)
    s = np.s_[2:-2, 2:-2]
    print(f"      |div u| rms {np.sqrt(np.mean(rc[s]**2)):.3e} max {np.abs(rc[s]).max():.3e}"
          f"   vort-transport rms {np.sqrt(np.mean(rw[s]**2)):.3e}"
          f"   |omega| max {np.abs(om[s]).max():.2f}")
    _ = (uxx, uyy, vxx, vyy)


def psiw_internals(mod, params):
    """How the two heads relate: omega vs -lap(psi), and how far psi is from
    the bare lift (did the correction head learn anything?)."""
    def psi_om(xy):
        raw = mod._PREDICT_MODEL.apply(params, xy[None, :])[0]
        return mod._fields(raw, xy)
    def lap_psi(xy):
        H = jax.hessian(lambda z: psi_om(z)[0])(xy)
        return H[0, 0] + H[1, 1]
    q = jax.vmap(psi_om)(PTS)
    lp = jax.vmap(lap_psi)(PTS)
    om = np.asarray(q[:, 1]); psi = np.asarray(q[:, 0]); lp = np.asarray(lp)
    x = np.asarray(PTS[:, 0]); y = np.asarray(PTS[:, 1])
    sg = np.tanh((x / mod.L_IN) ** 2); w = 1 - 4 * y * y
    lift = (0.25 + 0.75 * y - y ** 3) * 1.0
    G = np.where(y > 0, 6 * y * y - 8 * y ** 3, 0.0)
    lift = lift + (G - lift) * (1 - sg)
    corr = psi - lift
    r_psi = lp + om
    print(f"      coupling  rms(omega + lap psi) {np.sqrt(np.mean(r_psi**2)):.3e}"
          f"   rms(omega) {np.sqrt(np.mean(om**2)):.3f}   max|omega| {np.abs(om).max():.2f}")
    print(f"      psi correction: rms {np.sqrt(np.mean(corr**2)):.4f}  max {np.abs(corr).max():.4f}"
          f"   (lift rms {np.sqrt(np.mean(lift**2)):.4f})")
    _ = (w,)


def autodiff_residuals(mod, params):
    """The two training residuals, measured exactly as the loss sees them."""
    def q_of(xy):
        raw = mod._PREDICT_MODEL.apply(params, xy[None, :])[0]
        return mod._fields(raw, xy)
    def per_point(xy):
        H_psi = jax.hessian(lambda z: q_of(z)[0])(xy)
        H_om = jax.hessian(lambda z: q_of(z)[1])(xy)
        g_psi = jax.grad(lambda z: q_of(z)[0])(xy)
        g_om = jax.grad(lambda z: q_of(z)[1])(xy)
        om = q_of(xy)[1]
        u, v = g_psi[1], -g_psi[0]
        r_psi = -(H_psi[0, 0] + H_psi[1, 1] + om)
        r_om = u * g_om[0] + v * g_om[1] - NU * (H_om[0, 0] + H_om[1, 1])
        return jnp.stack([r_psi, r_om])
    r = np.asarray(jax.vmap(per_point)(PTS))
    x = np.asarray(PTS[:, 0])
    print(f"      autodiff residual rms: r_psi {np.sqrt(np.mean(r[:,0]**2)):.3e}"
          f"   r_omega {np.sqrt(np.mean(r[:,1]**2)):.3e}")
    for lo, hi in [(0, 0.5), (0.5, 4), (4, 8), (8, 15.01)]:
        m = (x >= lo) & (x < hi)
        print(f"        x in [{lo},{hi}): r_psi {np.sqrt(np.mean(r[m,0]**2)):.3e}"
              f"  r_omega {np.sqrt(np.mean(r[m,1]**2)):.3e}")


def compare(ua, va, ub, vb, ta, tb):
    """Relative L2 distance between two fields, and where it lives."""
    num = np.sqrt(np.sum((ua-ub)**2 + (va-vb)**2))
    den = np.sqrt(np.sum(ub**2 + vb**2))
    print(f"  [{ta} vs {tb}] relative L2 distance {num/den:.4f}")
    tot = np.sum((ua-ub)**2 + (va-vb)**2)
    for lo, hi in [(0, 0.5), (0.5, 4), (4, 8), (8, 12), (12, 15.01)]:
        m = (XS >= lo) & (XS < hi)
        part = np.sum((ua[:, m]-ub[:, m])**2 + (va[:, m]-vb[:, m])**2)
        print(f"        x in [{lo},{hi}): {100*part/tot:5.1f} % of the squared difference")


def main():
    print("== b06 field diagnostics ==")
    store = {}
    for f in sys.argv[1:] or ["blocks/b06/b06_base.py", "blocks/b06/b06_psiw.py"]:
        if not (ROOT / f.replace(".py", ".pkl")).is_file():
            print(f"  [{f}] no .pkl — skipped"); continue
        mod, params = load(f)
        u, v = fields(mod, params)
        structure(Path(f).stem, u, v)
        ns_residual(u, v)
        if hasattr(mod, "_fields"):
            psiw_internals(mod, params)
            autodiff_residuals(mod, params)
        store[Path(f).stem] = (u, v)
        print()
    ks = list(store)
    if "b06_base" in ks:
        for k in ks:
            if k != "b06_base":
                compare(*store[k], *store["b06_base"], k, "b06_base")


if __name__ == "__main__":
    main()
