"""b08 continuation probe (--diag): how far is the pseudo-time march from
converged at the 180 s wall?  Measures the field displacement between the
saved 40k / 70k / 110k seed-0 fields (whose rRMSE is known), then continues
the march past 110k steps and reports the same displacement + residual, so
the score gain per further step can be extrapolated reference-blind.
"""
from __future__ import annotations

import os
import pickle
import sys
import time
import types
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
_T0 = float(os.environ.get("FORGE_T0", time.time()))
WALL = float(os.environ.get("B08_CONT_WALL", "158"))
REP = int(os.environ.get("B08_CONT_REP", "50"))

import jax
import jax.numpy as jnp
from jax import random
import jax.flatten_util
import optax


def load(path: Path):
    mod = types.ModuleType("_b08_cont_" + path.stem)
    sys.modules[mod.__name__] = mod
    exec(compile(path.read_text(encoding="utf-8"), str(path), "exec"), mod.__dict__)
    return mod


mod = load(ROOT / "blocks" / "b08" / "b08_base.py")

nx, ny = 481, 65
xs = np.linspace(mod.X_MIN, mod.X_MAX, nx)
ys = np.linspace(mod.Y_MIN, mod.Y_MAX, ny)
X, Y = np.meshgrid(xs, ys)
GRID = jnp.array(np.stack([X.flatten(), Y.flatten()], axis=1).astype(np.float32))


def field(params):
    d = mod.predict_fn(params, GRID)
    return np.stack([np.asarray(d["u"]), np.asarray(d["v"])], axis=1)


def rel(a, b):
    return float(np.linalg.norm(a - b) / np.linalg.norm(b))


def main():
    saved = [("40k", "b08_n400.pkl", 0.03186), ("70k", "b08_n700.pkl", 0.02027),
             ("110k", "b08_base.pkl", 0.01639)]
    fields = {}
    for tag, fn, score in saved:
        with open(ROOT / "blocks" / "b08" / fn, "rb") as f:
            fields[tag] = field(pickle.load(f))
    print("--- displacement between the saved seed-0 fields (rRMSE known) ---")
    for a, b in [("40k", "70k"), ("70k", "110k"), ("40k", "110k")]:
        print(f"  |q({a}) - q({b})| / |q({b})| = {rel(fields[a], fields[b]):.5f}")
    for tag, fn, score in saved:
        print(f"  rRMSE({tag}) = {score:.5f}")

    # ---- continue the march from the 110k field ----
    with open(ROOT / "blocks" / "b08" / "b08_base.pkl", "rb") as f:
        p110 = pickle.load(f)
    q110 = fields["110k"]

    flat, unravel = jax.flatten_util.ravel_pytree(p110)
    # run_chunk closes over a schedule-based optimiser; rebuild the whole
    # training closure with a constant schedule pinned at the LR floor, and
    # keep ITS optimiser state so the pytree structures match.
    mod.LR0 = mod.LR_FLOOR
    mod.LR_DECAY_RATE = 1.0
    flat0, opt_state, run_chunk, unravel3, rng = mod._make_train(random.PRNGKey(0))
    assert flat0.shape == flat.shape
    params_flat = jnp.asarray(flat)
    ema = params_flat

    print("\n--- continuation past 110k steps (fresh Adam at the LR floor) ---")
    print("  extra_steps  |q - q(110k)|   |q - q(70k)|")
    n_extra = 0
    while time.time() - _T0 < WALL:
        for _ in range(REP):
            rng, k = random.split(rng)
            params_flat, opt_state, ema, loss = run_chunk(params_flat, opt_state, ema, k)
            n_extra += mod.CHUNK
        qc = field(unravel3(ema))
        print(f"  {n_extra:9d}    {rel(qc, q110):.5f}       {rel(qc, fields['70k']):.5f}"
              f"    loss={float(loss):.4e}")
    print(f"\n  total extra steps: {n_extra}")


if __name__ == "__main__":
    main()
