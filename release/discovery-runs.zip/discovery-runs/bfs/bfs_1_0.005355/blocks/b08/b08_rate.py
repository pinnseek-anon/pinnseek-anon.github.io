"""b08 rate probe (--diag): steps/s of the champion training step under the
knobs that could buy more pseudo-time chunks inside the 180 s wall — batch
size, network shape, matmul precision.  b08's stopping-point sweep shows the
score is still falling with step count, so the step rate is the resource.
"""
from __future__ import annotations

import sys
import time
import types
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]

import jax
import jax.numpy as jnp
from jax import random


def load(path: Path):
    mod = types.ModuleType("_b08_rate_" + path.stem)
    sys.modules[mod.__name__] = mod
    exec(compile(path.read_text(encoding="utf-8"), str(path), "exec"), mod.__dict__)
    return mod


def rate(tag, bs=None, shape=None, precision=None, chunk=None):
    mod = load(ROOT / "blocks" / "b08" / "b08_base.py")
    if bs is not None:
        mod.BS_INT = bs
    if chunk is not None:
        mod.CHUNK = chunk
    if shape is not None:
        base_cls = mod.PINN
        w, d = shape
        mod.PINN = lambda: base_cls(hidden_width=w, n_hidden_layers=d)
    if precision is not None:
        jax.config.update("jax_default_matmul_precision", precision)
    else:
        jax.config.update("jax_default_matmul_precision", "highest")

    t0 = time.time()
    params, opt_state, run_chunk, unravel, rng = mod._make_train(random.PRNGKey(0))
    n_par = params.size
    ema = params
    rng, k = random.split(rng)
    params, opt_state, ema, loss = run_chunk(params, opt_state, ema, k)
    loss.block_until_ready()
    t_compile = time.time() - t0

    n_chunks = 20
    t0 = time.time()
    for _ in range(n_chunks):
        rng, k = random.split(rng)
        params, opt_state, ema, loss = run_chunk(params, opt_state, ema, k)
    loss.block_until_ready()
    dt = time.time() - t0
    c = chunk or mod.CHUNK
    sps = n_chunks * c / dt
    budget = 180.0 - 6.0 - t_compile - 3.0
    print(f"{tag:28s} params={n_par:6d} compile={t_compile:5.1f}s "
          f"{sps:7.1f} steps/s  loss={float(loss):.4e}  "
          f"-> {int(sps * budget / c)} chunks in the wall")
    return sps


if __name__ == "__main__":
    rate("BS2048 5x100 (champion)")
    rate("BS1024 5x100", bs=1024)
    rate("BS512  5x100", bs=512)
    rate("BS2048 4x64", shape=(64, 4))
    rate("BS2048 5x100 tf32", precision="tensorfloat32")
    rate("BS1024 5x100 tf32", bs=1024, precision="tensorfloat32")
    rate("BS1024 4x64  tf32", bs=1024, shape=(64, 4), precision="tensorfloat32")
