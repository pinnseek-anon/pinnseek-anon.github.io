"""b08 diagnostic: measure the pressure-Poisson (PPE) defect of the saved
champion fields — the one independent NS condition that costs no extra
derivative order (p_xx, p_yy, u_x, u_y, v_x, v_y are all already computed by
the champion's 2-direction jvp).  Runs free on CPU from the .pkl files.
"""
from __future__ import annotations

import os
import pickle
import sys
import types
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[2]

import jax
import jax.numpy as jnp

CHAMP = ROOT / "blocks" / "b06" / "b06_base.py"


def load_module(path: Path):
    code = path.read_text(encoding="utf-8")
    mod = types.ModuleType("_champ_" + path.stem)
    sys.modules[mod.__name__] = mod
    exec(compile(code, str(path), "exec"), mod.__dict__)
    return mod


def analyse(mod, params, tag):
    NU = mod.NU
    model = mod.PINN()
    ansatz = mod._ansatz

    def predict_one(xy):
        raw = model.apply(params, xy[None, :])[0]
        return ansatz(raw, xy)

    ex = jnp.array([1.0, 0.0])
    ey = jnp.array([0.0, 1.0])

    def dir2(xy, e):
        def inner(z):
            return jax.jvp(predict_one, (z,), (e,))
        (q, d1), (_, d2) = jax.jvp(inner, (xy,), (e,))
        return q, d1, d2

    def per_point(xy):
        q, dx, dxx = dir2(xy, ex)
        _, dy, dyy = dir2(xy, ey)
        u, v = q[0], q[1]
        r_mx = u * dx[0] + v * dy[0] + dx[2] - NU * (dxx[0] + dyy[0])
        r_my = u * dx[1] + v * dy[1] + dy[2] - NU * (dxx[1] + dyy[1])
        r_c = dx[0] + dy[1]
        lap_p = dxx[2] + dyy[2]
        prod = dx[0] ** 2 + 2.0 * dy[0] * dx[1] + dy[1] ** 2
        r_p = lap_p + prod
        return jnp.stack([r_mx, r_my, r_c, r_p, lap_p, prod, u, v, q[2]])

    nx, ny = 481, 65
    xs = np.linspace(mod.X_MIN, mod.X_MAX, nx)
    ys = np.linspace(mod.Y_MIN, mod.Y_MAX, ny)
    X, Y = np.meshgrid(xs, ys)
    pts = jnp.array(np.stack([X.flatten(), Y.flatten()], axis=1).astype(np.float32))

    out = []
    f = jax.jit(jax.vmap(per_point))
    for i in range(0, pts.shape[0], 4096):
        out.append(np.asarray(f(pts[i:i + 4096])))
    A = np.concatenate(out, axis=0)
    names = ["r_mx", "r_my", "r_c", "r_ppe", "lap_p", "gradu:gradu", "u", "v", "p"]
    rms = {n: float(np.sqrt(np.mean(A[:, k] ** 2))) for k, n in enumerate(names)}
    print(f"\n=== {tag} ===")
    print("  rms: " + "  ".join(f"{n}={rms[n]:.4g}" for n in names))
    # scale of the pointwise pseudo-time loss terms
    m3 = float(np.mean(A[:, 0] ** 2 + A[:, 1] ** 2 + A[:, 2] ** 2))
    m4 = float(np.mean(A[:, 3] ** 2))
    print(f"  mean(r_mx^2+r_my^2+r_c^2) = {m3:.4g}   mean(r_ppe^2) = {m4:.4g}"
          f"   ratio = {m4 / max(m3, 1e-30):.4g}")
    # banded rms of the ppe defect
    x = np.asarray(pts[:, 0])
    for lo, hi in [(0.0, 0.5), (0.5, 2.0), (2.0, 4.0), (4.0, 8.0), (8.0, 15.0)]:
        m = (x >= lo) & (x < hi)
        print(f"    x in [{lo},{hi}): r_ppe={np.sqrt(np.mean(A[m,3]**2)):.4g}  "
              f"r_mx={np.sqrt(np.mean(A[m,0]**2)):.4g}  "
              f"r_c={np.sqrt(np.mean(A[m,2]**2)):.4g}")
    return A


DEFAULT = [
    ("blocks/b06/b06_base.py", "blocks/b06/b06_base.pkl", "b06_base s0 (0.02053)"),
    ("blocks/b07/b07_fd.py", "blocks/b07/b07_fd_s2.pkl", "b07_fd s2 (0.01170)"),
]


def main():
    args = sys.argv[1:]
    if args:
        targets = [(a.replace(".pkl", ".py").rsplit("_s", 1)[0] + ".py"
                    if a.endswith(".pkl") and "_s" in Path(a).stem else
                    a.replace(".pkl", ".py"), a, Path(a).stem) for a in args]
    else:
        targets = [(m, p, t) for m, p, t in DEFAULT]
    for mpath, ppath, tag in targets:
        mp, pp = ROOT / mpath, ROOT / ppath
        if not pp.is_file():
            print(f"missing {pp}")
            continue
        with open(pp, "rb") as f:
            params = pickle.load(f)
        analyse(load_module(mp), params, tag)


if __name__ == "__main__":
    main()
