"""Diag: (a) verify the SPINN lattice JVP streams against per-point autodiff,
(b) price steps/s of a full pseudo-time chunk for a few (rank, width, grid)
configurations, so N_CHUNKS can be fixed to the 180 s wall (b08 lead 1)."""
import time

import jax
import jax.numpy as jnp
import numpy as np
import optax
from flax import linen as nn
import jax.flatten_util

X_MIN, X_MAX = 0.0, 15.0
Y_MIN, Y_MAX = -0.5, 0.5
NU = 1.0 / 800.0
OUTPUT_DIM = 3
L_IN = 0.25
DT = 1.0
_XC, _XS = 0.5 * (X_MIN + X_MAX), 0.5 * (X_MAX - X_MIN)
_YC, _YS = 0.5 * (Y_MIN + Y_MAX), 0.5 * (Y_MAX - Y_MIN)


def _U_in(y):
    return jnp.where(y > 0.0, 24.0 * y * (0.5 - y), 0.0)


def _ansatz(raw, x, y):
    s = jnp.tanh(x / L_IN)
    w = 1.0 - 4.0 * y * y
    ws = w * s
    return jnp.stack([_U_in(y) * (1.0 - s) + ws * raw[..., 0],
                      ws * raw[..., 1],
                      raw[..., 2]], axis=-1)


class AxisBody(nn.Module):
    width: int
    depth: int
    rank: int

    @nn.compact
    def __call__(self, z):
        kinit = jax.nn.initializers.he_uniform()
        h = z
        for _ in range(self.depth):
            h = nn.tanh(nn.Dense(self.width, kernel_init=kinit)(h))
        out = nn.Dense(OUTPUT_DIM * self.rank, kernel_init=kinit)(h)
        return out.reshape(out.shape[0], OUTPUT_DIM, self.rank)


class SPINN2D(nn.Module):
    width: int = 64
    depth: int = 5
    rank: int = 128

    def setup(self):
        self.ax = AxisBody(self.width, self.depth, self.rank, name="axis_x")
        self.ay = AxisBody(self.width, self.depth, self.rank, name="axis_y")

    def _fx(self, xs):
        return self.ax(((xs - _XC) / _XS)[:, None])

    def _fy(self, ys):
        return self.ay(((ys - _YC) / _YS)[:, None])

    def __call__(self, xs, ys):
        return jnp.einsum("ick,jck->ijc", self._fx(xs), self._fy(ys)) / np.sqrt(self.rank)

    def pointwise(self, xy):
        return jnp.einsum("ick,ick->ic", self._fx(xy[:, 0]),
                          self._fy(xy[:, 1])) / np.sqrt(self.rank)


def build(rank, width, depth, nxs, nys, seed=0):
    nx, ny = 481, 65
    xs_full = np.linspace(X_MIN, X_MAX, nx)[1:]
    ys_full = np.linspace(Y_MIN, Y_MAX, ny)[1:-1]
    xs = jnp.array(xs_full[:: max(1, len(xs_full) // nxs)].astype(np.float32))
    ys = jnp.array(ys_full[:: max(1, len(ys_full) // nys)].astype(np.float32))
    model = SPINN2D(width=width, depth=depth, rank=rank)
    params = model.init(jax.random.PRNGKey(seed), xs[:2], ys[:2])
    flat, unravel = jax.flatten_util.ravel_pytree(params)
    ones_x, ones_y = jnp.ones_like(xs), jnp.ones_like(ys)

    def field(pf, xa, ya):
        return _ansatz(model.apply(unravel(pf), xa, ya), xa[:, None], ya[None, :])

    def streams(pf):
        fx = lambda z: field(pf, z, ys)
        (q, dx), (_, dxx) = jax.jvp(lambda z: jax.jvp(fx, (z,), (ones_x,)),
                                    (xs,), (ones_x,))
        fy = lambda z: field(pf, xs, z)
        (_, dy), (_, dyy) = jax.jvp(lambda z: jax.jvp(fy, (z,), (ones_y,)),
                                    (ys,), (ones_y,))
        return q, dx, dy, dxx, dyy

    def loss_fn(pf, pprev):
        q, dx, dy, dxx, dyy = streams(pf)
        u, v = q[..., 0], q[..., 1]
        r_mx = u * dx[..., 0] + v * dy[..., 0] + dx[..., 2] - NU * (dxx[..., 0] + dyy[..., 0])
        r_my = u * dx[..., 1] + v * dy[..., 1] + dy[..., 2] - NU * (dxx[..., 1] + dyy[..., 1])
        r_c = dx[..., 0] + dy[..., 1]
        r = jnp.stack([r_mx, r_my, r_c], axis=-1)
        q_n = jax.lax.stop_gradient(field(pprev, xs, ys))
        return (jnp.mean(jnp.sum(((q - q_n) / DT + r) ** 2, axis=-1))
                + jnp.mean(q[-1, :, 2]) ** 2)

    return model, unravel, flat, xs, ys, field, streams, loss_fn


def check_correctness():
    model, unravel, flat, xs, ys, field, streams, _ = build(32, 32, 3, 40, 20)
    q, dx, dy, dxx, dyy = streams(flat)

    def point(pf, xy):
        raw = model.apply(unravel(pf), xy[None, :], method=SPINN2D.pointwise)[0]
        return _ansatz(raw, xy[0], xy[1])

    d1 = jax.jacfwd(point, argnums=1)
    d2 = jax.jacfwd(jax.jacfwd(point, argnums=1), argnums=1)
    errs = []
    for i in (0, 7, 19, 39):
        for j in (0, 5, 13, 19):
            xy = jnp.array([xs[i], ys[j]])
            a1, a2 = d1(flat, xy), d2(flat, xy)
            errs.append(float(jnp.max(jnp.abs(a1[:, 0] - dx[i, j]))))
            errs.append(float(jnp.max(jnp.abs(a1[:, 1] - dy[i, j]))))
            errs.append(float(jnp.max(jnp.abs(a2[:, 0, 0] - dxx[i, j]))))
            errs.append(float(jnp.max(jnp.abs(a2[:, 1, 1] - dyy[i, j]))))
            errs.append(float(jnp.max(jnp.abs(point(flat, xy) - q[i, j]))))
    print(f"[check] max |lattice-JVP - per-point jacfwd| = {max(errs):.3e}")


def rate(rank, width, depth, nxs, nys, chunk=100):
    _, _, flat, xs, ys, field, _, loss_fn = build(rank, width, depth, nxs, nys)
    lg = jax.value_and_grad(loss_fn)
    sched = optax.exponential_decay(1e-3, 2000, 0.9, end_value=1e-4)
    opt = optax.adam(sched)
    st = opt.init(flat)

    def one(pprev, carry, _):
        pf, st, ema = carry
        loss, g = lg(pf, pprev)
        upd, st = opt.update(g, st)
        pf = optax.apply_updates(pf, upd)
        ema = 0.999 * ema + 0.001 * pf
        return (pf, st, ema), loss

    @jax.jit
    def run(pf, st, ema):
        pp = jax.lax.stop_gradient(pf)
        (a, b, c), l = jax.lax.scan(lambda cr, k: one(pp, cr, k), (pf, st, ema),
                                    None, length=chunk)
        return a, b, c, l[-1]

    t0 = time.time()
    a, b, c, l = run(flat, st, flat)
    float(l)
    t_compile = time.time() - t0
    t0 = time.time()
    for _ in range(5):
        a, b, c, l = run(a, b, c)
    float(l)
    dt = (time.time() - t0) / 5
    n_pts = len(xs) * len(ys)
    print(f"rank={rank:4d} w={width:3d} d={depth} grid={len(xs)}x{len(ys)}={n_pts:6d} "
          f"| {chunk/dt:7.1f} steps/s | compile {t_compile:5.1f}s "
          f"| loss {float(l):.4e} | Mpt-upd/s {chunk/dt*n_pts/1e6:7.1f}")
    return chunk / dt


if __name__ == "__main__":
    print("devices:", jax.devices())
    check_correctness()
    for rk, w, d, nxs, nys in [(128, 64, 5, 480, 63),
                               (64, 64, 5, 480, 63),
                               (256, 64, 5, 480, 63),
                               (128, 128, 5, 480, 63),
                               (128, 64, 5, 240, 63),
                               (128, 64, 5, 480, 126)]:
        rate(rk, w, d, nxs, nys)
