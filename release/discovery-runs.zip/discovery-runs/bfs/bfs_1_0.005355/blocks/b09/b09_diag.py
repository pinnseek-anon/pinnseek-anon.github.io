"""Diag (runs free on CPU): SVD rank spectrum of the champion's own field on
the 481x65 lattice — i.e. how much rank a separable/CP ansatz (kb1/070) needs —
plus a field-space comparison of the b09 SPINN fields against the b08 champion
fields (b07's reference-blind conformity surrogate)."""
import os
import pickle

os.environ.setdefault("JAX_PLATFORMS", "cpu")

import numpy as np

X_MIN, X_MAX = 0.0, 15.0
Y_MIN, Y_MAX = -0.5, 0.5
L_IN = 0.25


def grid():
    xs = np.linspace(X_MIN, X_MAX, 481)
    ys = np.linspace(Y_MIN, Y_MAX, 65)
    X, Y = np.meshgrid(xs, ys, indexing="ij")
    return xs, ys, np.stack([X.ravel(), Y.ravel()], 1).astype(np.float32)


def load(path, code):
    import sys
    import types
    import jax.numpy as jnp
    name = "m_" + os.path.basename(code)[:-3]
    mod = types.ModuleType(name)
    sys.modules[name] = mod
    exec(compile(open(code).read(), code, "exec"), mod.__dict__)
    with open(path, "rb") as f:
        params = pickle.load(f)
    _, _, pts = grid()
    out = mod.predict_fn(params, jnp.asarray(pts))
    return np.stack([np.asarray(out["u"]), np.asarray(out["v"])], -1).reshape(481, 65, 2)


def spectrum(M, name):
    s = np.linalg.svd(M, compute_uv=False)
    tot = np.sqrt(np.sum(s ** 2))
    line = []
    for r in (1, 2, 4, 8, 16, 32, 64):
        tail = np.sqrt(np.sum(s[r:] ** 2)) / tot
        line.append(f"r={r}:{tail:.2e}")
    print(f"  {name:18s} rel. tail error  " + "  ".join(line))


def main():
    xs, ys, _ = grid()
    fields = {}
    for tag, pkl, code in [
        ("b08_base", "blocks/b08/b08_base.pkl", "blocks/b08/b08_base.py"),
        ("b08_base_s1", "blocks/b08/b08_base_s1.pkl", "blocks/b08/b08_base.py"),
        ("b08_base_s2", "blocks/b08/b08_base_s2.pkl", "blocks/b08/b08_base.py"),
        ("b09_spinn", "blocks/b09/b09_spinn.pkl", "blocks/b09/b09_spinn.py"),
        ("b09_spinw", "blocks/b09/b09_spinw.pkl", "blocks/b09/b09_spinw.py"),
    ]:
        if os.path.exists(pkl):
            fields[tag] = load(pkl, code)
            print(f"loaded {tag}")

    print("\n== how separable is the champion field? (SVD over x (x) y) ==")
    q = fields["b08_base"]
    s = np.tanh(xs / L_IN)[:, None]
    w = (1.0 - 4.0 * ys * ys)[None, :]
    U_in = np.where(ys > 0, 24.0 * ys * (0.5 - ys), 0.0)[None, :]
    lift = U_in * (1.0 - s)
    for name, M in [("u", q[:, :, 0]), ("v", q[:, :, 1]),
                    ("u_hat (ansatz)", (q[:, :, 0] - lift) / np.maximum(w * s, 1e-6)),
                    ("v_hat (ansatz)", q[:, :, 1] / np.maximum(w * s, 1e-6))]:
        spectrum(M, name)

    print("\n== field distances (relative, ||a-b|| / ||champion||) ==")
    ref = fields["b08_base"]
    nref = np.linalg.norm(ref)
    for tag, f in fields.items():
        print(f"  {tag:14s} d(.,b08_base) = {np.linalg.norm(f - ref) / nref:.4f}"
              f"   ||q|| = {np.linalg.norm(f) / nref:.4f}")

    print("\n== where the SPINN field differs from the champion (x-bands) ==")
    for tag in ("b09_spinn", "b09_spinw"):
        if tag not in fields:
            continue
        d2 = np.sum((fields[tag] - ref) ** 2, axis=(1, 2))
        tot = d2.sum()
        parts = []
        for lo, hi in ((0, 1), (1, 4), (4, 8), (8, 12), (12, 15)):
            m = (xs >= lo) & (xs < hi)
            parts.append(f"[{lo},{hi}) {100 * d2[m].sum() / tot:4.1f}%")
        print(f"  {tag:12s} " + "  ".join(parts))

    print("\n== structure (bottom-wall reattachment / upper-eddy extent) ==")
    for tag, f in fields.items():
        u = f[:, :, 0]
        jb, jt = 2, 62
        sb = np.sign(u[:, jb])
        rb = [xs[i] for i in range(1, 481) if sb[i - 1] < 0 <= sb[i]]
        st = np.sign(u[:, jt])
        rt = [xs[i] for i in range(1, 481) if st[i - 1] * st[i] < 0]
        print(f"  {tag:14s} bottom reattach {rb[:2]}  top-wall sign changes "
              f"{[round(v, 2) for v in rt[:3]]}  u range "
              f"[{u.min():.3f}, {u.max():.3f}]")


def ensemble():
    """Per-member fields of b09_ens3 and their mutual distances / spread."""
    import sys
    import types
    import jax.numpy as jnp
    name = "m_ens"
    mod = types.ModuleType(name)
    sys.modules[name] = mod
    exec(compile(open("blocks/b09/b09_ens3.py").read(), "e", "exec"), mod.__dict__)
    with open("blocks/b09/b09_ens3.pkl", "rb") as f:
        params = pickle.load(f)
    _, _, pts = grid()
    fs = []
    for i, mp in enumerate(params["members"]):
        out = mod.predict_fn({"members": [mp]}, jnp.asarray(pts))
        fs.append(np.stack([np.asarray(out["u"]), np.asarray(out["v"])], -1).reshape(481, 65, 2))
    mean = np.mean(fs, 0)
    ref = load("blocks/b09/b09_s5dt2.pkl", "blocks/b09/b09_s5dt2.py")
    n = np.linalg.norm(ref)
    print("\n== b09_ens3 members (distances relative to ||b09_s5dt2||) ==")
    for i, f in enumerate(fs):
        print(f"  member {i}: d(.,s5dt2) = {np.linalg.norm(f - ref) / n:.4f}   "
              f"d(.,ens mean) = {np.linalg.norm(f - mean) / n:.4f}   "
              f"||q|| = {np.linalg.norm(f) / n:.4f}   u range "
              f"[{f[:, :, 0].min():.3f}, {f[:, :, 0].max():.3f}]")
    for i in range(len(fs)):
        for j in range(i + 1, len(fs)):
            print(f"  d(member {i}, member {j}) = {np.linalg.norm(fs[i] - fs[j]) / n:.4f}")
    print(f"  d(ens mean, s5dt2) = {np.linalg.norm(mean - ref) / n:.4f}")


def gram():
    """Error-Gram calculus (free, no reference data): for fields f_i with known
    rRMSE_i, <e_i,e_j> = (||e_i||^2 + ||e_j||^2 - ||f_i-f_j||^2)/2, so the score
    of ANY weighted average of saved fields can be predicted before spending an
    eval. ||q_ref|| is approximated by ||b08_base|| (all fields agree to 0.3%)."""
    cat = [
        ("b08_base  110k", "blocks/b08/b08_base.pkl", "blocks/b08/b08_base.py", 0.016392),
        ("b08_n700   70k", "blocks/b08/b08_n700.pkl", "blocks/b08/b08_n700.py", 0.020270),
        ("b08_n400   40k", "blocks/b08/b08_n400.pkl", "blocks/b08/b08_n400.py", 0.031860),
        ("b08_lrs4  110k", "blocks/b08/b08_lrs4.pkl", "blocks/b08/b08_lrs4.py", 0.015280),
        ("b09_s5dt2  50k", "blocks/b09/b09_s5dt2.pkl", "blocks/b09/b09_s5dt2.py", 0.022723),
        ("b09_dt3   180k", "blocks/b09/b09_dt3.pkl", "blocks/b09/b09_dt3.py", 0.022534),
        ("b09_dt2   180k", "blocks/b09/b09_dt2.pkl", "blocks/b09/b09_dt2.py", 0.024996),
        ("b09_spinw 175k", "blocks/b09/b09_spinw.pkl", "blocks/b09/b09_spinw.py", 0.058805),
    ]
    names, fs, rr = [], [], []
    for nm, pk, cd, r in cat:
        if os.path.exists(pk):
            names.append(nm); fs.append(load(pk, cd)); rr.append(r)
    N = np.linalg.norm(fs[0])
    n = len(fs)
    e = np.array(rr) * N
    G = np.zeros((n, n))
    for i in range(n):
        for j in range(n):
            d2 = np.sum((fs[i] - fs[j]) ** 2)
            G[i, j] = 0.5 * (e[i] ** 2 + e[j] ** 2 - d2)
    print("\n== error correlation matrix (cos angle between error fields) ==")
    print("                 " + "  ".join(f"{nm[:9]:>9s}" for nm in names))
    for i in range(n):
        print(f"  {names[i]:15s} " + "  ".join(f"{G[i,j]/np.sqrt(G[i,i]*G[j,j]):9.3f}" for j in range(n)))
    print("\n== predicted rRMSE of equal-weight averages ==")
    import itertools
    rows = []
    for k in (1, 2, 3):
        for c in itertools.combinations(range(n), k):
            w = np.zeros(n); w[list(c)] = 1.0 / k
            rows.append((float(np.sqrt(w @ G @ w) / N), [names[i] for i in c]))
    rows.sort()
    for s, c in rows[:14]:
        print(f"  {s:.5f}   {' + '.join(x.strip() for x in c)}")
    print("\n== optimal (unconstrained, sum-to-one) weights over all fields ==")
    ones = np.ones(n)
    Gi = np.linalg.pinv(G)
    w = Gi @ ones / (ones @ Gi @ ones)
    print("  predicted rRMSE", f"{float(np.sqrt(w @ G @ w) / N):.5f}",
          " weights", {names[i].split()[0]: round(float(w[i]), 3) for i in range(n)})


if __name__ == "__main__":
    main()
    if os.path.exists("blocks/b09/b09_ens3.pkl"):
        ensemble()
    gram()
