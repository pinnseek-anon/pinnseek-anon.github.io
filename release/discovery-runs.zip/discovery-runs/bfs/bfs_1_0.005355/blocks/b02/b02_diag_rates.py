"""Diagnostic (not a candidate): step-rate probe for the design choices b02
is weighing, so full evals are not spent finding out what is affordable.

Times one Adam/SOAP training step of the b01 pseudo-time loss under four
derivative/optimiser variants at BS_INT = 2048 on GPU:
  (a) baseline: nested jacfwd Hessian, flat params, Adam   (b01_pts_ema)
  (b) 2-direction jvp-of-jvp (only the Hessian diagonal is needed), Adam
  (c) baseline derivatives, pytree params, SOAP (kb1/130's optimiser)
  (d) stream-function output (exact continuity) -> 3rd derivatives, Adam
"""
import os
import sys
import time
import types
from pathlib import Path

import jax
import jax.numpy as jnp
import numpy as np
import optax
from jax import jacfwd, jit, random, vmap
from jax.flatten_util import ravel_pytree
from flax import linen as nn

T0 = float(os.environ.get("FORGE_T0", time.time()))
WALL = 155.0
NSTEP = int(os.environ.get("DIAG_NSTEP", "200"))

ROOT = Path(__file__).resolve().parents[2]
SRC = ROOT / "blocks" / "b01" / "b01_pts_ema.py"
mod = types.ModuleType("_diag_src__")
sys.modules["_diag_src__"] = mod
exec(compile(SRC.read_text(encoding="utf-8"), "<src>", "exec"), mod.__dict__)

NU = mod.NU
BS = mod.BS_INT          # 2048
DT = mod.DT              # 0.5
W_BC, W_OUT = mod.WEIGHT_BC, mod.WEIGHT_OUT
pts_int, pts_bc, u_bc, v_bc, pts_out = mod._build_dataset()
n_int = pts_int.shape[0]
key0 = random.PRNGKey(0)

_XC, _XS = 7.5, 7.5
_YC, _YS = 0.0, 0.5


def _norm(xy):
    return jnp.stack([(xy[..., 0] - _XC) / _XS, (xy[..., 1] - _YC) / _YS], axis=-1)


class MLP(nn.Module):
    width: int = 100
    depth: int = 5
    d_out: int = 3

    @nn.compact
    def __call__(self, xy):
        ki = jax.nn.initializers.he_uniform()
        h = _norm(xy)
        for _ in range(self.depth):
            h = nn.tanh(nn.Dense(self.width, kernel_init=ki)(h))
        return nn.Dense(self.d_out, kernel_init=ki)(h)


def time_it(name, step_fn, args, n=None):
    n = NSTEP if n is None else n
    out = step_fn(*args)
    jax.block_until_ready(out)
    t = time.time()
    compile_s = None
    for _ in range(n):
        out = step_fn(*args)
    jax.block_until_ready(out)
    dt = time.time() - t
    print(f"  {name:52s} {n/dt:8.1f} steps/s  ({1000*dt/n:.2f} ms/step)")
    return n / dt


print(f"BS_INT={BS}  n_int={n_int}")
print("\n=== step rates ===")

# ── (a) baseline: nested jacfwd, flat params, Adam ──────────────────────
model = MLP()
p0 = model.init(key0, jnp.zeros([1, 2]))
flat0, unravel = ravel_pytree(p0)


def pred1(fp, xy):
    return model.apply(unravel(fp), xy[None, :])[0]


d1_a = jacfwd(pred1, argnums=1)
d2_a = jacfwd(jacfwd(pred1, argnums=1), argnums=1)


def res_a(fp, xy):
    q = pred1(fp, xy)
    d1 = d1_a(fp, xy)
    d2 = d2_a(fp, xy)
    r_mx = q[0]*d1[0, 0] + q[1]*d1[0, 1] + d1[2, 0] - NU*(d2[0, 0, 0] + d2[0, 1, 1])
    r_my = q[0]*d1[1, 0] + q[1]*d1[1, 1] + d1[2, 1] - NU*(d2[1, 0, 0] + d2[1, 1, 1])
    return q, jnp.stack([r_mx, r_my, d1[0, 0] + d1[1, 1]])


def make_loss(res_fn, pred_fn):
    def pts_pt(fp, fprev, xy):
        q, r = res_fn(fp, xy)
        qn = jax.lax.stop_gradient(pred_fn(fprev, xy))
        return jnp.sum(((q[:3] - qn[:3]) / DT + r) ** 2)

    pb = vmap(pts_pt, in_axes=(None, None, 0))
    fb = vmap(pred_fn, in_axes=(None, 0))

    def loss(fp, fprev, xy):
        l = jnp.mean(pb(fp, fprev, xy))
        q = fb(fp, pts_bc)
        l += W_BC * jnp.mean((q[:, 0] - u_bc) ** 2 + (q[:, 1] - v_bc) ** 2)
        l += W_OUT * jnp.mean(fb(fp, pts_out)[:, 2] ** 2)
        return l
    return loss


loss_a = make_loss(res_a, pred1)
opt = optax.adam(1e-3)
st = opt.init(flat0)
idx = random.choice(key0, n_int, (BS,))
xb = pts_int[idx]


@jit
def step_a(fp, st, xb):
    v, g = jax.value_and_grad(loss_a)(fp, fp, xb)
    u, st = opt.update(g, st)
    return optax.apply_updates(fp, u), st


r_a = time_it("(a) nested jacfwd + flat params + Adam", step_a, (flat0, st, xb))

# ── (b) 2-direction jvp-of-jvp (Hessian diagonal only) ──────────────────
_EX = jnp.array([1.0, 0.0])
_EY = jnp.array([0.0, 1.0])


def _dd(fp, xy, e):
    """(f, df/de, d2f/de2) by forward-over-forward along a single direction."""
    def inner(z):
        return jax.jvp(lambda w: pred1(fp, w), (z,), (e,))
    (q, d1), (_, d2) = jax.jvp(inner, (xy,), (e,))
    return q, d1, d2


def res_b(fp, xy):
    q, dx, dxx = _dd(fp, xy, _EX)
    _, dy, dyy = _dd(fp, xy, _EY)
    r_mx = q[0]*dx[0] + q[1]*dy[0] + dx[2] - NU*(dxx[0] + dyy[0])
    r_my = q[0]*dx[1] + q[1]*dy[1] + dy[2] - NU*(dxx[1] + dyy[1])
    return q, jnp.stack([r_mx, r_my, dx[0] + dy[1]])


loss_b = make_loss(res_b, pred1)
st_b = opt.init(flat0)


@jit
def step_b(fp, st, xb):
    v, g = jax.value_and_grad(loss_b)(fp, fp, xb)
    u, st = opt.update(g, st)
    return optax.apply_updates(fp, u), st


r_b = time_it("(b) 2-dir jvp-of-jvp + flat params + Adam", step_b, (flat0, st_b, xb))

# ── (c) pytree params + SOAP ────────────────────────────────────────────
try:
    from soap_jax import soap

    def pred1_t(pt, xy):
        return model.apply(pt, xy[None, :])[0]

    d1_c = jacfwd(pred1_t, argnums=1)
    d2_c = jacfwd(jacfwd(pred1_t, argnums=1), argnums=1)

    def res_c(pt, xy):
        q = pred1_t(pt, xy)
        d1 = d1_c(pt, xy)
        d2 = d2_c(pt, xy)
        r_mx = q[0]*d1[0, 0] + q[1]*d1[0, 1] + d1[2, 0] - NU*(d2[0, 0, 0] + d2[0, 1, 1])
        r_my = q[0]*d1[1, 0] + q[1]*d1[1, 1] + d1[2, 1] - NU*(d2[1, 0, 0] + d2[1, 1, 1])
        return q, jnp.stack([r_mx, r_my, d1[0, 0] + d1[1, 1]])

    loss_c = make_loss(res_c, pred1_t)
    opt_c = soap(learning_rate=1e-3, precondition_frequency=10)
    st_c = opt_c.init(p0)

    @jit
    def step_c(pt, st, xb):
        v, g = jax.value_and_grad(loss_c)(pt, pt, xb)
        u, st = opt_c.update(g, st, pt)
        return optax.apply_updates(pt, u), st

    r_c = time_it("(c) nested jacfwd + pytree params + SOAP", step_c, (p0, st_c, xb))
except Exception as e:  # noqa: BLE001
    print(f"  (c) SOAP failed: {type(e).__name__}: {e}")

# ── (d) stream function: 3rd derivatives ────────────────────────────────
model_d = MLP(d_out=2)          # (psi, p)
pd0 = model_d.init(key0, jnp.zeros([1, 2]))
fd0, unravel_d = ravel_pytree(pd0)


def psi_p(fp, xy):
    return model_d.apply(unravel_d(fp), xy[None, :])[0]


def uvp_d(fp, xy):
    g = jacfwd(psi_p, argnums=1)(fp, xy)
    o = psi_p(fp, xy)
    return jnp.stack([g[0, 1], -g[0, 0], o[1]])     # u = psi_y, v = -psi_x


d1_d = jacfwd(uvp_d, argnums=1)
d2_d = jacfwd(jacfwd(uvp_d, argnums=1), argnums=1)


def res_d(fp, xy):
    q = uvp_d(fp, xy)
    d1 = d1_d(fp, xy)
    d2 = d2_d(fp, xy)
    r_mx = q[0]*d1[0, 0] + q[1]*d1[0, 1] + d1[2, 0] - NU*(d2[0, 0, 0] + d2[0, 1, 1])
    r_my = q[0]*d1[1, 0] + q[1]*d1[1, 1] + d1[2, 1] - NU*(d2[1, 0, 0] + d2[1, 1, 1])
    return q, jnp.stack([r_mx, r_my, jnp.zeros(())])


loss_d = make_loss(res_d, uvp_d)
st_d = opt.init(fd0)


@jit
def step_d(fp, st, xb):
    v, g = jax.value_and_grad(loss_d)(fp, fp, xb)
    u, st = opt.update(g, st)
    return optax.apply_updates(fp, u), st


try:
    r_d = time_it("(d) stream function (3rd derivs) + Adam", step_d, (fd0, st_d, xb), n=max(1, NSTEP*6//10))
except Exception as e:  # noqa: BLE001
    print(f"  (d) stream function failed: {type(e).__name__}: {e}")

print(f"\nwall used {time.time()-T0:.1f}s")
print("\nDIAG OK")
