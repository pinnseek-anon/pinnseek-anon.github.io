"""Diagnostic (not a candidate): can a full-batch quasi-Newton polish
improve b01's champion field?

Loads blocks/b01/b01_pts_ema.pkl (rRMSE 0.05444, the block-best), then runs
optax.lbfgs (kb1/074 Adam->L-BFGS pipeline) on the FULL-grid steady NS loss
for a fixed wall, reporting loss, per-component residual RMS, BC error,
mass-flux drift and the separation/reattachment structure before and after.
Also times the iteration rate so the phase length can be budgeted.
"""
import pickle
import sys
import time
import types
from pathlib import Path

import jax
import jax.numpy as jnp
import numpy as np
import optax
from jax import jacfwd, vmap
from jax.flatten_util import ravel_pytree

T0 = float(__import__("os").environ.get("FORGE_T0", time.time()))
WALL = float(__import__("os").environ.get("DIAG_WALL", "150"))   # leave margin under eval.py's 180 s diag wall

ROOT = Path(__file__).resolve().parents[2]
SRC = ROOT / "blocks" / "b01" / "b01_pts_ema.py"
PKL = ROOT / "blocks" / "b01" / "b01_pts_ema.pkl"

mod = types.ModuleType("_diag_src__")
sys.modules["_diag_src__"] = mod
exec(compile(SRC.read_text(encoding="utf-8"), "<src>", "exec"), mod.__dict__)

with open(PKL, "rb") as f:
    params0 = pickle.load(f)

NU = mod.NU
model = mod.PINN()
flat0, unravel = ravel_pytree(params0)
print(f"params: {flat0.size}")

# ── point sets (identical to the candidate's) ───────────────────────────
pts_int, pts_bc, u_bc, v_bc, pts_out = mod._build_dataset()
_sub = int(__import__("os").environ.get("DIAG_SUB", "0"))   # >0: subsample (CPU dry-run)
if _sub:
    pts_int = pts_int[::max(1, pts_int.shape[0] // _sub)]
n_int = pts_int.shape[0]
print(f"interior {n_int}  bc {pts_bc.shape[0]}  out {pts_out.shape[0]}")


def predict_one(fp, xy):
    return model.apply(unravel(fp), xy[None, :])[0]


d1_fn = jacfwd(predict_one, argnums=1)
d2_fn = jacfwd(jacfwd(predict_one, argnums=1), argnums=1)


def res_vec(fp, xy):
    q = predict_one(fp, xy)
    u, v = q[0], q[1]
    d1 = d1_fn(fp, xy)
    d2 = d2_fn(fp, xy)
    u_x, u_y = d1[0, 0], d1[0, 1]
    v_x, v_y = d1[1, 0], d1[1, 1]
    p_x, p_y = d1[2, 0], d1[2, 1]
    r_mx = u * u_x + v * u_y + p_x - NU * (d2[0, 0, 0] + d2[0, 1, 1])
    r_my = u * v_x + v * v_y + p_y - NU * (d2[1, 0, 0] + d2[1, 1, 1])
    r_c = u_x + v_y
    return jnp.stack([r_mx, r_my, r_c])


res_batch = vmap(res_vec, in_axes=(None, 0))
fwd_batch = vmap(predict_one, in_axes=(None, 0))

W_BC = mod.WEIGHT_BC       # 100.0
W_OUT = mod.WEIGHT_OUT     # 1.0


def steady_loss(fp):
    """Full-batch steady NS loss — no pseudo-time term, no minibatching."""
    pde = jnp.mean(jnp.sum(res_batch(fp, pts_int) ** 2, axis=1))
    q = fwd_batch(fp, pts_bc)
    bc = jnp.mean((q[:, 0] - u_bc) ** 2 + (q[:, 1] - v_bc) ** 2)
    out = jnp.mean(fwd_batch(fp, pts_out)[:, 2] ** 2)
    return pde + W_BC * bc + W_OUT * out


# ── reporting helpers ───────────────────────────────────────────────────
nx, ny = 481, 65
xs = np.linspace(0.0, 15.0, nx)
ys = np.linspace(-0.5, 0.5, ny)
Xg, Yg = np.meshgrid(xs, ys, indexing="ij")
grid = jnp.asarray(np.stack([Xg.ravel(), Yg.ravel()], axis=1).astype(np.float32))


def _inflow(y):
    return np.where(y > 0.0, 24.0 * y * (0.5 - y), 0.0)


def _sign_changes(col):
    s = np.sign(col)
    idx = np.where(s[:-1] * s[1:] < 0)[0]
    return [round(float(xs[i] + (xs[i + 1] - xs[i]) * abs(col[i])
                        / (abs(col[i]) + abs(col[i + 1]) + 1e-30)), 3) for i in idx]


@jax.jit
def _fields(fp):
    q = fwd_batch(fp, grid)
    r = res_batch(fp, grid)
    return q, r


def report(tag, fp):
    q, r = _fields(fp)
    q = np.asarray(q).reshape(nx, ny, 3)
    r = np.asarray(r).reshape(nx, ny, 3)
    u, v, p = q[..., 0], q[..., 1], q[..., 2]
    flux = np.trapezoid(u, ys, axis=1)
    print(f"\n--- {tag} ---")
    print(f"  u [{u.min():+.4f},{u.max():+.4f}]  v [{v.min():+.4f},{v.max():+.4f}]"
          f"  p [{p.min():+.4f},{p.max():+.4f}]")
    print(f"  BC max|err|: inlet u {np.abs(u[0] - _inflow(ys)).max():.3e}"
          f"  walls u {max(abs(u[:, 0]).max(), abs(u[:, -1]).max()):.3e}"
          f"  outlet p {np.abs(p[-1]).max():.3e}")
    print(f"  mass flux (exact 0.5): min {flux.min():.5f} max {flux.max():.5f}"
          f"  drift {100*(flux.max()-flux.min())/0.5:.2f}%")
    print("  residual RMS  r_mx {:.4e}  r_my {:.4e}  r_c {:.4e}".format(
        *[np.sqrt((r[..., k] ** 2).mean()) for k in range(3)]))
    print("  residual RMS by x-band (r_mx):  " + "  ".join(
        f"[{a},{b}) {np.sqrt((r[(Xg[:,0]>=a)&(Xg[:,0]<b)][...,0]**2).mean()):.2e}"
        for a, b in ((0, 1), (1, 2), (2, 4), (4, 8), (8, 15))))
    print(f"  bottom-wall u sign changes: {_sign_changes(u[:, 1])}  (Gartling 6.10)")
    print(f"  top-wall    u sign changes: {_sign_changes(u[:, -2])}  (Gartling 4.85, 10.48)")


report("BEFORE (b01_pts_ema)", flat0)

# ── L-BFGS polish ───────────────────────────────────────────────────────
value_and_grad = jax.jit(jax.value_and_grad(steady_loss))
opt = optax.lbfgs(learning_rate=None, memory_size=20,
                  linesearch=optax.scale_by_zoom_linesearch(max_linesearch_steps=20))
state = opt.init(flat0)


@jax.jit
def lbfgs_step(fp, state):
    val, grad = value_and_grad(fp)
    upd, state = opt.update(grad, state, fp, value=val, grad=grad,
                            value_fn=steady_loss)
    return optax.apply_updates(fp, upd), state, val


t_compile = time.time()
fp, state, val = lbfgs_step(flat0, state)
jax.block_until_ready(fp)
print(f"\nL-BFGS compile+first step: {time.time()-t_compile:.1f}s   loss0 {val:.6e}")

t0 = time.time()
it = 1
best = (float(val), flat0)
while time.time() - T0 < WALL:
    fp, state, val = lbfgs_step(fp, state)
    it += 1
    if it % 25 == 0:
        v = float(val)
        if not np.isfinite(v):
            print(f"  it {it}: non-finite loss, stop")
            break
        if v < best[0]:
            best = (v, fp)
        print(f"  it {it:5d}  loss {v:.6e}  {it/(time.time()-t0):.1f} it/s")
jax.block_until_ready(fp)
rate = it / (time.time() - t0)
print(f"\nL-BFGS: {it} iters in {time.time()-t0:.1f}s = {rate:.1f} it/s"
      f"   final loss {float(val):.6e}   best {best[0]:.6e}")

report("AFTER L-BFGS", fp)
print("\nDIAG OK")
