"""Diagnostic (not a candidate): field/residual report for a trained b02
candidate, to locate what is still wrong after the hard-BC + PTS recipe.

Targets are listed in TARGETS (candidate stem -> its .pkl in blocks/b02/).
Reports field ranges, BC satisfaction, mass-flux drift, per-component and
x-banded residual RMS, and the separation/reattachment structure against
Gartling's Re=800 benchmark (bottom reattachment 6.10, top eddy 4.85-10.48).
"""
import pickle
import sys
import types
from pathlib import Path

import jax
import jax.numpy as jnp
import numpy as np
from jax import vmap

TARGETS = ["b02_dt10", "b02_outlet", "b02_dt20"]
ROOT = Path(__file__).resolve().parents[2]

nx, ny = 481, 65
xs = np.linspace(0.0, 15.0, nx)
ys = np.linspace(-0.5, 0.5, ny)
Xg, Yg = np.meshgrid(xs, ys, indexing="ij")
grid = jnp.asarray(np.stack([Xg.ravel(), Yg.ravel()], axis=1).astype(np.float32))


def _inflow(y):
    return np.where(y > 0.0, 24.0 * y * (0.5 - y), 0.0)


def _sign_changes(col):
    s = np.sign(col)
    idx = np.where(s[:-1] * s[1:] < 0)[0]
    return [round(float(xs[i] + (xs[i + 1] - xs[i]) * abs(col[i])
                        / (abs(col[i]) + abs(col[i + 1]) + 1e-30)), 3) for i in idx]


for stem in TARGETS:
    cand = ROOT / "blocks" / "b02" / f"{stem}.py"
    pkl = ROOT / "blocks" / "b02" / f"{stem}.pkl"
    if not pkl.is_file():
        print(f"\n### {stem}: no params, skipped")
        continue
    mod = types.ModuleType(f"_diag_{stem}__")
    sys.modules[f"_diag_{stem}__"] = mod
    exec(compile(cand.read_text(encoding="utf-8"), "<cand>", "exec"), mod.__dict__)
    with open(pkl, "rb") as f:
        params = pickle.load(f)
    NU = mod.NU
    pf = mod.predict_fn

    def uvp_one(xy):
        o = pf(params, xy[None, :])
        return jnp.stack([o["u"][0], o["v"][0], o["p"][0]])

    ex, ey = jnp.array([1.0, 0.0]), jnp.array([0.0, 1.0])

    def dir2(xy, e):
        def inner(z):
            return jax.jvp(uvp_one, (z,), (e,))
        (q, d1), (_, d2) = jax.jvp(inner, (xy,), (e,))
        return q, d1, d2

    def res_one(xy):
        q, dx, dxx = dir2(xy, ex)
        _, dy, dyy = dir2(xy, ey)
        r_mx = q[0]*dx[0] + q[1]*dy[0] + dx[2] - NU*(dxx[0] + dyy[0])
        r_my = q[0]*dx[1] + q[1]*dy[1] + dy[2] - NU*(dxx[1] + dyy[1])
        return jnp.stack([r_mx, r_my, dx[0] + dy[1]])

    q = np.asarray(jax.jit(vmap(uvp_one))(grid)).reshape(nx, ny, 3)
    r = np.asarray(jax.jit(vmap(res_one))(grid)).reshape(nx, ny, 3)
    u, v, p = q[..., 0], q[..., 1], q[..., 2]
    flux = np.trapezoid(u, ys, axis=1)

    print(f"\n### {stem}")
    print(f"  u [{u.min():+.4f},{u.max():+.4f}]  v [{v.min():+.4f},{v.max():+.4f}]"
          f"  p [{p.min():+.4f},{p.max():+.4f}]")
    print(f"  BC max|err|: inlet u {np.abs(u[0] - _inflow(ys)).max():.3e}"
          f"  walls u {max(abs(u[:, 0]).max(), abs(u[:, -1]).max()):.3e}"
          f"  outlet p {np.abs(p[-1]).max():.3e}")
    print(f"  mass flux (exact 0.5): min {flux.min():.5f} max {flux.max():.5f}"
          f"  drift {100*(flux.max()-flux.min())/0.5:.2f}%")
    print("  residual RMS  r_mx {:.4e}  r_my {:.4e}  r_c {:.4e}".format(
        *[np.sqrt((r[..., k] ** 2).mean()) for k in range(3)]))
    for k, nm in enumerate(("r_mx", "r_my", "r_c")):
        print(f"  {nm} RMS by x-band: " + "  ".join(
            f"[{a},{b}) {np.sqrt((r[(Xg[:,0]>=a)&(Xg[:,0]<b)][...,k]**2).mean()):.2e}"
            for a, b in ((0, 0.5), (0.5, 1), (1, 2), (2, 4), (4, 8), (8, 15))))
    print(f"  bottom-wall u sign changes: {_sign_changes(u[:, 1])}   (Gartling 6.10)")
    print(f"  top-wall    u sign changes: {_sign_changes(u[:, -2])}   (Gartling 4.85, 10.48)")
    j = ny // 2
    print("  centreline u at x=1,2,4,6,8,11,15: " + " ".join(
        f"{u[int(round(xq/15*(nx-1))), j]:+.4f}" for xq in (1, 2, 4, 6, 8, 11, 15)))
    print("  flux profile x=0,1,2,4,6,8,11,15:  " + " ".join(
        f"{flux[int(round(xq/15*(nx-1)))]:+.5f}" for xq in (0, 1, 2, 4, 6, 8, 11, 15)))

print("\nDIAG OK")
