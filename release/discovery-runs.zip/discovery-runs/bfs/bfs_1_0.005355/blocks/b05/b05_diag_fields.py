"""Diagnostic: structure + residual decomposition of every field b05 saved.

Runs free on CPU from the saved .pkl files (registered once on GPU with
--diag so it carries an evals.jsonl record).  Answers two questions:

  1. Did any b05 candidate move the systematic upper-eddy bias that b04
     reported for every champion member (separation ~4.94-5.08 vs Gartling
     4.85, reattachment ~10.09-10.25 vs 10.48, bottom reattachment ~6.1)?
  2. Did the weak-norm candidate actually change the residual's *structure*
     -- element-mean residual relative to pointwise RMS -- or only its level?
"""
from __future__ import annotations

import os
import pickle
import sys
import types
from pathlib import Path

os.environ.setdefault("JAX_PLATFORMS", "cpu")

import numpy as np
import jax
import jax.numpy as jnp

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent

NU = 1.0 / 800.0
NX, NY = 481, 65
XS = np.linspace(0.0, 15.0, NX)
YS = np.linspace(-0.5, 0.5, NY)
NBX, NBY = 30, 4


def load(name):
    """exec a candidate module and return (predict_fn, params)."""
    src = (HERE / f"{name}.py").read_text()
    mod = types.ModuleType(f"_m_{name}")
    sys.modules[mod.__name__] = mod
    exec(compile(src, name, "exec"), mod.__dict__)
    with open(HERE / f"{name}.pkl", "rb") as f:
        params = pickle.load(f)
    return mod.__dict__["predict_fn"], params


def zero_crossings(x, f):
    """x where f changes sign (linear interpolation), ascending."""
    out = []
    for i in range(len(f) - 1):
        if f[i] == 0.0:
            out.append(x[i])
        elif f[i] * f[i + 1] < 0:
            t = f[i] / (f[i] - f[i + 1])
            out.append(x[i] + t * (x[i + 1] - x[i]))
    return out


def report(name):
    pf, params = load(name)
    X, Y = np.meshgrid(XS, YS)
    pts = jnp.asarray(np.stack([X.ravel(), Y.ravel()], 1).astype(np.float32))
    pr = pf(params, pts)
    u = np.asarray(pr["u"]).reshape(NY, NX)
    v = np.asarray(pr["v"]).reshape(NY, NX)

    # wall shear proxies: first interior row off each wall
    bot = zero_crossings(XS, u[1, :])
    top = zero_crossings(XS, u[-2, :])

    # residual on the interior, via autodiff of the candidate's own predict_fn
    def q_one(xy):
        d = pf(params, xy[None, :])
        return jnp.array([d["u"][0], d["v"][0], d["p"][0]])

    d1 = jax.jacfwd(q_one)
    d2 = jax.jacfwd(jax.jacfwd(q_one))

    def res(xy):
        q = q_one(xy)
        g = d1(xy)
        h = d2(xy)
        u_, v_ = q[0], q[1]
        r_mx = u_ * g[0, 0] + v_ * g[0, 1] + g[2, 0] - NU * (h[0, 0, 0] + h[0, 1, 1])
        r_my = u_ * g[1, 0] + v_ * g[1, 1] + g[2, 1] - NU * (h[1, 0, 0] + h[1, 1, 1])
        r_c = g[0, 0] + g[1, 1]
        return jnp.array([r_mx, r_my, r_c])

    sel = np.stack([X[1:-1, 1:].ravel(), Y[1:-1, 1:].ravel()], 1).astype(np.float32)
    R = np.asarray(jax.lax.map(res, jnp.asarray(sel)))          # [N, 3]

    bx = np.clip((sel[:, 0] - 0.0) / (15.0 / NBX), 0, NBX - 1e-6).astype(int)
    by = np.clip((sel[:, 1] + 0.5) / (1.0 / NBY), 0, NBY - 1e-6).astype(int)
    b = bx * NBY + by
    means = np.zeros((NBX * NBY, 3))
    cnt = np.bincount(b, minlength=NBX * NBY).astype(float)
    for k in range(3):
        means[:, k] = np.bincount(b, weights=R[:, k], minlength=NBX * NBY)
    means /= np.maximum(cnt, 1)[:, None]

    rms = np.sqrt((R ** 2).mean(0))
    mrms = np.sqrt((means ** 2).mean(0))
    flux = np.trapezoid(u, YS, axis=0)

    print(f"\n=== {name} ===")
    print(f"  u range [{u.min():+.3f}, {u.max():+.3f}]   v range "
          f"[{v.min():+.3f}, {v.max():+.3f}]")
    print(f"  bottom-wall u sign changes: {[round(z, 2) for z in bot][:4]}")
    print(f"  top-wall    u sign changes: {[round(z, 2) for z in top][:4]}")
    print(f"  mass flux   min/max {flux.min():.4f}/{flux.max():.4f} "
          f"(exact 0.5, drift {100 * (flux.max() - flux.min()) / 0.5:.2f}%)")
    print(f"  pointwise residual RMS   r_mx {rms[0]:.3e} r_my {rms[1]:.3e} "
          f"r_c {rms[2]:.3e}")
    print(f"  element-mean residual RMS r_mx {mrms[0]:.3e} r_my {mrms[1]:.3e} "
          f"r_c {mrms[2]:.3e}")
    print(f"  ratio (element-mean / pointwise) "
          f"{mrms[0] / rms[0]:.3f} {mrms[1] / rms[1]:.3f} {mrms[2] / rms[2]:.3f}")
    return u, v


if __name__ == "__main__":
    # default kept short so the GPU registration is cheap; the full
    # 7-field sweep reported in blocks/kb2/b05.md was run free on CPU as
    #   .venv/bin/python blocks/b05/b05_diag_fields.py b05_base b05_weak \
    #       b05_vs b05_wall b05_gauge b05_fo b05_lrf30
    names = sys.argv[1:] or ["b05_base", "b05_weak"]
    fields = {}
    for n in names:
        if (HERE / f"{n}.pkl").is_file():
            fields[n] = report(n)

    # cross-candidate scatter: how far apart are the different formulations?
    print("\n=== pairwise relative field distance on [u; v] ===")
    ks = list(fields)
    mat = np.zeros((len(ks), len(ks)))
    for i, a in enumerate(ks):
        for j, bn in enumerate(ks):
            qa = np.concatenate([fields[a][0].ravel(), fields[a][1].ravel()])
            qb = np.concatenate([fields[bn][0].ravel(), fields[bn][1].ravel()])
            mat[i, j] = np.linalg.norm(qa - qb) / np.linalg.norm(qb)
    print("        " + " ".join(f"{k[4:]:>8s}" for k in ks))
    for i, a in enumerate(ks):
        print(f"{a[4:]:>8s} " + " ".join(f"{mat[i, j]:8.4f}" for j in range(len(ks))))
    qm = np.mean([np.concatenate([fields[k][0].ravel(), fields[k][1].ravel()])
                  for k in ks], axis=0)
    d = [np.linalg.norm(np.concatenate([fields[k][0].ravel(),
                                        fields[k][1].ravel()]) - qm)
         / np.linalg.norm(qm) for k in ks]
    print(f"\nspread of the 7 formulations about their own mean: "
          f"{np.mean(d):.4f} (min {min(d):.4f}, max {max(d):.4f})")
