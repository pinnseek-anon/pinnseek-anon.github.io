"""Metric probe (not a solver): champion field composed with the piecewise-constant
x-displacement beta(x) that the 15 strip probes measured. Verifies how much of the
champion's error is a smooth coordinate distortion. Diagnostic instrument only —
its coefficients come from the metric, so it is never a candidate solution."""
from __future__ import annotations

# ═══════════════════════════════════════════════════════════════
# PDE CONSTANTS — DO NOT MODIFY (frozen header, byte-identical to parent)
# ═══════════════════════════════════════════════════════════════

# --- I/O shape ---
INPUT_DIM    = 2
OUTPUT_DIM   = 3
INPUT_NAMES  = ("x", "y")
FIELD_NAMES  = ("u", "v", "p")

# --- Domain (channel downstream of the step; step face = lower half of x=X_MIN) ---
X_MIN, X_MAX = 0.0, 15.0
Y_MIN, Y_MAX = -0.5, 0.5
HAS_TIME = False

# --- Equation structure ---
TIME_DERIV_ORDER        = 0
MAX_SPATIAL_DERIV_ORDER = 2
N_RESIDUAL_COMPONENTS   = 3   # ru, rv, continuity
HAS_SOURCE              = False

# --- Boundary topology ---
BOUNDARY_NAMES = ("inflow", "wall", "outflow")
PERIODIC_AXES  = ()
GEOMETRY_KIND  = "box"

# --- Physical parameters ---
RE     = 800.0       # NS-BFS Re=800 (channel height 1, mean inlet velocity 1)
NU     = 1.0 / RE
U_MAX  = 1.5         # peak of the parabolic inlet profile 24 y (0.5 - y)
H_STEP = 0.5         # step height = inlet height = half the channel

# --- Training budget ---
import os as _os, time as _time
_T0 = float(_os.environ.get("FORGE_T0", _time.time()))  # process-start wall anchor
TRAIN_TIME = 180.0     # total wall-clock seconds for the WHOLE process,
                       # from _T0: imports, JIT compile, training and param
                       # save all included — eval.py kills the process at
                       # this wall; return params with margin to spare
MAX_ITER   = 1_000_000 # safety cap on the loop (not expected to bind)

# --- Eval gate: full fidelity only under task/eval.py ---
if _os.environ.get("FORGE_EVAL_TOKEN") != "task/eval.py":
    TRAIN_TIME = 10.0                                # off-eval runs are smoke:
    _os.environ.setdefault("JAX_PLATFORMS", "cpu")   # CPU, 10 s
# ═══════════════════════════════════════════════════════════════

from typing import Any, Callable
import pickle, sys, types

import jax
import jax.numpy as jnp
import numpy as np

_m = types.ModuleType("_forge_probe_src__")
sys.modules["_forge_probe_src__"] = _m
with open("~/PINNSeek/blocks/b09/b09_base.py", "r", encoding="utf-8") as _f:
    exec(compile(_f.read(), "<probe-src>", "exec"), _m.__dict__)
_bp = _m.__dict__["predict_fn"]

BETA = jnp.array([0.0786, 0.0181, -0.0443, -0.0491, -0.0204, 0.0070, 0.0569,
                  -0.1500, -0.2049, -0.1891, -0.1646, -0.0951, -0.0784, -0.1499, -0.0910])
SCALE = 1.0


def _field(params, X):
    d = _bp(params, X)
    return jnp.stack([d["u"], d["v"], d["p"]], axis=-1)


def predict_fn(params, X):
    X = jnp.asarray(X)
    out = _field(params, X)
    ex = jnp.zeros_like(X).at[:, 0].set(1.0)
    _, dd = jax.jvp(lambda z: _field(params, z), (X,), (ex,))
    b = BETA[jnp.clip(jnp.floor(X[:, 0]).astype(jnp.int32), 0, 14)] * SCALE
    return {"u": out[:, 0] + b * dd[:, 0], "v": out[:, 1] + b * dd[:, 1], "p": out[:, 2]}


def train(rng, eval_callback: Callable[[Any, int, float], None] | None = None):
    """No training: loads the frozen champion params. Diagnostic only."""
    with open("~/PINNSeek/blocks/b09/b09_base.pkl", "rb") as f:
        return pickle.load(f), 1
