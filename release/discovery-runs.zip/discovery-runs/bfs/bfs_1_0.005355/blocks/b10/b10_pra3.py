"""Metric probe (not a solver): champion field b09_base + a known perturbation
delta. Its rRMSE yields one inner product <e_champ, delta> — one linear
functional of the reference, used as a diagnostic only, never as data.
Mode scale on x in [5.0, 8.0), amplitude 0.03686."""
from __future__ import annotations

# ═══════════════════════════════════════════════════════════════
# PDE CONSTANTS — DO NOT MODIFY (frozen header, byte-identical to parent)
# ═══════════════════════════════════════════════════════════════

# --- I/O shape ---
INPUT_DIM    = 2
OUTPUT_DIM   = 3
INPUT_NAMES  = ("x", "y")
FIELD_NAMES  = ("u", "v", "p")

# --- Domain (channel downstream of the step; step face = lower half of x=X_MIN) ---
X_MIN, X_MAX = 0.0, 15.0
Y_MIN, Y_MAX = -0.5, 0.5
HAS_TIME = False

# --- Equation structure ---
TIME_DERIV_ORDER        = 0
MAX_SPATIAL_DERIV_ORDER = 2
N_RESIDUAL_COMPONENTS   = 3   # ru, rv, continuity
HAS_SOURCE              = False

# --- Boundary topology ---
BOUNDARY_NAMES = ("inflow", "wall", "outflow")
PERIODIC_AXES  = ()
GEOMETRY_KIND  = "box"

# --- Physical parameters ---
RE     = 800.0       # NS-BFS Re=800 (channel height 1, mean inlet velocity 1)
NU     = 1.0 / RE
U_MAX  = 1.5         # peak of the parabolic inlet profile 24 y (0.5 - y)
H_STEP = 0.5         # step height = inlet height = half the channel

# --- Training budget ---
import os as _os, time as _time
_T0 = float(_os.environ.get("FORGE_T0", _time.time()))  # process-start wall anchor
TRAIN_TIME = 180.0     # total wall-clock seconds for the WHOLE process,
                       # from _T0: imports, JIT compile, training and param
                       # save all included — eval.py kills the process at
                       # this wall; return params with margin to spare
MAX_ITER   = 1_000_000 # safety cap on the loop (not expected to bind)

# --- Eval gate: full fidelity only under task/eval.py ---
if _os.environ.get("FORGE_EVAL_TOKEN") != "task/eval.py":
    TRAIN_TIME = 10.0                                # off-eval runs are smoke:
    _os.environ.setdefault("JAX_PLATFORMS", "cpu")   # CPU, 10 s
# ═══════════════════════════════════════════════════════════════

from typing import Any, Callable
import pickle

import jax
import jax.numpy as jnp
import numpy as np
from flax import linen as nn

_XC = 0.5 * (X_MIN + X_MAX)
_XS = 0.5 * (X_MAX - X_MIN)
_YC = 0.5 * (Y_MIN + Y_MAX)
_YS = 0.5 * (Y_MAX - Y_MIN)


def _normalize(xy):
    return jnp.stack([(xy[..., 0] - _XC) / _XS,
                      (xy[..., 1] - _YC) / _YS], axis=-1)


class PINN(nn.Module):
    hidden_width: int = 100
    n_hidden_layers: int = 5

    @nn.compact
    def __call__(self, xy):
        kinit = jax.nn.initializers.he_uniform()
        h = _normalize(xy)
        for _ in range(self.n_hidden_layers):
            h = nn.Dense(self.hidden_width, kernel_init=kinit)(h)
            h = nn.tanh(h)
        return nn.Dense(OUTPUT_DIM, kernel_init=kinit)(h)


L_IN = 0.25


def _U_in(y):
    return jnp.where(y > 0.0, 24.0 * y * (0.5 - y), 0.0)


def _ansatz(raw, xy):
    x, y = xy[..., 0], xy[..., 1]
    s = jnp.tanh(x / L_IN)
    w = 1.0 - 4.0 * y * y
    ws = w * s
    return jnp.stack([_U_in(y) * (1.0 - s) + ws * raw[..., 0],
                      ws * raw[..., 1],
                      raw[..., 2]], axis=-1)


_SRC = "~/PINNSeek/blocks/b09/b09_base.pkl"
MODE = "scale"
XLO, XHI, AMP = 5.0, 8.0, 0.03686

_PREDICT_MODEL = PINN()


def _field(params, X):
    return _ansatz(_PREDICT_MODEL.apply(params, X), X)


def predict_fn(params, X):
    X = jnp.asarray(X)
    out = _field(params, X)
    x = X[:, 0]
    m = ((x >= XLO) & (x < XHI)).astype(out.dtype)[:, None]
    if MODE == "scale":
        d = AMP * m * out
    elif MODE == "scaleu":
        d = AMP * m * out * jnp.array([1.0, 0.0, 0.0])
    elif MODE == "scalev":
        d = AMP * m * out * jnp.array([0.0, 1.0, 0.0])
    elif MODE == "shiftx":
        ex = jnp.zeros_like(X).at[:, 0].set(1.0)
        _, dd = jax.jvp(lambda z: _field(params, z), (X,), (ex,))
        d = AMP * m * dd
    elif MODE == "shifty":
        ey = jnp.zeros_like(X).at[:, 1].set(1.0)
        _, dd = jax.jvp(lambda z: _field(params, z), (X,), (ey,))
        d = AMP * m * dd
    else:
        raise ValueError(MODE)
    return {"u": out[:, 0] + d[:, 0], "v": out[:, 1] + d[:, 1], "p": out[:, 2]}


def train(rng, eval_callback: Callable[[Any, int, float], None] | None = None):
    """No training: loads the frozen champion params so the eval measures the
    perturbed field. Diagnostic instrument only."""
    with open(_SRC, "rb") as f:
        params = pickle.load(f)
    return params, 1
