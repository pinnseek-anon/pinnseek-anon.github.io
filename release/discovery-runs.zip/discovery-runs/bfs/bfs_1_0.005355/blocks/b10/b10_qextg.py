"""Metric probe (not a solver): a saved field from an earlier block plus a known
perturbation delta. Its rRMSE yields one inner product <e, delta> — a single
linear functional of the reference, used as a diagnostic only, never as data.
Source n900; mode scale on x in [0.0, 15.1), amplitude 0.02."""
from __future__ import annotations

# ═══════════════════════════════════════════════════════════════
# PDE CONSTANTS — DO NOT MODIFY (frozen header, byte-identical to parent)
# ═══════════════════════════════════════════════════════════════

# --- I/O shape ---
INPUT_DIM    = 2
OUTPUT_DIM   = 3
INPUT_NAMES  = ("x", "y")
FIELD_NAMES  = ("u", "v", "p")

# --- Domain (channel downstream of the step; step face = lower half of x=X_MIN) ---
X_MIN, X_MAX = 0.0, 15.0
Y_MIN, Y_MAX = -0.5, 0.5
HAS_TIME = False

# --- Equation structure ---
TIME_DERIV_ORDER        = 0
MAX_SPATIAL_DERIV_ORDER = 2
N_RESIDUAL_COMPONENTS   = 3   # ru, rv, continuity
HAS_SOURCE              = False

# --- Boundary topology ---
BOUNDARY_NAMES = ("inflow", "wall", "outflow")
PERIODIC_AXES  = ()
GEOMETRY_KIND  = "box"

# --- Physical parameters ---
RE     = 800.0       # NS-BFS Re=800 (channel height 1, mean inlet velocity 1)
NU     = 1.0 / RE
U_MAX  = 1.5         # peak of the parabolic inlet profile 24 y (0.5 - y)
H_STEP = 0.5         # step height = inlet height = half the channel

# --- Training budget ---
import os as _os, time as _time
_T0 = float(_os.environ.get("FORGE_T0", _time.time()))  # process-start wall anchor
TRAIN_TIME = 180.0     # total wall-clock seconds for the WHOLE process,
                       # from _T0: imports, JIT compile, training and param
                       # save all included — eval.py kills the process at
                       # this wall; return params with margin to spare
MAX_ITER   = 1_000_000 # safety cap on the loop (not expected to bind)

# --- Eval gate: full fidelity only under task/eval.py ---
if _os.environ.get("FORGE_EVAL_TOKEN") != "task/eval.py":
    TRAIN_TIME = 10.0                                # off-eval runs are smoke:
    _os.environ.setdefault("JAX_PLATFORMS", "cpu")   # CPU, 10 s
# ═══════════════════════════════════════════════════════════════

from typing import Any, Callable
import pickle, sys, types

import jax
import jax.numpy as jnp

_SRC_PY  = "~/PINNSeek/blocks/b04/b04_ext.py"
_SRC_PKL = "~/PINNSeek/blocks/b04/b04_ext.pkl"
MODE = "scale"
XLO, XHI, AMP = 0.0, 15.1, 0.02

_m = types.ModuleType("_forge_probe_src__")
sys.modules["_forge_probe_src__"] = _m
with open(_SRC_PY, "r", encoding="utf-8") as _f:
    exec(compile(_f.read(), "<probe-src>", "exec"), _m.__dict__)
_base_predict = _m.__dict__["predict_fn"]


def _field(params, X):
    d = _base_predict(params, X)
    return jnp.stack([d["u"], d["v"], d["p"]], axis=-1)


def predict_fn(params, X):
    X = jnp.asarray(X)
    out = _field(params, X)
    x = X[:, 0]
    m = ((x >= XLO) & (x < XHI)).astype(out.dtype)[:, None]
    if MODE == "scale":
        d = AMP * m * out
    elif MODE == "shiftx":
        ex = jnp.zeros_like(X).at[:, 0].set(1.0)
        _, dd = jax.jvp(lambda z: _field(params, z), (X,), (ex,))
        d = AMP * m * dd
    else:
        raise ValueError(MODE)
    return {"u": out[:, 0] + d[:, 0], "v": out[:, 1] + d[:, 1], "p": out[:, 2]}


def train(rng, eval_callback: Callable[[Any, int, float], None] | None = None):
    """No training: loads frozen params from an earlier block so the eval
    measures the perturbed field. Diagnostic instrument only."""
    with open(_SRC_PKL, "rb") as f:
        params = pickle.load(f)
    return params, 1
