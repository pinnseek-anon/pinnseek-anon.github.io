"""Metric probe (not a solver): champion march snapshots linearly extrapolated
in parameter space, p = pA + LAM * (pA - pB). Tests whether the pseudo-time
march's limit is better than its 110k-step endpoint. Diagnostic instrument.
LAM = 4.0, A = b08_base, B = b08_n900."""
from __future__ import annotations

# ═══════════════════════════════════════════════════════════════
# PDE CONSTANTS — DO NOT MODIFY (frozen header, byte-identical to parent)
# ═══════════════════════════════════════════════════════════════

# --- I/O shape ---
INPUT_DIM    = 2
OUTPUT_DIM   = 3
INPUT_NAMES  = ("x", "y")
FIELD_NAMES  = ("u", "v", "p")

# --- Domain (channel downstream of the step; step face = lower half of x=X_MIN) ---
X_MIN, X_MAX = 0.0, 15.0
Y_MIN, Y_MAX = -0.5, 0.5
HAS_TIME = False

# --- Equation structure ---
TIME_DERIV_ORDER        = 0
MAX_SPATIAL_DERIV_ORDER = 2
N_RESIDUAL_COMPONENTS   = 3   # ru, rv, continuity
HAS_SOURCE              = False

# --- Boundary topology ---
BOUNDARY_NAMES = ("inflow", "wall", "outflow")
PERIODIC_AXES  = ()
GEOMETRY_KIND  = "box"

# --- Physical parameters ---
RE     = 800.0       # NS-BFS Re=800 (channel height 1, mean inlet velocity 1)
NU     = 1.0 / RE
U_MAX  = 1.5         # peak of the parabolic inlet profile 24 y (0.5 - y)
H_STEP = 0.5         # step height = inlet height = half the channel

# --- Training budget ---
import os as _os, time as _time
_T0 = float(_os.environ.get("FORGE_T0", _time.time()))  # process-start wall anchor
TRAIN_TIME = 180.0     # total wall-clock seconds for the WHOLE process,
                       # from _T0: imports, JIT compile, training and param
                       # save all included — eval.py kills the process at
                       # this wall; return params with margin to spare
MAX_ITER   = 1_000_000 # safety cap on the loop (not expected to bind)

# --- Eval gate: full fidelity only under task/eval.py ---
if _os.environ.get("FORGE_EVAL_TOKEN") != "task/eval.py":
    TRAIN_TIME = 10.0                                # off-eval runs are smoke:
    _os.environ.setdefault("JAX_PLATFORMS", "cpu")   # CPU, 10 s
# ═══════════════════════════════════════════════════════════════

from typing import Any, Callable
import pickle, sys, types

import jax
import jax.numpy as jnp

_A = "~/PINNSeek/blocks/b08/b08_base.pkl"
_B = "~/PINNSeek/blocks/b08/b08_n900.pkl"
LAM = 4.0

_m = types.ModuleType("_forge_probe_src__")
sys.modules["_forge_probe_src__"] = _m
with open("~/PINNSeek/blocks/b09/b09_base.py", "r", encoding="utf-8") as _f:
    exec(compile(_f.read(), "<probe-src>", "exec"), _m.__dict__)
predict_fn = _m.__dict__["predict_fn"]


def train(rng, eval_callback: Callable[[Any, int, float], None] | None = None):
    """No training: linear combination of two saved march snapshots."""
    with open(_A, "rb") as f:
        pa = pickle.load(f)
    with open(_B, "rb") as f:
        pb = pickle.load(f)
    out = jax.tree_util.tree_map(lambda a, b: a + LAM * (a - b), pa, pb)
    return out, 1
