"""Is this recipe optimiser-limited or formulation-limited?

SOAP reached a ~9x lower pseudo-time loss than Adam at 0.7x the steps yet
scored the same (0.0193 vs 0.0198 mean). This measures the steady NS residual
RMS of each trained field on the full grid, together with the structural
markers, so "lower residual, same/worse rRMSE" can be read directly: if the
residual falls and the score does not, the fixed point of the formulation --
not the optimiser -- is the error floor. Free on CPU.
"""
from __future__ import annotations

import pickle
import sys
from pathlib import Path

import numpy as np
import jax
import jax.numpy as jnp

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

NU = 1.0 / 800.0
NX, NY = 481, 65
XS = np.linspace(0.0, 15.0, NX)
YS = np.linspace(-0.5, 0.5, NY)

CASES = [
    ("b02_dt10  s0 (Adam, 0.0146)", "blocks/b02/b02_dt10.py", "blocks/b02/b02_dt10.pkl"),
    ("b03_base  s1 (Adam, 0.0196)", "blocks/b03/b03_base.py", "blocks/b03/b03_base_s1.pkl"),
    ("b04_soap  s0 (SOAP, 0.0193)", "blocks/b04/b04_soap.py", "blocks/b04/b04_soap.pkl"),
    ("b04_soap  s1 (SOAP, 0.5013)", "blocks/b04/b04_soap.py", "blocks/b04/b04_soap_s1.pkl"),
    ("b04_sdt05 s0 (SOAP, 0.0458)", "blocks/b04/b04_sdt05.py", "blocks/b04/b04_sdt05.pkl"),
]


def load(path: Path, tag: str):
    import types
    mod = types.ModuleType(tag)
    sys.modules[tag] = mod
    exec(compile(path.read_text(), str(path), "exec"), mod.__dict__)
    return mod


def residual_fn(mod, params):
    ex, ey = jnp.array([1.0, 0.0]), jnp.array([0.0, 1.0])

    def qvec(xy):
        d = mod.predict_fn(params, xy[None, :])
        return jnp.stack([d["u"][0], d["v"][0], d["p"][0]])

    def dir2(xy, e):
        (q, d1), (_, d2) = jax.jvp(lambda z: jax.jvp(qvec, (z,), (e,)), (xy,), (e,))
        return q, d1, d2

    def res(xy):
        q, dx, dxx = dir2(xy, ex)
        _, dy, dyy = dir2(xy, ey)
        u, v = q[0], q[1]
        return jnp.stack([
            u * dx[0] + v * dy[0] + dx[2] - NU * (dxx[0] + dyy[0]),
            u * dx[1] + v * dy[1] + dy[2] - NU * (dxx[1] + dyy[1]),
            dx[0] + dy[1]])

    return jax.jit(jax.vmap(res))


def zero_cross(xs, f):
    s = np.sign(f)
    out = []
    for i in np.where(np.diff(s) != 0)[0]:
        a, b = f[i], f[i + 1]
        if b != a:
            out.append(round(float(xs[i] + (xs[i + 1] - xs[i]) * (-a) / (b - a)), 2))
    return out


def main():
    Xg, Yg = np.meshgrid(XS, YS, indexing="ij")
    full = np.stack([Xg.ravel(), Yg.ravel()], 1).astype(np.float32)
    interior = full[(full[:, 0] > 0) & (np.abs(full[:, 1]) < 0.5)]

    print(f"{'case':30s} {'r_mx':>9s} {'r_my':>9s} {'r_c':>9s} {'flux drift':>11s}"
          f"  bottom reattach / upper eddy")
    for name, py, pk in CASES:
        mod = load(ROOT / py, f"_{Path(pk).stem}_")
        with open(ROOT / pk, "rb") as f:
            params = pickle.load(f)
        r = np.asarray(residual_fn(mod, params)(jnp.asarray(interior)))
        rms = np.sqrt(np.mean(r ** 2, 0))
        out = mod.predict_fn(params, jnp.asarray(full))
        U = np.asarray(out["u"]).reshape(NX, NY)
        flux = np.trapezoid(U, YS, axis=1)
        tb = (U[:, 1] - U[:, 0]) / (YS[1] - YS[0])
        tt = -(U[:, -1] - U[:, -2]) / (YS[-1] - YS[-2])
        print(f"{name:30s} {rms[0]:9.3e} {rms[1]:9.3e} {rms[2]:9.3e} "
              f"{100*(flux.max()-flux.min())/0.5:10.2f}%  "
              f"{str(zero_cross(XS, tb)):22s} {zero_cross(XS, tt)}")

    print("\nGartling Re=800: bottom reattach 6.10, upper eddy 4.85-10.48")

    # --- pairwise relative field distance between the two "good" fields ---
    fields = {}
    for name, py, pk in CASES[:3]:
        mod = load(ROOT / py, f"_f{Path(pk).stem}_")
        with open(ROOT / pk, "rb") as f:
            params = pickle.load(f)
        o = mod.predict_fn(params, jnp.asarray(full))
        fields[name] = (np.asarray(o["u"]), np.asarray(o["v"]))
    keys = list(fields)
    print("\npairwise relative L2 distance between fields:")
    for i in range(len(keys)):
        for j in range(i + 1, len(keys)):
            a, b = fields[keys[i]], fields[keys[j]]
            d = np.sqrt(np.sum((a[0]-b[0])**2 + (a[1]-b[1])**2))
            n = np.sqrt(np.sum(a[0]**2 + a[1]**2))
            print(f"  {keys[i][:13]} vs {keys[j][:13]}: {d/n:.4f}")

    # --- per-x-band residual: is the remaining residual localised? ---
    edges = [0.0, 0.25, 0.5, 1.0, 2.0, 4.0, 8.0, 12.0, 14.5, 15.0]
    print("\nper-band r_mx / r_c RMS")
    print(f"{'band':16s} " + "  ".join(f"{n[:13]:>27s}" for n, _, _ in CASES[:3]))
    rr = []
    for name, py, pk in CASES[:3]:
        mod = load(ROOT / py, f"_b{Path(pk).stem}_")
        with open(ROOT / pk, "rb") as f:
            params = pickle.load(f)
        rr.append(np.asarray(residual_fn(mod, params)(jnp.asarray(interior))))
    for a, b in zip(edges[:-1], edges[1:]):
        m = (interior[:, 0] > a) & (interior[:, 0] <= b)
        cells = "  ".join(f"{np.sqrt(np.mean(r[m,0]**2)):12.3e}"
                          f"{np.sqrt(np.mean(r[m,2]**2)):15.3e}" for r in rr)
        print(f"[{a:5.2f},{b:6.2f}]  {cells}")

    # --- outflow behaviour: how far from a developed / do-nothing state? ---
    print("\n  x     du/dx RMS (over y)   for the three fields")
    for xv in (10.0, 12.0, 13.0, 14.0, 14.75, 15.0):
        row = []
        for name, py, pk in CASES[:3]:
            mod = load(ROOT / py, f"_o{Path(pk).stem}_")
            with open(ROOT / pk, "rb") as f:
                params = pickle.load(f)
            yq = np.linspace(-0.49, 0.49, 65)
            h = 1e-3
            p1 = np.stack([np.full_like(yq, xv - h), yq], 1).astype(np.float32)
            p2 = np.stack([np.full_like(yq, min(xv + h, 15.0)), yq], 1).astype(np.float32)
            u1 = np.asarray(mod.predict_fn(params, jnp.asarray(p1))["u"])
            u2 = np.asarray(mod.predict_fn(params, jnp.asarray(p2))["u"])
            row.append(np.sqrt(np.mean(((u2 - u1) / (p2[0, 0] - p1[0, 0])) ** 2)))
        print(f"{xv:6.2f}   " + "  ".join(f"{v:10.4f}" for v in row))


if __name__ == "__main__":
    main()
