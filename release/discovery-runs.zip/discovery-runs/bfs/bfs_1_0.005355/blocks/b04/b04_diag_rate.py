"""Rate probes. (1) SOAP vs the parent's Adam -- b02 priced a pytree SOAP at
69 steps/s, this measures a scan-fused version. (2) The joint ensemble: how
many steps does an M-member vmap'd run give up, given the single-model step at
BS 2048 is far from saturating an A6000?  Both report the pseudo-time loss
after 1500 steps so the rate is readable against progress.
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

import jax
import jax.numpy as jnp
from jax import random

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

N_CHUNKS = 15   # 1500 steps after the compile chunk
MODE = sys.argv[1] if len(sys.argv) > 1 else "ens"


def load(path: Path, tag: str):
    import types
    mod = types.ModuleType(tag)
    sys.modules[tag] = mod
    exec(compile(path.read_text(), str(path), "exec"), mod.__dict__)
    return mod


def time_adam(mod, tag):
    key = random.PRNGKey(0)
    t_c0 = time.time()
    p, o, run_chunk, _unravel, rng = mod._make_train(key)
    ema = p
    rng, k = random.split(rng)
    p, o, ema, loss = run_chunk(p, o, ema, k)
    float(loss)
    t_compile = time.time() - t_c0
    t0 = time.time()
    for _ in range(N_CHUNKS):
        rng, k = random.split(rng)
        p, o, ema, loss = run_chunk(p, o, ema, k)
    loss = float(loss)
    dt = time.time() - t0
    n = N_CHUNKS * mod.CHUNK
    print(f"{tag:22s} compile {t_compile:6.2f}s  {n/dt:7.1f} steps/s  "
          f"-> {int(168*n/dt/1000)}k steps in 180s   loss {loss:.4e}")


def time_soap(mod, freq, tag):
    mod.SOAP_FREQ = freq
    key = random.PRNGKey(0)
    t_c0 = time.time()
    p, st, run_chunk, rng = mod._make_train(key)
    ema = p
    t = jnp.int32(0)
    rng, k = random.split(rng)
    p, st, ema, t, loss = run_chunk(p, st, ema, t, k)
    float(loss)
    t_compile = time.time() - t_c0
    t0 = time.time()
    for _ in range(N_CHUNKS):
        rng, k = random.split(rng)
        p, st, ema, t, loss = run_chunk(p, st, ema, t, k)
    loss = float(loss)
    dt = time.time() - t0
    n = N_CHUNKS * mod.CHUNK
    print(f"{tag:22s} compile {t_compile:6.2f}s  {n/dt:7.1f} steps/s  "
          f"-> {int(168*n/dt/1000)}k steps in 180s   loss {loss:.4e}")


def main():
    print("device:", jax.devices()[0])
    if MODE == "soap":
        time_adam(load(ROOT / "blocks/b03/b03_base.py", "_base_"), "Adam (parent)")
        soap = load(ROOT / "blocks/b04/b04_soap.py", "_soap_")
        for freq in (10, 25, 100):
            time_soap(soap, freq, f"SOAP freq={freq}")
    else:
        time_adam(load(ROOT / "blocks/b04/b04_ext.py", "_ext_"), "b04_ext (M=1)")
        for m in (2, 4, 8, 16):
            ens = load(ROOT / "blocks/b04/b04_ens.py", f"_ens{m}_")
            ens.ENS_M = m
            time_adam(ens, f"b04_ens M={m}")


if __name__ == "__main__":
    main()
