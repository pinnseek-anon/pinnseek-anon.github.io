"""Diagnostic: what is the 0.0148 shared bias of the b02/b03 champion recipe?

Loads the five saved champion-recipe fields (b02_dt10 seed 0 + b03_base seeds
1-4), builds the ensemble mean, and reports (a) physically meaningful structure
per member and for the mean -- bottom reattachment, upper-eddy extent, peak
reverse-flow speed -- against Gartling's Re=800 benchmark (6.10; 4.85-10.48),
and (b) the member-to-mean scatter split by region and by field magnitude.

The question: is the shared error a *magnitude* deficit in the weak
recirculating flow (an optimiser/spectral-bias signature, kb1/088, kb1/108) or
a structural/positional defect?  Runs free on CPU; registered once via --diag.
"""
from __future__ import annotations

import pickle
import sys
from pathlib import Path

import numpy as np
import jax
import jax.numpy as jnp

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

NU = 1.0 / 800.0
X_MIN, X_MAX = 0.0, 15.0
Y_MIN, Y_MAX = -0.5, 0.5
NX, NY = 481, 65

MEMBERS = [
    ("b02_dt10   s0", "blocks/b02/b02_dt10.py", "blocks/b02/b02_dt10.pkl"),
    ("b03_base   s1", "blocks/b03/b03_base.py", "blocks/b03/b03_base_s1.pkl"),
    ("b03_base   s2", "blocks/b03/b03_base.py", "blocks/b03/b03_base_s2.pkl"),
    ("b03_base   s3", "blocks/b03/b03_base.py", "blocks/b03/b03_base_s3.pkl"),
    ("b03_base   s4", "blocks/b03/b03_base.py", "blocks/b03/b03_base_s4.pkl"),
]


def load_module(path: Path, tag: str):
    import types
    mod = types.ModuleType(tag)
    sys.modules[tag] = mod
    exec(compile(path.read_text(), str(path), "exec"), mod.__dict__)
    return mod


def field(mod, params, pts):
    out = mod.predict_fn(params, jnp.asarray(pts))
    return (np.asarray(out["u"]).reshape(NX, NY),
            np.asarray(out["v"]).reshape(NX, NY))


def zero_cross(xs, f):
    """x locations where f changes sign, linearly interpolated."""
    s = np.sign(f)
    idx = np.where(np.diff(s) != 0)[0]
    out = []
    for i in idx:
        a, b = f[i], f[i + 1]
        if b == a:
            continue
        out.append(float(xs[i] + (xs[i + 1] - xs[i]) * (-a) / (b - a)))
    return out


def structure(U, xs, ys):
    """Wall-shear sign changes -> separation / reattachment stations."""
    tb = (U[:, 1] - U[:, 0]) / (ys[1] - ys[0])            # bottom wall du/dy
    tt = (U[:, -1] - U[:, -2]) / (ys[-1] - ys[-2])         # top wall du/dy
    return zero_cross(xs, tb), zero_cross(xs, -tt)


def main():
    xs = np.linspace(X_MIN, X_MAX, NX)
    ys = np.linspace(Y_MIN, Y_MAX, NY)
    Xg, Yg = np.meshgrid(xs, ys, indexing="ij")
    pts = np.stack([Xg.ravel(), Yg.ravel()], 1).astype(np.float32)

    Us, Vs = [], []
    print("member          bottom reattach      upper eddy (sep, reattach)   "
          "min u    max|v|")
    for i, (name, py, pk) in enumerate(MEMBERS):
        mod = load_module(ROOT / py, f"_m{i}_")
        with open(ROOT / pk, "rb") as f:
            params = pickle.load(f)
        U, V = field(mod, params, pts)
        Us.append(U)
        Vs.append(V)
        b, t = structure(U, xs, ys)
        print(f"{name}  {str([round(z,3) for z in b]):20s} "
              f"{str([round(z,3) for z in t]):28s} "
              f"{U.min():8.4f} {np.abs(V).max():7.4f}")

    Um = np.mean(Us, 0)
    Vm = np.mean(Vs, 0)
    b, t = structure(Um, xs, ys)
    print(f"{'ENSEMBLE MEAN':14s}  {str([round(z,3) for z in b]):20s} "
          f"{str([round(z,3) for z in t]):28s} {Um.min():8.4f} "
          f"{np.abs(Vm).max():7.4f}")
    print("Gartling Re=800 benchmark: bottom 6.10, upper eddy 4.85-10.48\n")

    # --- scatter of members about the mean, split by region ---
    den = np.sqrt(np.sum(Um ** 2 + Vm ** 2))
    dev = np.sqrt(np.mean([np.sum((U - Um) ** 2 + (V - Vm) ** 2)
                           for U, V in zip(Us, Vs)]))
    print(f"member-to-mean relative scatter: {dev/den:.4f}")

    edges = [0.0, 1.0, 2.0, 4.0, 6.0, 8.0, 11.0, 15.0]
    print("\nband        share of ||q||^2   scatter share   mean|u|   mean|v|")
    tot_q = np.sum(Um ** 2 + Vm ** 2)
    tot_d = np.sum([np.sum((U - Um) ** 2 + (V - Vm) ** 2) for U, V in zip(Us, Vs)])
    for a, bb in zip(edges[:-1], edges[1:]):
        m = (xs > a) & (xs <= bb)
        q = np.sum(Um[m] ** 2 + Vm[m] ** 2)
        d = np.sum([np.sum((U[m] - Um[m]) ** 2 + (V[m] - Vm[m]) ** 2)
                    for U, V in zip(Us, Vs)])
        print(f"[{a:4.1f},{bb:5.1f}]  {q/tot_q:14.4f}   {d/tot_d:13.4f}   "
              f"{np.abs(Um[m]).mean():7.4f}  {np.abs(Vm[m]).mean():7.4f}")

    # --- how much of the field lives in the weak recirculating flow? ---
    speed = np.sqrt(Um ** 2 + Vm ** 2)
    for thr in (0.05, 0.1, 0.2, 0.5):
        m = speed < thr
        d = np.sum([np.sum((U[m] - Um[m]) ** 2 + (V[m] - Vm[m]) ** 2)
                    for U, V in zip(Us, Vs)])
        print(f"|q| < {thr:4.2f}: {100*m.mean():5.1f}% of points, "
              f"{100*np.sum(Um[m]**2+Vm[m]**2)/tot_q:5.2f}% of ||q||^2, "
              f"{100*d/tot_d:5.2f}% of scatter")

    # --- reverse-flow bubble strength (the small-amplitude structure) ---
    print("\n  x     min u (bottom bubble)   u at y=-0.25   v at y=0")
    for xv in (0.5, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 9.0, 12.0):
        i = int(np.argmin(np.abs(xs - xv)))
        col = Um[i]
        print(f"{xv:5.1f}  {col.min():12.5f}          "
              f"{col[int(0.25*(NY-1))]:9.5f}   {Vm[i, (NY-1)//2]:9.5f}")


if __name__ == "__main__":
    main()
