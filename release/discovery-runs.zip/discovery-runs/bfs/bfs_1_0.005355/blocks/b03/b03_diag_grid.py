"""Diagnostic on b02's champion (b02_dt10.pkl): is the residual grid-fitted?

Compares the NS residual RMS on the 481x65 collocation grid the candidate was
trained on against the same statistics on cell *midpoints* (never seen during
training), plus per-x-band residual and mass-flux profiles.  Runs on CPU for
free; also registered once via `eval.py --diag`.
"""
from __future__ import annotations

import pickle
import sys
from pathlib import Path

import numpy as np
import jax
import jax.numpy as jnp

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

NU = 1.0 / 800.0
X_MIN, X_MAX = 0.0, 15.0
Y_MIN, Y_MAX = -0.5, 0.5


def load_module(path: Path):
    import types
    mod = types.ModuleType("_cand_")
    sys.modules["_cand_"] = mod
    exec(compile(path.read_text(), str(path), "exec"), mod.__dict__)
    return mod


def make_residual(mod, params):
    """(r_mx, r_my, r_c) at a single point, all derivatives by autodiff."""
    ex = jnp.array([1.0, 0.0])
    ey = jnp.array([0.0, 1.0])

    def q_of(xy):
        return mod.predict_fn(params, xy[None, :])

    def qvec(xy):
        d = q_of(xy)
        return jnp.stack([d["u"][0], d["v"][0], d["p"][0]])

    def dir2(xy, e):
        def inner(z):
            return jax.jvp(qvec, (z,), (e,))
        (q, d1), (_, d2) = jax.jvp(inner, (xy,), (e,))
        return q, d1, d2

    def res(xy):
        q, dx, dxx = dir2(xy, ex)
        _, dy, dyy = dir2(xy, ey)
        u, v = q[0], q[1]
        r_mx = u * dx[0] + v * dy[0] + dx[2] - NU * (dxx[0] + dyy[0])
        r_my = u * dx[1] + v * dy[1] + dy[2] - NU * (dxx[1] + dyy[1])
        r_c = dx[0] + dy[1]
        return jnp.stack([r_mx, r_my, r_c])

    return jax.jit(jax.vmap(res))


def rms(a):
    return float(np.sqrt(np.mean(np.asarray(a) ** 2)))


def main():
    tgt = sys.argv[1] if len(sys.argv) > 1 else "blocks/b02/b02_dt10.py"
    cand = ROOT / tgt
    pkl = cand.with_suffix(".pkl")
    print(f"=== {tgt} ===")
    mod = load_module(cand)
    with open(pkl, "rb") as f:
        params = pickle.load(f)

    res_fn = make_residual(mod, params)

    nx, ny = 481, 65
    xs = np.linspace(X_MIN, X_MAX, nx)
    ys = np.linspace(Y_MIN, Y_MAX, ny)

    # --- on-grid (training) interior points: x > 0, |y| < 0.5 ---
    Xg, Yg = np.meshgrid(xs[1:], ys[1:-1], indexing="ij")
    pts_on = np.stack([Xg.ravel(), Yg.ravel()], 1).astype(np.float32)

    # --- off-grid cell midpoints, same count/region ---
    xm = 0.5 * (xs[:-1] + xs[1:])
    ym = 0.5 * (ys[:-1] + ys[1:])
    Xm, Ym = np.meshgrid(xm, ym, indexing="ij")
    pts_off = np.stack([Xm.ravel(), Ym.ravel()], 1).astype(np.float32)

    for name, pts in (("ON-GRID ", pts_on), ("OFF-GRID", pts_off)):
        r = np.asarray(res_fn(jnp.asarray(pts)))
        print(f"{name}  N={len(pts):6d}  r_mx {rms(r[:, 0]):.3e}  "
              f"r_my {rms(r[:, 1]):.3e}  r_c {rms(r[:, 2]):.3e}")

    # --- per-x-band residual (on-grid) ---
    r_on = np.asarray(res_fn(jnp.asarray(pts_on)))
    r_off = np.asarray(res_fn(jnp.asarray(pts_off)))
    edges = [0.0, 0.5, 1.0, 2.0, 4.0, 7.0, 11.0, 15.0]
    print("\nband        n     r_mx(on)  r_mx(off)  r_c(on)   r_c(off)")
    for a, b in zip(edges[:-1], edges[1:]):
        m_on = (pts_on[:, 0] > a) & (pts_on[:, 0] <= b)
        m_off = (pts_off[:, 0] > a) & (pts_off[:, 0] <= b)
        print(f"[{a:4.1f},{b:5.1f}] {m_on.sum():6d}  {rms(r_on[m_on, 0]):.3e} "
              f"{rms(r_off[m_off, 0]):.3e}  {rms(r_on[m_on, 2]):.3e} "
              f"{rms(r_off[m_off, 2]):.3e}")

    # --- fine near-inlet x-profile: does the lift inject divergence at x=0? ---
    xf = np.array([0.002, 0.01, 0.02, 0.05, 0.1, 0.15, 0.2, 0.3, 0.4, 0.6, 1.0])
    yq = np.linspace(-0.49, 0.49, 97)
    print("\n   x     r_mx      r_my      r_c       |div| max")
    for xv in xf:
        pq = np.stack([np.full_like(yq, xv), yq], 1).astype(np.float32)
        rq = np.asarray(res_fn(jnp.asarray(pq)))
        print(f"{xv:6.3f}  {rms(rq[:,0]):.3e} {rms(rq[:,1]):.3e} "
              f"{rms(rq[:,2]):.3e}  {np.abs(rq[:,2]).max():.3e}")

    # --- mass flux profile ---
    Xf, Yf = np.meshgrid(xs, ys, indexing="ij")
    pf = np.stack([Xf.ravel(), Yf.ravel()], 1).astype(np.float32)
    out = mod.predict_fn(params, jnp.asarray(pf))
    U = np.asarray(out["u"]).reshape(nx, ny)
    V = np.asarray(out["v"]).reshape(nx, ny)
    flux = np.trapezoid(U, ys, axis=1)
    print(f"\nmass flux  min {flux.min():.4f}  max {flux.max():.4f}  "
          f"(exact 0.5)  drift {100*(flux.max()-flux.min())/0.5:.2f}%")
    print(f"u range [{U.min():.4f}, {U.max():.4f}]   "
          f"v range [{V.min():.4f}, {V.max():.4f}]")

    # --- separation structure from wall shear ---
    for wall, j, lab in ((Y_MIN, 1, "bottom"), (Y_MAX, ny - 2, "top")):
        du = (U[:, j] - U[:, 0 if wall == Y_MIN else ny - 1]) / (ys[j] - wall)
        sgn = np.sign(du)
        cross = np.where(np.diff(sgn) != 0)[0]
        print(f"{lab} wall shear sign changes at x = "
              f"{[round(float(xs[c]), 2) for c in cross]}")


if __name__ == "__main__":
    main()
