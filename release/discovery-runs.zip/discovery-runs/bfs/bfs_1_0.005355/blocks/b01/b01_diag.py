"""Diagnostic (not a candidate): dissect a trained b01 field.

Target selected by the CAND_STEM constant below.

Reports BC satisfaction, mass-flux conservation along x, recirculation
structure, per-component residual RMS binned in x, and the gradient-norm
ratio between the PDE and BC loss terms (kb1/050 Algorithm 1) so the
fixed lambda_bc = 100 can be judged.
"""
import pickle
import sys
import types
from pathlib import Path

import jax
import jax.numpy as jnp
import numpy as np
from jax import jacfwd, vmap

CAND_STEM = "b01_pts"
ROOT = Path(__file__).resolve().parents[2]
CAND = ROOT / "blocks" / "b01" / f"{CAND_STEM}.py"
PKL = ROOT / "blocks" / "b01" / f"{CAND_STEM}.pkl"
print(f"target: {CAND_STEM}")

mod = types.ModuleType("_diag_cand__")
sys.modules["_diag_cand__"] = mod
exec(compile(CAND.read_text(encoding="utf-8"), "<cand>", "exec"), mod.__dict__)

with open(PKL, "rb") as f:
    params = pickle.load(f)

NU = mod.NU
predict_fn = mod.predict_fn

nx, ny = 481, 65
xs = np.linspace(0.0, 15.0, nx)
ys = np.linspace(-0.5, 0.5, ny)
Xg, Yg = np.meshgrid(xs, ys, indexing="ij")          # [nx, ny]
pts = np.stack([Xg.ravel(), Yg.ravel()], axis=1).astype(np.float32)

out = predict_fn(params, jnp.asarray(pts))
u = np.asarray(out["u"]).reshape(nx, ny)
v = np.asarray(out["v"]).reshape(nx, ny)
p = np.asarray(out["p"]).reshape(nx, ny)

print("=== field ranges ===")
print(f"u: [{u.min():+.4f}, {u.max():+.4f}]   v: [{v.min():+.4f}, {v.max():+.4f}]"
      f"   p: [{p.min():+.4f}, {p.max():+.4f}]")


def inflow(y):
    return np.where(y > 0.0, 24.0 * y * (0.5 - y), 0.0)


print("\n=== BC error (max |.|) ===")
print(f"inlet  u: {np.abs(u[0] - inflow(ys)).max():.4e}   v: {np.abs(v[0]).max():.4e}")
print(f"walls  u: {max(np.abs(u[:, 0]).max(), np.abs(u[:, -1]).max()):.4e}   "
      f"v: {max(np.abs(v[:, 0]).max(), np.abs(v[:, -1]).max()):.4e}")
print(f"outlet p: {np.abs(p[-1]).max():.4e}")

print("\n=== mass flux  int u dy  (exact = 0.5 at every x) ===")
flux = np.trapezoid(u, ys, axis=1)
for xq in (0.0, 0.5, 1.0, 2.0, 4.0, 6.0, 8.0, 11.0, 15.0):
    i = int(round(xq / 15.0 * (nx - 1)))
    print(f"  x={xs[i]:5.2f}  flux={flux[i]:+.5f}")

print("\n=== recirculation structure (wall-adjacent u, j=1 / j=-2) ===")
print("   x     u_near_bottom   u_near_top")
for xq in (0.25, 0.5, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 10.0, 12.0, 14.0):
    i = int(round(xq / 15.0 * (nx - 1)))
    print(f" {xs[i]:5.2f}   {u[i, 1]:+.5f}      {u[i, -2]:+.5f}")


def _sign_changes(col):
    s = np.sign(col)
    idx = np.where(s[:-1] * s[1:] < 0)[0]
    return [float(xs[i] + (xs[i + 1] - xs[i]) * abs(col[i]) / (abs(col[i]) + abs(col[i + 1])))
            for i in idx]


print("\n=== separation / reattachment (u sign changes on the near-wall row) ===")
print(f"  bottom wall: {[round(z, 3) for z in _sign_changes(u[:, 1])]}"
      "   (Gartling Re=800 benchmark: reattachment ~6.1)")
print(f"  top wall:    {[round(z, 3) for z in _sign_changes(u[:, -2])]}"
      "   (Gartling: separation ~4.85, reattachment ~10.5)")


# ── residual field, per component ────────────────────────────────────────
def uvp_one(xy):
    o = predict_fn(params, xy[None, :])
    return jnp.stack([o["u"][0], o["v"][0], o["p"][0]])


d1_fn = jacfwd(uvp_one)
d2_fn = jacfwd(jacfwd(uvp_one))


def res_one(xy):
    q = uvp_one(xy)
    d1 = d1_fn(xy)
    d2 = d2_fn(xy)
    u_, v_ = q[0], q[1]
    u_x, u_y = d1[0, 0], d1[0, 1]
    v_x, v_y = d1[1, 0], d1[1, 1]
    p_x, p_y = d1[2, 0], d1[2, 1]
    u_xx, u_yy = d2[0, 0, 0], d2[0, 1, 1]
    v_xx, v_yy = d2[1, 0, 0], d2[1, 1, 1]
    r_c = u_x + v_y
    r_mx = u_ * u_x + v_ * u_y + p_x - NU * (u_xx + u_yy)
    r_my = u_ * v_x + v_ * v_y + p_y - NU * (v_xx + v_yy)
    return jnp.stack([r_c, r_mx, r_my])


res = np.asarray(jax.jit(vmap(res_one))(jnp.asarray(pts))).reshape(nx, ny, 3)
print("\n=== residual RMS over the whole grid ===")
for k, nm in enumerate(("continuity", "x-momentum", "y-momentum")):
    print(f"  {nm:12s} {np.sqrt((res[..., k] ** 2).mean()):.4e}   "
          f"max {np.abs(res[..., k]).max():.3e}")

print("\n=== residual RMS binned in x ===")
print("   x-band     cont       r_mx       r_my")
edges = [0, 1, 2, 4, 6, 8, 11, 15]
for a, b in zip(edges[:-1], edges[1:]):
    m = (Xg[:, 0] >= a) & (Xg[:, 0] < b + 1e-9)
    r = res[m]
    print(f" [{a:5.1f},{b:5.1f}]  " + "  ".join(
        f"{np.sqrt((r[..., k] ** 2).mean()):.3e}" for k in range(3)))


# ── gradient-norm balance (kb1/050 Alg. 1) at the trained point ──────────
pts_int = pts.reshape(nx, ny, 2)[1:-1, 1:-1].reshape(-1, 2)
sub = np.asarray(pts_int[np.random.RandomState(0).choice(len(pts_int), 4096, False)])
bc_x = np.concatenate([np.stack([np.zeros(ny), ys], 1),
                       np.stack([xs, np.full(nx, -0.5)], 1),
                       np.stack([xs, np.full(nx, 0.5)], 1)]).astype(np.float32)
bc_u = np.concatenate([inflow(ys), np.zeros(2 * nx)]).astype(np.float32)

flat, unravel = jax.flatten_util.ravel_pytree(params)


def L_pde(fp):
    def r1(xy):
        return jnp.sum(_res_p(fp, xy) ** 2)
    return jnp.mean(vmap(r1)(jnp.asarray(sub)))


def _uvp_p(fp, xy):
    o = predict_fn(unravel(fp), xy[None, :])
    return jnp.stack([o["u"][0], o["v"][0], o["p"][0]])


def _res_p(fp, xy):
    q = _uvp_p(fp, xy)
    d1 = jacfwd(_uvp_p, argnums=1)(fp, xy)
    d2 = jacfwd(jacfwd(_uvp_p, argnums=1), argnums=1)(fp, xy)
    r_c = d1[0, 0] + d1[1, 1]
    r_mx = q[0] * d1[0, 0] + q[1] * d1[0, 1] + d1[2, 0] - NU * (d2[0, 0, 0] + d2[0, 1, 1])
    r_my = q[0] * d1[1, 0] + q[1] * d1[1, 1] + d1[2, 1] - NU * (d2[1, 0, 0] + d2[1, 1, 1])
    return jnp.stack([r_c, r_mx, r_my])


def L_bc(fp):
    q = vmap(lambda xy: _uvp_p(fp, xy))(jnp.asarray(bc_x))
    return jnp.mean((q[:, 0] - jnp.asarray(bc_u)) ** 2 + q[:, 1] ** 2)


g_pde = np.abs(np.asarray(jax.grad(L_pde)(flat)))
g_bc = np.abs(np.asarray(jax.grad(L_bc)(flat)))
print("\n=== kb1/050 gradient statistics at the trained point ===")
print(f"  max|grad L_pde| = {g_pde.max():.4e}   mean|grad L_pde| = {g_pde.mean():.4e}")
print(f"  max|grad L_bc | = {g_bc.max():.4e}   mean|grad L_bc | = {g_bc.mean():.4e}")
print(f"  lambda_hat = max|g_pde| / mean|g_bc|      = {g_pde.max() / (g_bc.mean() + 1e-30):.3e}")
print(f"  (with the applied lambda_bc = {mod.WEIGHT_BC}, the effective ratio of")
print(f"   mean grad magnitudes pde:bc is 1 : {mod.WEIGHT_BC * g_bc.mean() / (g_pde.mean() + 1e-30):.3e})")
print("\nDIAG OK")
