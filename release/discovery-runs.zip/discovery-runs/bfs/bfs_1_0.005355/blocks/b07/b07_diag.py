"""b07 diagnostic: what distinguishes good from bad draws of the champion
family, and what does the fdlift ansatz change actually do to the field?
Runs free on CPU from saved .pkl fields of b03/b05/b06 (also registers on GPU
via `eval.py --diag`).  No reference data is read anywhere.
"""
from __future__ import annotations

import json
import os
import pickle
import sys
import types
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
os.environ.setdefault("JAX_PLATFORMS", "cpu")

import jax
import jax.numpy as jnp


def load_module(path: Path) -> types.ModuleType:
    mod = types.ModuleType("m_" + path.stem)
    sys.modules[mod.__name__] = mod
    exec(compile(path.read_text(), str(path), "exec"), mod.__dict__)
    return mod


NX, NY = 481, 65
xs = np.linspace(0.0, 15.0, NX)
ys = np.linspace(-0.5, 0.5, NY)
Xg, Yg = np.meshgrid(xs, ys)                      # [NY, NX]
PTS = jnp.array(np.stack([Xg.ravel(), Yg.ravel()], 1).astype(np.float32))

# (label, candidate module path, pkl path, rRMSE)
BASE = [
    ("b03_base_s1", "b03/b03_base.py", "b03/b03_base_s1.pkl", 0.019640),
    ("b03_base_s2", "b03/b03_base.py", "b03/b03_base_s2.pkl", 0.019545),
    ("b03_base_s3", "b03/b03_base.py", "b03/b03_base_s3.pkl", 0.024317),
    ("b03_base_s4", "b03/b03_base.py", "b03/b03_base_s4.pkl", 0.020904),
    ("b05_base_s0", "b05/b05_base.py", "b05/b05_base.pkl", 0.023172),
    ("b05_base_s1", "b05/b05_base.py", "b05/b05_base_s1.pkl", 0.016319),
    ("b05_base_s2", "b05/b05_base.py", "b05/b05_base_s2.pkl", 0.019682),
    ("b05_base_s3", "b05/b05_base.py", "b05/b05_base_s3.pkl", 0.021377),
    ("b05_base_s4", "b05/b05_base.py", "b05/b05_base_s4.pkl", 0.020982),
    ("b05_base_s5", "b05/b05_base.py", "b05/b05_base_s5.pkl", 0.018460),
    ("b06_base_s0", "b06/b06_base.py", "b06/b06_base.pkl", 0.020528),
    ("b06_base_s1", "b06/b06_base.py", "b06/b06_base_s1.pkl", 0.018426),
    ("b06_base_s2", "b06/b06_base.py", "b06/b06_base_s2.pkl", 0.019700),
    ("b06_base_s3", "b06/b06_base.py", "b06/b06_base_s3.pkl", 0.022394),
]
FD = [
    ("fdlift_s0", "b06/b06_fdlift.py", "b06/b06_fdlift.pkl", 0.015949),
    ("fdlift_s1", "b06/b06_fdlift.py", "b06/b06_fdlift_s1.pkl", 0.022640),
    ("fdlift_s2", "b06/b06_fdlift.py", "b06/b06_fdlift_s2.pkl", 0.011701),
    ("fdlift_s3", "b06/b06_fdlift.py", "b06/b06_fdlift_s3.pkl", 0.021092),
]
ALL = BASE + FD

_mods: dict[str, types.ModuleType] = {}


def field(rel_py: str, rel_pkl: str):
    if rel_py not in _mods:
        _mods[rel_py] = load_module(ROOT / "blocks" / rel_py)
    mod = _mods[rel_py]
    with open(ROOT / "blocks" / rel_pkl, "rb") as f:
        params = pickle.load(f)
    out = mod.predict_fn(params, PTS)
    u = np.asarray(out["u"], np.float64).reshape(NY, NX)
    v = np.asarray(out["v"], np.float64).reshape(NY, NX)
    p = np.asarray(out["p"], np.float64).reshape(NY, NX)
    return u, v, p


def zero_cross(xs_, f):
    """all sign changes of f(x) with the interpolated x location"""
    out = []
    for i in range(len(f) - 1):
        if f[i] == 0.0:
            continue
        if f[i] * f[i + 1] < 0:
            t = f[i] / (f[i] - f[i + 1])
            out.append((xs_[i] + t * (xs_[i + 1] - xs_[i]), np.sign(f[i + 1] - f[i])))
    return out


def structure(u, v):
    """near-wall streamwise velocity sign structure -> separation/reattachment"""
    ub = u[1, :]        # just above the bottom wall  (y = -0.5 + dy)
    ut = u[-2, :]       # just below the top wall
    bot = zero_cross(xs, ub)
    top = zero_cross(xs, ut)
    flux = np.trapezoid(u, ys, axis=0)      # int u dy at every x
    return dict(
        bot_cross=[round(float(a), 3) for a, s in bot],
        top_cross=[round(float(a), 3) for a, s in top],
        u_min=float(u.min()), u_max=float(u.max()),
        v_absmax=float(np.abs(v).max()),
        flux_drift=float((flux.max() - flux.min()) / 0.5),
        neg_area=float((u < 0).mean()),
    )


print("=" * 72)
print("PART 1 — field structure vs score")
print("=" * 72)
fields = {}
rows = []
for lab, py, pkl, score in ALL:
    u, v, p = field(py, pkl)
    fields[lab] = (u, v)
    st = structure(u, v)
    rows.append((lab, score, st))
    print(f"{lab:14s} rRMSE={score:.5f}  bot={st['bot_cross']}  top={st['top_cross']}"
          f"  umin={st['u_min']:+.3f} vmax={st['v_absmax']:.3f}"
          f"  flux={st['flux_drift']*100:.2f}%  negA={st['neg_area']*100:.1f}%")

# correlation of each scalar metric with the score
print("\n-- Pearson r of metric vs rRMSE (n=%d) --" % len(rows))
sc = np.array([r[1] for r in rows])


def metric(name, fn):
    vals = np.array([fn(r[2]) for r in rows], float)
    if np.std(vals) < 1e-12:
        return
    r = float(np.corrcoef(vals, sc)[0, 1])
    print(f"  {name:22s} r={r:+.3f}   range [{vals.min():.4f}, {vals.max():.4f}]")


def first_bot_reattach(st):
    c = st["bot_cross"]
    return c[0] if c else np.nan


def top_sep(st):
    c = st["top_cross"]
    return c[0] if len(c) >= 1 else np.nan


def top_reattach(st):
    c = st["top_cross"]
    return c[1] if len(c) >= 2 else np.nan


metric("bottom reattach x", first_bot_reattach)
metric("top separation x", top_sep)
metric("top reattach x", top_reattach)
metric("top eddy length", lambda s: top_reattach(s) - top_sep(s))
metric("u_min", lambda s: s["u_min"])
metric("|v|_max", lambda s: s["v_absmax"])
metric("flux drift", lambda s: s["flux_drift"])
metric("negative-u area", lambda s: s["neg_area"])

print("\n" + "=" * 72)
print("PART 2 — ensemble geometry: where do good and bad draws differ?")
print("=" * 72)
labs = [r[0] for r in rows]
Q = np.stack([np.concatenate([fields[l][0].ravel(), fields[l][1].ravel()]) for l in labs])
nrm = np.linalg.norm(Q, axis=1)
qbar = Q.mean(0)
D = Q - qbar
print("mean |q| = %.4f ; spread of each member from ensemble mean (relative):" % nrm.mean())
for l, d in zip(labs, D):
    print(f"   {l:14s} {np.linalg.norm(d)/nrm.mean():.4f}")

# PCA of the ensemble, and correlation of each PC score with rRMSE
U_, S_, Vt = np.linalg.svd(D, full_matrices=False)
var = S_ ** 2 / np.sum(S_ ** 2)
print("\nPC variance fractions:", " ".join(f"{v:.3f}" for v in var[:6]))
for k in range(4):
    pc = U_[:, k] * S_[k]
    r = float(np.corrcoef(pc, sc)[0, 1])
    print(f"  PC{k+1}: var {var[k]:.3f}  corr(score) r={r:+.3f}")

# where does PC1 live in space?
for k in range(2):
    mode = Vt[k]
    mu = mode[: NY * NX].reshape(NY, NX)
    mv = mode[NY * NX:].reshape(NY, NX)
    e = mu ** 2 + mv ** 2
    bands = [(0, 1), (1, 2), (2, 4), (4, 6), (6, 8), (8, 10), (10, 12), (12, 15)]
    tot = e.sum()
    frac = [(a, b, 100 * e[:, (xs >= a) & (xs < b)].sum() / tot) for a, b in bands]
    print(f"  PC{k+1} energy by x-band: " + " ".join(f"[{a},{b}):{f:.0f}%" for a, b, f in frac))

print("\n" + "=" * 72)
print("PART 3 — fdlift good vs bad draws, direct field difference")
print("=" * 72)
good = ["fdlift_s2", "fdlift_s0"]
bad = ["fdlift_s1", "fdlift_s3"]
gu = np.mean([fields[l][0] for l in good], 0)
gv = np.mean([fields[l][1] for l in good], 0)
bu = np.mean([fields[l][0] for l in bad], 0)
bv = np.mean([fields[l][1] for l in bad], 0)
du, dv = gu - bu, gv - bv
e = du ** 2 + dv ** 2
tot = e.sum()
bands = [(0, 1), (1, 2), (2, 4), (4, 6), (6, 8), (8, 10), (10, 12), (12, 15)]
print("good(0.0117,0.0159) - bad(0.0211,0.0226): rel diff = %.4f" %
      (np.sqrt(tot) / np.linalg.norm(np.concatenate([gu.ravel(), gv.ravel()]))))
print("  energy by x-band: " + " ".join(
    f"[{a},{b}):{100*e[:, (xs>=a)&(xs<b)].sum()/tot:.0f}%" for a, b in bands))
print("  energy by y-band: " + " ".join(
    f"[{a:+.2f},{b:+.2f}):{100*e[(ys>=a)&(ys<b), :].sum()/tot:.0f}%"
    for a, b in [(-0.5, -0.25), (-0.25, 0.0), (0.0, 0.25), (0.25, 0.5)]))

# same for base ensemble mean vs fdlift ensemble mean
bm_u = np.mean([fields[l][0] for l, *_ in BASE], 0)
bm_v = np.mean([fields[l][1] for l, *_ in BASE], 0)
fm_u = np.mean([fields[l][0] for l, *_ in FD], 0)
fm_v = np.mean([fields[l][1] for l, *_ in FD], 0)
du, dv = fm_u - bm_u, fm_v - bm_v
e = du ** 2 + dv ** 2
tot = e.sum()
print("\nfdlift mean - base mean: rel diff = %.4f" %
      (np.sqrt(tot) / np.linalg.norm(np.concatenate([bm_u.ravel(), bm_v.ravel()]))))
print("  energy by x-band: " + " ".join(
    f"[{a},{b}):{100*e[:, (xs>=a)&(xs<b)].sum()/tot:.0f}%" for a, b in bands))

print("\n-- streamwise profile of the mean fields (u at 3 heights) --")
for xq in [0.5, 2, 4, 6, 8, 10, 12, 15]:
    i = int(np.argmin(np.abs(xs - xq)))
    print(f"  x={xq:5.1f}  base u(-0.4,0,+0.4)="
          f"{bm_u[np.argmin(abs(ys+0.4)),i]:+.3f},{bm_u[NY//2,i]:+.3f},{bm_u[np.argmin(abs(ys-0.4)),i]:+.3f}"
          f"   fd u="
          f"{fm_u[np.argmin(abs(ys+0.4)),i]:+.3f},{fm_u[NY//2,i]:+.3f},{fm_u[np.argmin(abs(ys-0.4)),i]:+.3f}")

print("\n" + "=" * 72)
print("PART 4 — residual of the mean fields (autodiff), by x-band")
print("=" * 72)
NU = 1.0 / 800.0
_EX = jnp.array([1.0, 0.0])
_EY = jnp.array([0.0, 1.0])


def residual_report(rel_py: str, rel_pkl: str, lab: str):
    mod = _mods[rel_py]
    with open(ROOT / "blocks" / rel_pkl, "rb") as f:
        params = pickle.load(f)

    def q_of(xy):
        o = mod.predict_fn(params, xy[None, :])
        return jnp.stack([o["u"][0], o["v"][0], o["p"][0]])

    def d2(xy, e):
        def inner(z):
            return jax.jvp(q_of, (z,), (e,))
        (q, d1), (_, dd) = jax.jvp(inner, (xy,), (e,))
        return q, d1, dd

    def res(xy):
        q, dx, dxx = d2(xy, _EX)
        _, dy, dyy = d2(xy, _EY)
        u, v = q[0], q[1]
        return jnp.stack([
            u * dx[0] + v * dy[0] + dx[2] - NU * (dxx[0] + dyy[0]),
            u * dx[1] + v * dy[1] + dy[2] - NU * (dxx[1] + dyy[1]),
            dx[0] + dy[1]])

    sub = PTS[::4]
    r = np.asarray(jax.vmap(res)(sub))
    xsub = np.asarray(sub[:, 0])
    print(f"{lab:14s} rms r_mx={np.sqrt((r[:,0]**2).mean()):.2e} "
          f"r_my={np.sqrt((r[:,1]**2).mean()):.2e} r_c={np.sqrt((r[:,2]**2).mean()):.2e}")
    for a, b in [(0, 0.5), (0.5, 2), (2, 6), (6, 10), (10, 15.01)]:
        m = (xsub >= a) & (xsub < b)
        print(f"     x[{a},{b}) r_mx={np.sqrt((r[m,0]**2).mean()):.2e} "
              f"r_my={np.sqrt((r[m,1]**2).mean()):.2e} r_c={np.sqrt((r[m,2]**2).mean()):.2e}")


for lab, py, pkl, score in [ALL[10], FD[2], FD[1]]:
    residual_report(py, pkl, lab)

print("\ndone")

print("\n" + "=" * 72)
print("PART 5 — error decomposition: is rRMSE^2 = bias^2 + |q-qbar|^2 ?")
print("=" * 72)
Qn = Q / nrm.mean()                       # relative units
qb = Qn.mean(0)
d = np.linalg.norm(Qn - qb, axis=1)
r = np.corrcoef(d, sc)[0, 1]
print(f"corr(|q_i - qbar|, rRMSE_i) = {r:+.3f}   (n={len(sc)})")
# least-squares fit  rRMSE^2 = b^2 + c*|d|^2
A = np.stack([np.ones_like(d), d ** 2], 1)
coef, *_ = np.linalg.lstsq(A, sc ** 2, rcond=None)
pred = np.sqrt(np.maximum(A @ coef, 0))
print(f"fit rRMSE^2 = {coef[0]:.3e} + {coef[1]:.3f}*|d|^2  ->  bias = {np.sqrt(max(coef[0],0)):.4f}")
print(f"    residual std of fit (in rRMSE units) = {np.std(sc - pred):.4f}")
for l, di, s, pp in zip(labs, d, sc, pred):
    print(f"   {l:14s} |d|={di:.4f}  rRMSE={s:.5f}  pred={pp:.5f}")

print("\n-- within-recipe pairwise distances (free, reference-blind) --")
groups = {"b03_base": [l for l in labs if l.startswith("b03_base")],
          "b05_base": [l for l in labs if l.startswith("b05_base")],
          "b06_base": [l for l in labs if l.startswith("b06_base")],
          "base_all": [l for l in labs if "base" in l],
          "fdlift":   [l for l in labs if l.startswith("fdlift")]}
idx = {l: i for i, l in enumerate(labs)}
gmeans = {}
for g, ls in groups.items():
    ii = [idx[l] for l in ls]
    sub = Qn[ii]
    gmeans[g] = sub.mean(0)
    pd = [np.linalg.norm(sub[a] - sub[b]) for a in range(len(ii)) for b in range(a + 1, len(ii))]
    print(f"  {g:9s} n={len(ii)}  mean pairwise dist = {np.mean(pd):.4f} "
          f"(min {np.min(pd):.4f}, max {np.max(pd):.4f})  mean rRMSE={np.mean(sc[ii]):.5f}")
print(f"  || mean(base_all) - mean(fdlift) || = "
      f"{np.linalg.norm(gmeans['base_all'] - gmeans['fdlift']):.4f}")
print(f"  || mean(b05_base) - mean(b06_base) || = "
      f"{np.linalg.norm(gmeans['b05_base'] - gmeans['b06_base']):.4f}")
np.save(Path(__file__).with_name("ens_mean.npy"), qb)
print("\nsaved reference-blind ensemble mean -> blocks/b07/ens_mean.npy")

print("\n" + "=" * 72)
print("PART 6 — reference-blind surrogate for extra fields (blocks/b07/extra.json)")
print("=" * 72)
extra_path = Path(__file__).with_name("extra.json")
if extra_path.is_file():
    scale = nrm.mean()
    b2, c2 = coef
    print(f"{'label':22s} {'|d|':>7s} {'pred':>8s} {'rRMSE':>8s} {'resid':>8s}  "
          f"(resid<0 = closer to truth than conformity predicts)")
    for lab, py, pkl, score in json.loads(extra_path.read_text()):
        u, v, _ = field(py, pkl)
        q = np.concatenate([u.ravel(), v.ravel()]) / scale
        di = float(np.linalg.norm(q - qb))
        pr = float(np.sqrt(max(b2 + c2 * di ** 2, 0)))
        if score is None:
            print(f"{lab:22s} {di:7.4f} {pr:8.5f} {'-':>8s} {'-':>8s}")
        else:
            print(f"{lab:22s} {di:7.4f} {pr:8.5f} {score:8.5f} {score-pr:+8.5f}")
