# Discovery runs

The 22 discovery runs of the paper, three on LDC, three on KS and one on each other problem. In the
code a round is called a block, so round NN is `bNN`, and round 0 is the standard PINN solver.

| Path | Content |
|---|---|
| `<problem>/<run>/blocks/kb2/bNN.md` | summary that round NN writes into the experience base |
| `<problem>/<run>/blocks/bNN/evals.jsonl` | one record per evaluation in round NN, with the relative L2 error as `rRMSE` |
| `<problem>/<run>/blocks/bNN/*.py` | code written in round NN |

| Problem | Run | Rounds |
|---|---|---|
| Poisson-CG | `poissoncg_1_0.0009592` | 5 |
| IB | `ib_1_1.348e-05` | 5 |
| KdV | `kdv_1_0.001731` | 5 |
| Wave-HM | `wavems_1_0.04592` | 10 |
| LDC | `ldc_1_0.01295` | 10 |
| LDC | `ldc_2_0.01604` | 10 |
| LDC | `ldc_3_0.01664` | 10 |
| BFS | `bfs_1_0.005355` | 10 |
| Heat-LT | `heatlt_1_0.03522` | 10 |
| NACA | `naca_1_0.007671` | 10 |
| Smoke | `smoke_1_0.06326` | 10 |
| Cyl | `cyl_1_0.01531` | 10 |
| GL | `gl_1_0.003662` | 10 |
| GS | `gs_1_0.001683` | 10 |
| KF | `kf_1_0.01489` | 10 |
| KS | `ks_1_0.009508` | 10 |
| KS | `ks_2_0.01159` | 10 |
| KS | `ks_3_0.003358` | 10 |
| NS4D | `ns4d_1_2.659e-07` | 5 |
| Cyl-LT | `cyl2_1_0.1001` | 10 |
| RT | `rt_1_0.004299` | 10 |
| Wing3D | `wing3d_1_0.02078` | 10 |
