# Discovered PINN solvers

The 18 discovered PINN solvers of Table 1, one file per problem. Run a solver with the `eval.py` of
its task package, as described in the README of the task package.

| Problem | File | Training time (s) |
|---|---|---|
| Poisson-CG | `poissoncg.py` | 60 |
| IB | `ib.py` | 100 |
| KdV | `kdv.py` | 100 |
| Wave-HM | `wavems.py` | 100 |
| LDC | `ldc.py` | 150 |
| BFS | `bfs.py` | 180 |
| Heat-LT | `heatlt.py` | 180 |
| NACA | `naca.py` | 180 |
| Smoke | `smoke.py` | 180 |
| Cyl | `cyl.py` | 300 |
| GL | `gl.py` | 300 |
| GS | `gs.py` | 300 |
| KF | `kf.py` | 300 |
| KS | `ks.py` | 300 |
| NS4D | `ns4d.py` | 300 |
| Cyl-LT | `cyl2.py` | 480 |
| RT | `rt.py` | 480 |
| Wing3D | `wing3d.py` | 480 |
