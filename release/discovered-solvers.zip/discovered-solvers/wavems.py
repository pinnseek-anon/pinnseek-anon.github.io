"""b10_eig03 with the BLAS thread cap that stops two concurrent evals
from losing 9 s of wall to the eigensolve. Same objective; b09_dtsc's
goal-oriented term rebuilt on the TRUE generalized eigenmodes
of the medium (-lap psi = w^2 psi/c) with a causal, zero-padded Duhamel
convolution at true kernel amplitude, replacing the homogenised-CBAR resonant
filter. Free CPU diag: error correlation 0.02 -> 0.46.
"""
from __future__ import annotations

# ═══════════════════════════════════════════════════════════════
# PDE CONSTANTS — DO NOT MODIFY (frozen header, byte-identical to parent)
# ═══════════════════════════════════════════════════════════════

# --- I/O shape ---
INPUT_DIM    = 3
OUTPUT_DIM   = 1
INPUT_NAMES  = ("t", "x", "y")
FIELD_NAMES  = ("u",)

# --- Domain ---
T_MIN, T_MAX = 0.0, 5.0
X_MIN, X_MAX = -1.0, 1.0
Y_MIN, Y_MAX = -1.0, 1.0
HAS_TIME = True

# --- Equation structure ---
TIME_DERIV_ORDER        = 2   # u_tt — the IC fixes both u and u_t at t = 0
MAX_SPATIAL_DERIV_ORDER = 2
N_RESIDUAL_COMPONENTS   = 1   # r
HAS_SOURCE              = False  # no forcing: every term carries u

# --- Boundary topology ---
BOUNDARY_NAMES = ("x_lo", "x_hi", "y_lo", "y_hi")
PERIODIC_AXES  = ()       # none: zero Neumann on all four faces
GEOMETRY_KIND  = "box"

# --- Physical parameters ---
COEF_FILE = "wavems_coef.csv"   # c(x, y) on a 256 x 256 grid over [-1, 1]^2
C_LO, C_HI = 1.0, 12.0          # the medium is two-valued; wave speed sqrt(c)
IC_X0, IC_Y0, IC_SIGMA = -0.5, 0.0, 0.3   # Gaussian pulse of the initial condition

# --- Training budget ---
import os as _os, time as _time
_T0 = float(_os.environ.get("FORGE_T0", _time.time()))  # process-start wall anchor
TRAIN_TIME = 100.0     # total wall-clock seconds for the WHOLE process,
                       # from _T0: imports, JIT compile, training and param
                       # save all included — eval.py kills the process at
                       # this wall; return params with margin to spare
MAX_ITER   = 1_000_000 # safety cap on the loop (not expected to bind)

# --- Eval gate: full fidelity only under task/eval.py ---
if _os.environ.get("FORGE_EVAL_TOKEN") != "task/eval.py":
    TRAIN_TIME = 10.0                                # off-eval runs are smoke:
    _os.environ.setdefault("JAX_PLATFORMS", "cpu")   # CPU, 10 s
# ═══════════════════════════════════════════════════════════════

# Two concurrent evals each ran a 1024^2 generalized eigh with 32 BLAS threads
# on 32 cores: module import 1.0 s -> 9.6 s, i.e. ~2700 training steps lost.
for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    _os.environ.setdefault(_v, "4")

import time
from pathlib import Path
from typing import Any, Callable

import jax
import jax.numpy as jnp
from jax import jit, random, vmap
import numpy as np
import optax
from flax import linen as nn


def _locate(name: str) -> Path:
    """Find task/<name> by walking up from cwd (eval.py runs from root)."""
    here = Path.cwd()
    for base in [here, *here.parents]:
        cand = base / "task" / name
        if cand.is_file():
            return cand
    return Path("task") / name


# ══════════ Hyperparameters ══════════

NT, NX, NY = 768, 96, 96     # tensor-grid collocation: 2.95M points per step
RANK       = 192             # CP rank of the separable ansatz
WIDTH      = 64              # per-axis MLP width
DEPTH      = 4               # per-axis MLP hidden layers
NFREQ_T    = 32              # sin/cos embedding modes on t (spectrum needs ~8.5
                             # full cycles over [0,5]; 8 was right at the edge)
FT_KEEP    = 20            # temporal modes kept at full scale
FT_ALPHA   = 0.10          # ... and the scale of the modes above it
NFREQ_S    = 10              # sin/cos embedding modes on x and y
GATE_A     = 0.35            # hard-IC gate width: g = 1 - exp(-(t/GATE_A)^2)
LAM_BC     = 0.3             # Neumann term multiplier inside the kb1 021 pairing
LR0, LR1   = 3.2e-2, 1e-4      # exponential LR decay across the wall budget
SYNC_EVERY = 50              # host sync / schedule refresh cadence
LAM_M      = 0.1           # relative pull of the <u/c> invariant
LAM_E      = 0.18          # relative pull of the energy-conservation term
SIG_T      = 0.0103          # Gaussian half-width of the residual average, t
SIG_S      = 0.065         # ... and in x and y (0 disables the averaging)
M_SPEC     = 32            # Neumann cosine modes kept per spatial axis
P_NEG      = 0.0           # negative order of the spatial residual norm
LAM1       = 2.4674        # = (pi/2)^2, the first Neumann eigenvalue
AW         = 1.5           # early-time up-weight of the residual slices
EMA_BETA   = 0.99          # Polyak averaging of the weights; the b08_cont
EMA_FRAC   = 0.30          # diagnostic shows the run ends gradient-noise
                           # limited (the loss fluctuates 2-5x between steps
                           # while the field still creeps down), so the tail
                           # of the trajectory is noise around a better point
LAM_D      = 0.08          # relative pull of the goal-oriented (Duhamel) term
N_EIG      = 256           # generalized eigenmodes kept for the Duhamel filter
NQ_EIG     = 256           # quadrature grid for the eigenbasis' mass matrix
SAVE_MARGIN_S = 6.0          # stop the loop this early so device_get + pickling
                             # finish before eval.py's TRAIN_TIME wall


# ══════════ Medium c(x, y) ══════════

def _coef_grid():
    """The 256 x 256 medium c(x, y) as an array C[iy, ix] plus its axis."""
    raw = np.loadtxt(_locate(COEF_FILE), delimiter=",", skiprows=1, dtype=np.float64)
    n = int(round(np.sqrt(len(raw))))
    return raw[:, 2].reshape(n, n).astype(np.float32), n


def coef_at(C, n, x, y):
    """Bilinear interpolation of the medium at arbitrary (x, y) — numpy or jnp."""
    gx = (x - X_MIN) / (X_MAX - X_MIN) * (n - 1)
    gy = (y - Y_MIN) / (Y_MAX - Y_MIN) * (n - 1)
    gx = jnp.clip(gx, 0.0, n - 1 - 1e-6)
    gy = jnp.clip(gy, 0.0, n - 1 - 1e-6)
    i, j = jnp.floor(gx).astype(jnp.int32), jnp.floor(gy).astype(jnp.int32)
    fx, fy = gx - i, gy - j
    c00, c10 = C[j, i], C[j, i + 1]
    c01, c11 = C[j + 1, i], C[j + 1, i + 1]
    return (1 - fy) * ((1 - fx) * c00 + fx * c10) + fy * ((1 - fx) * c01 + fx * c11)


# ══════════ Analytic initial pulse (rank-1: u0 = A(x) B(y)) ══════════

def _gA(z, z0):
    return jnp.exp(-((z - z0) ** 2) / (2.0 * IC_SIGMA ** 2))


def _gA1(z, z0):
    return _gA(z, z0) * (-(z - z0) / IC_SIGMA ** 2)


def _gA2(z, z0):
    d = z - z0
    return _gA(z, z0) * (d ** 2 / IC_SIGMA ** 4 - 1.0 / IC_SIGMA ** 2)


# ══════════ Per-axis branch network ══════════

class Branch(nn.Module):
    """1-D modified/gated MLP (kb1 050 'improved fully-connected architecture',
    the SPINN-mod backbone of kb1 070) over a sin/cos embedding of the axis."""
    width: int = WIDTH
    depth: int = DEPTH
    rank: int = RANK

    @nn.compact
    def __call__(self, feat):                     # feat: [F]
        gi = nn.initializers.glorot_normal()
        U = nn.tanh(nn.Dense(self.width, kernel_init=gi, name="Wu")(feat))
        V = nn.tanh(nn.Dense(self.width, kernel_init=gi, name="Wv")(feat))
        h = nn.tanh(nn.Dense(self.width, kernel_init=gi, name="W0")(feat))
        for i in range(self.depth - 1):
            z = nn.tanh(nn.Dense(self.width, kernel_init=gi, name=f"W{i+1}")(h))
            h = (1.0 - z) * U + z * V
        return nn.Dense(self.rank, kernel_init=gi)(h)     # [rank]


_BRANCH = Branch()
_KT = np.arange(1, NFREQ_T + 1, dtype=np.float32)
_KS = np.arange(1, NFREQ_S + 1, dtype=np.float32)
_RSCALE = 1.0 / np.sqrt(RANK, dtype=np.float32)
_SCT = jnp.asarray(np.where(_KT <= FT_KEEP, 1.0, FT_ALPHA).astype(np.float32))
_SCS = jnp.asarray(np.ones_like(_KS))


def _embed(z, lo, hi, ks, sc):
    """Scalar axis coordinate -> [1 + 2*len(ks)] features, each Fourier pair
    scaled by its entry of ``sc`` so the modes above the old ceiling enter the
    NTK gently instead of injecting Om^2-amplified junk (kb1 020)."""
    s = 2.0 * (z - lo) / (hi - lo) - 1.0                  # -> [-1, 1]
    ang = jnp.pi * jnp.asarray(ks) * (s + 1.0) / 2.0
    return jnp.concatenate([jnp.reshape(s, (1,)),
                            jnp.cos(ang) * sc, jnp.sin(ang) * sc])


def _feat0(p, z, lo, hi, ks, sc):
    return vmap(lambda s: _BRANCH.apply(p, _embed(s, lo, hi, ks, sc)))(z)


def _feat01(p, z, lo, hi, ks, sc):
    """Branch value and first derivative from a single jvp (2 fwd-equivalents)."""
    f = lambda s: _BRANCH.apply(p, _embed(s, lo, hi, ks, sc))
    return vmap(lambda s: jax.jvp(f, (s,), (jnp.ones_like(s),)))(z)


def _feat012(p, z, lo, hi, ks, sc):
    """Branch value and its first TWO derivatives from ONE nested jvp — 4
    forward-equivalents instead of the 1 + 2 + 4 of three separate jacfwd
    passes, and one vmapped kernel launch instead of three (kb1 070's
    forward-mode SPINN scheme, just assembled in a single sweep)."""
    f = lambda s: _BRANCH.apply(p, _embed(s, lo, hi, ks, sc))

    def f01(s):
        return jax.jvp(f, (s,), (jnp.ones_like(s),))

    def f012(s):
        (d0, d1), (_, d2) = jax.jvp(f01, (s,), (jnp.ones_like(s),))
        return d0, d1, d2

    return vmap(f012)(z)


def _xy(b, c):
    """Outer product of two axis factor matrices, contracted-side first:
    [J,r],[K,r] -> [r, J*K].  Doing (x,y) before t keeps the intermediate
    3.3x smaller than the [NT,NX,r] of a t-first contraction."""
    r = b.shape[1]
    return (b.T[:, :, None] * c.T[:, None, :]).reshape(r, -1)


def _smooth_mat(n, lo, hi, sig):
    """Gaussian local-average matrix on the uniform grid of [lo, hi] with mirror
    (Neumann) reflection at both ends; rows sum to 1 so constants survive."""
    if sig <= 0.0:
        return None
    h = (hi - lo) / n
    i = np.arange(n)
    d0 = (i[:, None] - i[None, :]) * h
    d1 = (i[:, None] + i[None, :] + 1.0) * h
    d2 = (2 * n - 1 - i[:, None] - i[None, :]) * h
    K = (np.exp(-0.5 * (d0 / sig) ** 2) + np.exp(-0.5 * (d1 / sig) ** 2)
         + np.exp(-0.5 * (d2 / sig) ** 2))
    K /= K.sum(axis=1, keepdims=True)
    return jnp.asarray(K.astype(np.float32))


_ST = _smooth_mat(NT, T_MIN, T_MAX, SIG_T)

# Neumann cosine modes phi_j(z) = cos(j*pi*(z+1)/2), eigenvalues lam_j of -d2/dz2.
# The mirror-reflected Gaussian average of b03-b05 is exactly diagonal in this
# basis with multiplier exp(-lam*SIG_S^2/2), so squaring it is the weight
# exp(-lam*SIG_S^2); the extra (1+lam/LAM1)^-P_NEG factor makes the residual
# norm negative-order — the field error solves e_tt/c - lap(e) = r, so a
# residual at spatial mode lam feeds the metric with a gain ~ lam^-1/2 in
# amplitude (kb1 063's function-space/energy metric, kb1 124's norm-equivalent
# FOSLS weighting; kb1 027/086 set the same scale by local test functions).
_JM = np.arange(M_SPEC, dtype=np.float32)
_SJ = jnp.asarray(np.where(_JM == 0, 1.0, np.sqrt(2.0)).astype(np.float32))
_LAMJ = (np.pi * _JM / 2.0) ** 2
_LAM2 = _LAMJ[:, None] + _LAMJ[None, :]
_W2 = jnp.asarray((np.exp(-_LAM2 * SIG_S ** 2)
                   * (1.0 + _LAM2 / LAM1) ** (-P_NEG)).astype(np.float32))
_JMJ = jnp.asarray(_JM)

# Goal-oriented (Duhamel) term, on the medium's OWN modes.  With the hard IC the
# field error obeys e_tt/c - lap e = r, e(0) = e_t(0) = 0.  b09 decoupled that in
# the plain Neumann-cosine basis with a homogenised speed, w^2 = CBAR*lam; a free
# CPU diagnostic (b10_diagA) shows that decoupling is simply false in a 12x
# medium — the resulting filter's output correlates with the champion's actual
# error field at 0.02.  The exact decoupling uses the GENERALIZED eigenmodes
#     -lap psi_n = w_n^2 (1/c) psi_n ,   <psi_n, psi_m>_{1/c} = delta_nm,
# which are exactly diagonal for this operator.  -lap is already diagonal in the
# cosine basis, so the whole eigenproblem is the [P,P] pencil (diag(lam), Mass)
# with Mass_pq = <phi_p phi_q / c> — one dense eigh at import, 0.2 s.  Then
#     a_n'' + w_n^2 a_n = <r, psi_n>,  a_n(0) = a_n'(0) = 0,
# solved by the CAUSAL convolution a_n = (sin(w_n t)/w_n) * s_n at TRUE kernel
# amplitude (b08's note: b07's L2-normalised kernels made the weight positive
# order).  Zero-padding to 2*NT makes it a linear, not a circular, convolution,
# so resonance is represented as the secular growth it is instead of needing an
# ad-hoc ridge width.  The same diagnostic gives error correlation 0.46 (0.65-0.84
# for t > 1) and ||e_pred||/||e_true|| = 1.6, i.e. a real estimator of the metric
# (kb1 113's DWR estimator, kb1 063's function-space metric).  It is still ADDED,
# never substituted — b06/b07/b08 each replaced the norm and each lost the
# constraints that pin the scattering structure.
def _eig_basis():
    """Generalized eigenpairs (w, V) of (-lap, 1/c) in the [M_SPEC,M_SPEC]
    Neumann-cosine basis; V columns are psi_n's cosine coefficients."""
    import scipy.linalg as _sla
    C_np, n_g = _coef_grid()
    gg = -1.0 + 2.0 * (np.arange(NQ_EIG) + 0.5) / NQ_EIG
    rho = np.asarray(1.0 / coef_at(jnp.asarray(C_np), n_g,
                                   jnp.asarray(gg)[:, None], jnp.asarray(gg)[None, :]),
                     dtype=np.float64)
    P1 = np.cos(np.pi * _JM[None, :] * (gg[:, None] + 1.0) / 2.0) * np.asarray(_SJ)[None, :]
    U = (P1[:, :, None] * P1[:, None, :]).reshape(NQ_EIG, M_SPEC * M_SPEC)
    G = (U.T @ rho @ U) / (NQ_EIG * NQ_EIG)
    Mass = G.reshape(M_SPEC, M_SPEC, M_SPEC, M_SPEC).transpose(0, 2, 1, 3).reshape(
        M_SPEC * M_SPEC, M_SPEC * M_SPEC)
    Mass = 0.5 * (Mass + Mass.T)
    w2, V = _sla.eigh(np.diag(_LAM2.ravel().astype(np.float64)), Mass)
    return np.sqrt(np.maximum(w2, 0.0)), V


_WEIG, _VEIG = _eig_basis()
_ORD = np.argsort(_WEIG)[:N_EIG]
_WK = _WEIG[_ORD]
_VK = _VEIG[:, _ORD]
# plain-L2 output norm of each mode: ||e||^2 = ||V a||^2, and the off-diagonal of
# V^T V moves the value by 3 % (b10_diagC), so the diagonal is enough and free.
_DG = np.sum(_VK ** 2, axis=0)
_DG[_WK < 1e-6] = 0.0          # the constant mode is the mass invariant's job
_NFFT = 2 * NT
_DTG = (T_MAX - T_MIN) / NT
_TK = np.arange(_NFFT) * _DTG
with np.errstate(divide="ignore", invalid="ignore"):
    _HK = np.where(_WK[None, :] > 1e-8,
                   np.sin(_WK[None, :] * _TK[:, None]) / np.maximum(_WK[None, :], 1e-8),
                   _TK[:, None]) * _DTG
_VKJ = jnp.asarray(_VK.astype(np.float32))
_DGJ = jnp.asarray(_DG.astype(np.float32))
_HKF = jnp.asarray(np.fft.rfft(_HK, axis=0).astype(np.complex64))


def _qmat(z, lo, hi, n):
    """[n, M_SPEC] cosine quadrature matrix on the (jittered) uniform grid z:
    contracting a field against it gives mode amplitudes whose squares sum to
    the grid mean of the field's square (discrete Parseval)."""
    ang = jnp.pi * _JMJ[None, :] * (z[:, None] - lo) / (hi - lo)
    return jnp.cos(ang) * _SJ[None, :] / n


def _smooth(r, qx, qy):
    """Residual field [NT,NX,NY] -> smoothed mode amplitudes [NT,M,M]."""
    r = jnp.tensordot(r, qy, axes=(2, 0))             # [NT,NX,M]
    r = jnp.einsum("ixm,xj->ijm", r, qx)              # [NT,M,M]
    return jnp.tensordot(_ST, r, axes=(1, 0))         # [NT,NT] . [NT,M,M]


# ══════════ Loss ══════════

def _terms(params, t, x, y, c):
    """Raw per-time-slice PDE residual and the four Neumann-face residuals."""
    ft0, ft1, ft2 = _feat012(params["t"], t, T_MIN, T_MAX, _KT, _SCT)
    fx0, fx1, fx2 = _feat012(params["x"], x, X_MIN, X_MAX, _KS, _SCS)
    fy0, fy1, fy2 = _feat012(params["y"], y, Y_MIN, Y_MAX, _KS, _SCS)
    I, J, K = t.shape[0], x.shape[0], y.shape[0]

    # hard IC gate g(t) = 1 - exp(-(t/GATE_A)^2) : g(0)=0, g'(0)=0, g -> 1
    e = jnp.exp(-((t / GATE_A) ** 2))
    g0v = 1.0 - e
    g1v = 2.0 * t / GATE_A ** 2 * e
    g2v = (2.0 / GATE_A ** 2) * (1.0 - 2.0 * (t / GATE_A) ** 2) * e
    g0 = g0v[:, None, None]
    g1 = g1v[:, None, None]
    g2 = g2v[:, None, None]

    A0, A2 = _gA(x, IC_X0), _gA2(x, IC_X0)
    B0, B2 = _gA(y, IC_Y0), _gA2(y, IC_Y0)

    # ONE contraction for the whole residual.  u_tt = g2 N + 2 g1 Nt + g0 Ntt
    # with N, Nt, Ntt sharing P00, and g depending only on t, so the three
    # t-factor matrices combine BEFORE the GEMM; 1/c depends only on (x,y),
    # so it folds into P00.  b06 spent one [NT,NX,NY] tensor on each of
    # N, Nt, Ntt, Nlap; this materialises the residual itself and nothing else.
    P00 = _xy(fx0, fy0)                                        # [r, J*K]
    Plap = _xy(fx2, fy0) + _xy(fx0, fy2)                       # [r, J*K]
    rho = (1.0 / c).reshape(1, -1)
    Q = jnp.concatenate([P00 * rho, -Plap], axis=0)            # [2r, J*K]
    FT = jnp.concatenate([g2v[:, None] * ft0 + 2.0 * g1v[:, None] * ft1
                          + g0v[:, None] * ft2,
                          g0v[:, None] * ft0], axis=1)         # [I, 2r]
    r = (FT @ Q).reshape(I, J, K) * _RSCALE - (
        A2[:, None] * B0[None, :] + A0[:, None] * B2[None, :])[None, :, :]
    qx, qy = _qmat(x, X_MIN, X_MAX, J), _qmat(y, Y_MIN, Y_MAX, K)
    A = _smooth(r, qx, qy)                                          # [NT,M,M]
    L_slice = jnp.sum(_W2 * A ** 2, axis=(1, 2))                    # [NT]
    wt = 1.0 + AW * (1.0 - t / T_MAX)
    L_slice = L_slice * (wt / jnp.mean(wt))
    # goal-oriented estimate of ||e||^2: the residual driving the medium's own
    # modes through the causal Duhamel convolution, then measured in plain L2.
    S = A.reshape(I, -1) @ _VKJ                                     # [I, N_EIG]
    aq = jnp.fft.irfft(jnp.fft.rfft(S, n=_NFFT, axis=0) * _HKF,
                       n=_NFFT, axis=0)[:I]                         # [I, N_EIG]
    L_dh = jnp.mean(jnp.sum(_DGJ[None, :] * aq ** 2, axis=1))

    # E(t) = <u_t^2/c + |grad u|^2> is EXACTLY conserved here (multiply the
    # PDE by u_t/c and integrate by parts; the Neumann faces kill the flux),
    # and u_t(0)=0 fixes its value analytically at E0 = <|grad u0|^2>.
    # Both anchors are quadratic/linear in a SEPARABLE field, so every integral
    # collapses to per-axis Gram matrices; only the 1/c-weighted one needs a
    # [r,r] moment of the medium.  No [NT,NX,NY] tensor is ever formed.
    A1, B1 = _gA1(x, IC_X0), _gA1(y, IC_Y0)
    rho = 1.0 / c
    ft00 = g0[:, :, 0] * ft0                                # [I, r]
    at = g1[:, :, 0] * ft0 + g0[:, :, 0] * ft1              # u_t coefficients
    Gx0, Gx1 = fx0.T @ fx0 / J, fx1.T @ fx1 / J
    Gy0, Gy1 = fy0.T @ fy0 / K, fy1.T @ fy1 / K
    KX = (fx0[:, :, None] * fx0[:, None, :]).reshape(J, -1)
    KY = (fy0[:, :, None] * fy0[:, None, :]).reshape(K, -1)
    H = jnp.sum((rho.T @ KX) * KY, axis=0).reshape(RANK, RANK) / (J * K)
    q = lambda a, G: jnp.sum((a @ G) * a, axis=1)
    vx = (fx1.T @ A1 / J) * (fy0.T @ B0 / K)
    vy = (fx0.T @ A0 / J) * (fy1.T @ B1 / K)
    cx = jnp.mean(A1 ** 2) * jnp.mean(B0 ** 2)
    cy = jnp.mean(A0 ** 2) * jnp.mean(B1 ** 2)
    E_slice = (_RSCALE ** 2 * (q(at, H) + q(ft00, Gx1 * Gy0) + q(ft00, Gx0 * Gy1))
               + 2.0 * _RSCALE * (ft00 @ (vx + vy)) + cx + cy)
    E0 = cx + cy
    # LINEAR invariant: integrating u_tt/c = lap(u) over the box kills the flux
    # by Neumann, so d2/dt2 <u/c> = 0, and u_t(0)=0 makes <u/c> exactly constant.
    # Unlike the quadratic energy, a uniformly shrunk field cannot satisfy it.
    mr = jnp.sum((fx0.T @ rho) * fy0.T, axis=1) / (J * K)
    M0 = jnp.mean((A0[:, None] * B0[None, :]) / c)
    M_slice = M0 + _RSCALE * (ft00 @ mr)
    L_ma = jnp.mean((M_slice / M0 - 1.0) ** 2)
    L_en = jnp.mean((E_slice / E0 - 1.0) ** 2)

    # Neumann faces: u_x at x = +-1 (all t, all y) and u_y at y = +-1
    xb = jnp.array([X_MIN, X_MAX], dtype=jnp.float32)
    _, bx1 = _feat01(params["x"], xb, X_MIN, X_MAX, _KS, _SCS)
    _, by1 = _feat01(params["y"], xb, Y_MIN, Y_MAX, _KS, _SCS)

    Nx_b = (ft0 @ _xy(bx1, fy0)).reshape(I, 2, K) * _RSCALE
    Ny_b = (ft0 @ _xy(fx0, by1)).reshape(I, J, 2) * _RSCALE
    ux_b = (_gA1(xb, IC_X0)[:, None] * B0[None, :])[None, :, :] + g0 * Nx_b
    uy_b = (A0[:, None] * _gA1(xb, IC_Y0)[None, :])[None, :, :] + g0 * Ny_b
    L_bc = jnp.mean(ux_b ** 2) + jnp.mean(uy_b ** 2)
    return L_slice, L_bc, L_en, L_ma, L_dh


def _loss(params, t, x, y, c):
    L_slice, L_bc, L_en, L_ma, L_dh = _terms(params, t, x, y, c)
    L_res = jnp.mean(L_slice)
    # magnitude normalisation (kb1 021): parameter-free residual/BC balance
    MI = jax.lax.stop_gradient(L_res)
    L_bc = LAM_BC * L_bc
    MB = jax.lax.stop_gradient(L_bc)
    loss = (MB * L_res + MI * L_bc) / (MI + MB + 1e-30)
    # energy anchor at a FIXED relative pull, deliberately outside the kb1 021
    # pairing: that pairing equalises the pull of every term it contains, which
    # is why b01's energy penalty outvoted the residual and won with u = u0.
    loss = loss + jax.lax.stop_gradient(loss) * (LAM_E * L_en + LAM_M * L_ma)
    # relative pull, like the anchors: the value is fixed at LAM_D * loss, only
    # the DIRECTION of the goal-oriented gradient is added, so no constraint of
    # the standing norm is weakened and no scale has to be tuned.
    loss = loss + jax.lax.stop_gradient(loss) * LAM_D * (
        L_dh / (jax.lax.stop_gradient(L_dh) + 1e-30))
    return loss


# ══════════ Public contract ══════════

def predict_fn(params, X):
    """X: [BS, 3] with columns (t, x, y). Returns {"u": [BS]}."""
    out = []
    CH = 1 << 16
    n = X.shape[0]
    for s in range(0, n, CH):
        Xi = jnp.asarray(X[s:s + CH])
        t, x, y = Xi[:, 0], Xi[:, 1], Xi[:, 2]
        ft = _feat0(params["t"], t, T_MIN, T_MAX, _KT, _SCT)
        fx = _feat0(params["x"], x, X_MIN, X_MAX, _KS, _SCS)
        fy = _feat0(params["y"], y, Y_MIN, Y_MAX, _KS, _SCS)
        N = jnp.sum(ft * fx * fy, axis=-1) * _RSCALE
        u = _gA(x, IC_X0) * _gA(y, IC_Y0) + (1.0 - jnp.exp(-((t / GATE_A) ** 2))) * N
        out.append(u)
    return {"u": jnp.concatenate(out)}


def train(rng, eval_callback: Callable[[Any, int, float], None] | None = None):
    """Wall-deadline Adam on the separable hard-IC ansatz.

    Returns (params, step_count) — ``params`` is a dict of three Flax pytrees.
    """
    C_np, n_grid = _coef_grid()
    C = jnp.asarray(C_np)

    k0, k1, k2, rng_local = random.split(rng, 4)
    params = {
        "t": _BRANCH.init(k0, jnp.zeros((1 + 2 * NFREQ_T,))),
        "x": _BRANCH.init(k1, jnp.zeros((1 + 2 * NFREQ_S,))),
        "y": _BRANCH.init(k2, jnp.zeros((1 + 2 * NFREQ_S,))),
    }

    def sample(key):
        ka, kb, kc = random.split(key, 3)
        # t must stay uniform (the Gaussian _ST matrix is only valid there),
        # but b06's mode-space spatial smoother builds its quadrature from the
        # ACTUAL x, y values, so x and y may be sampled per point.  b03 had to
        # give up per-point jitter to make the spatial averaging matrices valid
        # and paid for it; nothing has needed it since.  Stratified: one draw
        # per cell, so the estimator stays unbiased and the medium is resolved
        # in expectation instead of on a fixed 96-point lattice.
        it = (jnp.arange(NT) + random.uniform(ka, ())) / NT        # uniform spacing
        ix = (jnp.arange(NX) + random.uniform(kb, (NX,))) / NX
        iy = (jnp.arange(NY) + random.uniform(kc, (NY,))) / NY
        t = T_MIN + (T_MAX - T_MIN) * it
        x = X_MIN + (X_MAX - X_MIN) * ix
        y = Y_MIN + (Y_MAX - Y_MIN) * iy
        c = coef_at(C, n_grid, x[:, None], y[None, :])
        return t, x, y, c

    opt = optax.scale_by_adam()
    opt_state = opt.init(params)

    @jit
    def update(params, opt_state, ema, key, lr, beta):
        t, x, y, c = sample(key)
        loss, grads = jax.value_and_grad(_loss)(params, t, x, y, c)
        updates, opt_state = opt.update(grads, opt_state, params)
        params = jax.tree_util.tree_map(lambda p, u: p - lr * u, params, updates)
        ema = jax.tree_util.tree_map(lambda e, p: beta * e + (1.0 - beta) * p,
                                     ema, params)
        return params, opt_state, ema, loss

    deadline = _T0 + TRAIN_TIME - SAVE_MARGIN_S
    span = max(deadline - _T0, 1e-6)

    # Warmup step: JIT-compiles the whole training step; it is a real step.
    ema = params
    rng_local, ks = random.split(rng_local)
    params, opt_state, ema, loss = update(params, opt_state, ema, ks,
                                          jnp.float32(LR0), jnp.float32(0.0))
    step_count = 1
    last_loss = float(loss)

    for it in range(1, MAX_ITER):
        now = time.time()
        if now > deadline:
            break
        frac = min(max((now - _T0) / span, 0.0), 1.0)
        lr = jnp.float32(LR0 * (LR1 / LR0) ** frac)
        beta = jnp.float32(EMA_BETA if frac > 1.0 - EMA_FRAC else 0.0)
        for _ in range(SYNC_EVERY):
            rng_local, ks = random.split(rng_local)
            params, opt_state, ema, loss = update(params, opt_state, ema, ks,
                                                  lr, beta)
        step_count += SYNC_EVERY
        last_loss = float(loss)
        if eval_callback is not None and (step_count % 1000 < SYNC_EVERY):
            eval_callback(params, step_count, last_loss)

    return ema, step_count
