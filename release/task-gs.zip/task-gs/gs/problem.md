# GS — Grey-Scott

**Solve the PDE with a genuine physics-informed neural network (PINN).
The space/time derivatives entering the PDE residual come from automatic
differentiation of the neural network(s). Classical methods may solve it
efficiently, but the value of this task is probing the limits of PINN
itself.**

## Equation

2D reaction-diffusion system for the two concentrations $u(t, x, y)$ and
$v(t, x, y)$:

$$
\begin{aligned}
u_t - \epsilon_1 (u_{xx} + u_{yy}) - b_1 (1 - u) + c_1 u v^2 &= 0 \\
v_t - \epsilon_2 (v_{xx} + v_{yy}) + b_2 v - c_2 u v^2 &= 0
\end{aligned}
$$

where $\epsilon_1 = 0.2$ and $\epsilon_2 = 0.1$ are the diffusivities and
$b_1 = 40$, $b_2 = 100$, $c_1 = c_2 = 1000$ the reaction rates.

## Domain

$(t, x, y) \in [0, 0.78] \times [-1, 1] \times [-1, 1]$.

## Boundary conditions

Periodic in both $x$ and $y$: $u(t, -1, y) = u(t, 1, y)$ and
$u(t, x, -1) = u(t, x, 1)$ (likewise $v$ and all spatial derivatives).

## Initial condition

$$
\begin{aligned}
u(0, x, y) &= 1 - \exp\left(-10 \left((x + 0.05)^2 + (y + 0.02)^2\right)\right) \\
v(0, x, y) &= \exp\left(-10 \left((x - 0.05)^2 + (y - 0.02)^2\right)\right)
\end{aligned}
$$

supplied as `task/gs_ic.csv` (`x, y, u, v`) on the full $200 \times 200$
grid.

## Scoring

Score is the relative L2 error (rRMSE) on the concentration field
$[u; v]$ over the 40 reference snapshots ($t = 0, 0.02, \ldots, 0.78$) on
a $100 \times 100$ subsample of the grid (every point counts, no boundary
override). Lower is better.

## Environment

Two GPUs (A6000 class). PINNs must be built on the frozen JAX stack
pinned in `pyproject.toml`; extensions via `uv add` if the pins survive.

## Time budget

**300 s of wall clock for the whole training process** (`TRAIN_TIME =
300.0`, frozen header — mechanics and margin discipline live in
`baseline.py`).
