# WAVEMS — 2D wave in a multiscale medium

**Solve the PDE with a genuine physics-informed neural network (PINN).
The space/time derivatives entering the PDE residual come from automatic
differentiation of the neural network(s). Classical methods may solve it
efficiently, but the value of this task is probing the limits of PINN
itself.**

## Equation

2D wave equation with a spatially varying wave speed, for $u(t, x, y)$:

$$
u_{tt} - c(x, y) \left( u_{xx} + u_{yy} \right) = 0
$$

where the medium $c(x, y)$ takes the two values $1$ and $12$ (wave speed
$\sqrt{c}$, contrast $3.46$), supplied as `task/wavems_coef.csv`
(`x, y, c`) on a $256 \times 256$ grid over the domain and evaluated
between grid points by bilinear interpolation.

## Domain

$(t, x, y) \in [0, 5] \times [-1, 1] \times [-1, 1]$.

## Boundary conditions

Zero Neumann on all four sides: $u_x(t, \pm 1, y) = 0$ and
$u_y(t, x, \pm 1) = 0$.

## Initial condition

$$
u(0, x, y) = \exp\!\left(-\frac{(x + 0.5)^2 + y^2}{2 \cdot 0.3^2}\right),
\qquad u_t(0, x, y) = 0
$$

## Scoring

Score is the relative L2 error (rRMSE) on the field $u$ over the 51
reference snapshots ($t = 0, 0.1, \ldots, 5$) on a $129 \times 129$ grid
(every point counts, no boundary override). Lower is better.

## Environment

Two GPUs (A6000 class). PINNs must be built on the frozen JAX stack
pinned in `pyproject.toml`; extensions via `uv add` if the pins survive.

## Time budget

**100 s of wall clock for the whole training process** (`TRAIN_TIME =
100.0`, frozen header — mechanics and margin discipline live in
`baseline.py`).
