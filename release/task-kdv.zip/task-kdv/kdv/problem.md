# KDV — Korteweg-de Vries

**Solve the PDE with a genuine physics-informed neural network (PINN).
The space/time derivatives entering the PDE residual come from automatic
differentiation of the neural network(s). Classical methods may solve it
efficiently, but the value of this task is probing the limits of PINN
itself.**

## Equation

1D Korteweg-de Vries equation for $u(t, x)$:

$$
u_t + u u_x + \delta^2 u_{xxx} = 0
$$

where $\delta = 0.022$ sets the dispersion.

## Domain

$(t, x) \in [0, 1] \times [-1, 1]$.

## Boundary conditions

Periodic in $x$: $u(t, -1) = u(t, 1)$ (likewise all spatial
derivatives).

## Initial condition

$$
u(0, x) = \cos(\pi x)
$$

supplied as `task/kdv_ic.csv` (`x, u`) on the full 512-point grid.

## Scoring

Score is the relative L2 error (rRMSE) on the field $u$ over the 201
reference snapshots ($t = 0, 0.005, \ldots, 1$) on the 511 distinct grid
points (every point counts, no boundary override). Lower is better.

## Environment

Two GPUs (A6000 class). PINNs must be built on the frozen JAX stack
pinned in `pyproject.toml`; extensions via `uv add` if the pins survive.

## Time budget

**100 s of wall clock for the whole training process** (`TRAIN_TIME =
100.0`, frozen header — mechanics and margin discipline live in
`baseline.py`).
