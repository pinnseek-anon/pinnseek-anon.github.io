# Wing3D task package

The task package of Wing3D (Flow over a 3D wing) used in the discovery runs, with its reference solution. The
problem is defined in Supplementary Note 1 of the paper.

| File | Content |
|---|---|
| `problem.md` | problem statement given to the agent |
| `baseline.py` | standard PINN solver from which each discovery run starts |
| `eval.py` | evaluation tool that trains a solver and reports its relative L2 error |
| `ref_data.npy` | reference solution |
| `collocation.npy`, `wing_surface.npy` | input data of the problem |

## Running a solver

On Linux with Python 3.11 and the packages pinned in `pyproject.toml` of the framework:

```bash
mkdir -p project/blocks/b01
cp -r task-wing3d/wing3d project/task
cp discovered-solvers/wing3d.py project/blocks/b01/
cd project && python task/eval.py blocks/b01/wing3d.py --gpu 0 --seed 1
```

The last line printed is the evaluation record, with the relative L2 error as `rRMSE`.
