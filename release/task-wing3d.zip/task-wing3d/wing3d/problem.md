# WING3D — flow over a finite 3D wing

**Solve the PDE with a genuine physics-informed neural network (PINN).
The space/time derivatives entering the PDE residual come from automatic
differentiation of the neural network(s). Classical methods may solve it
efficiently, but the value of this task is probing the limits of PINN
itself.**

## Equation

3D steady incompressible Navier-Stokes for $u(x,y,z)$, $v(x,y,z)$,
$w(x,y,z)$, $p(x,y,z)$:

$$
\begin{aligned}
u\,u_x + v\,u_y + w\,u_z + p_x - \nu\,(u_{xx}+u_{yy}+u_{zz}) &= 0 \\
u\,v_x + v\,v_y + w\,v_z + p_y - \nu\,(v_{xx}+v_{yy}+v_{zz}) &= 0 \\
u\,w_x + v\,w_y + w\,w_z + p_z - \nu\,(w_{xx}+w_{yy}+w_{zz}) &= 0 \\
u_x + v_y + w_z &= 0
\end{aligned}
$$

where $u, v, w$ are the velocity components and $p$ the pressure (all
dimensionless), with $\nu = 1/\text{Re}$, $\text{Re} = 1000$
($\nu = 1.0\times10^{-3}$).

## Domain

Farfield box $(x,y,z) \in [-1.5, 3.5] \times [-2,2] \times [0,3.5]$ with a
half model of a swept, tapered finite wing (9.7% thickness, root chord $1$
with leading edge at $x=0$, tip chord $0.56252$, leading-edge sweep
$29.999^\circ$, rounded tip reaching $z=1.50323$) at 7° angle of attack.
Lengths are in root chords; $x$ is chordwise, $y$ is the lift direction,
$z$ is spanwise, and only $z \ge 0$ is modelled — the root section sits on
the symmetry plane $z=0$. The fluid region is the box minus the wing,
given by the signed-distance level set `phi` in `task/collocation.npy`
(`x, y, z, phi`; `phi <= 0` = fluid, `phi > 0` = wing interior).

## Boundary conditions

| Boundary | condition |
|---|---|
| Wing surface (no-slip) | $u = v = w = 0$ |
| Inlet $x=-1.5$ and lateral farfield $y=\pm2$, $z=3.5$ | $u = 1,\; v = 0,\; w = 0$ |
| Outlet $x=3.5$ | $p = 0$ |
| Symmetry plane $z=0$ | $w = 0,\quad \partial u/\partial z = \partial v/\partial z = 0$ |

Geometry sources: the wing no-slip points are `task/wing_surface.npy`
(`x, y, z`); the fluid mask is the `phi` column of `task/collocation.npy`.
The outer-box faces are analytic.

## Initial condition

None (steady-state problem; no time variable).

## Scoring

Score is the relative L2 error (rRMSE) on the velocity magnitude
$V = \sqrt{u^2+v^2+w^2}$, over the fluid points (`phi <= 0`) in the
near-wing window $x \in [-0.2, 2.2]$, $y \in [-0.35, 0.35]$,
$z \in [0, 1.8]$. Lower is better.

Reference accuracy: the reference is a finite-volume solve, so a perfect
solution of the stated PDE would not score zero. An independent solve of a
wake sub-box has its own error of 0.0041 and agrees with the reference to
**0.0071** in the metric above. Treat $\approx 0.007$ as the error floor:
a score below about $0.01$ is fitting discretisation error rather than the
physics.

## Environment

Two GPUs (A6000 class). PINNs must be built on the frozen JAX stack
pinned in `pyproject.toml`; extensions via `uv add` if the pins survive.

## Time budget

**480 s of wall clock for the whole training process** (`TRAIN_TIME =
480.0`, frozen header — mechanics and margin discipline live in
`baseline.py`).
