# Drivers of the four SOTA methods

Code that trains Scale-PINN, APTS, SPINN and DSGNAR on the 18 problems for Table 1 and
Supplementary Table 1. Each `<problem>/<method>/` folder holds `run.py`, which sets the problem and
the training time, and the code of the method that it imports. The repositories of the methods are
cited in the paper.
