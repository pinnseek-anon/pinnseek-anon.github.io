import time
import os

import jax
import jax.numpy as jnp

import wandb

from jaxpi.models import create_lr_schedule, create_optimizer, create_arch, create_train_state
from jaxpi.samplers import UniformSampler
from jaxpi.checkpointing import create_checkpoint_manager
from jaxpi.logging import Logger
from jaxpi.checkpointing import save_checkpoint
from jaxpi.utils import create_update_scheduler

import models
from utils import get_dataset


def train_and_evaluate(config):
    # [sota patch] the donor builds an analytic 1D travelling wave from five
    # scalars; this task is 2D with coefficient fields read from disk, so the
    # dataset comes from utils.get_dataset and the domain box gains a third
    # axis. All three coordinates are normalised to [0, 1] by the task.
    d = get_dataset()
    u_ref, t_star, x_star, y_star = d["u_ref"], d["t_star"], d["x_star"], d["y_star"]

    dom = jnp.array([[0.0, 1.0], [0.0, 1.0], [0.0, 1.0]])

    # Initialize  residual sampler
    res_sampler = iter(UniformSampler(dom, batch_size=config.training.batch_size))

    # Initialize model
    lr = create_lr_schedule(config.optim)
    tx = create_optimizer(config.optim, lr)
    arch = create_arch(config.arch)
    state = create_train_state(config, tx, arch)
    model = models.Smoke2D(config, lr, tx, arch, state, d)   # [sota patch] 2D

    # Initialize evaluator
    evaluator = models.Advection1DEvaluator(config)

    # Weights update scheduler
    loss_update = create_update_scheduler(**config.loss_weighting.update_schedule)
    pseudo_time_update = create_update_scheduler(**config.pseudo_time.update_schedule)

    # Initialize logger
    logger = Logger()

    # Create checkpoint manager
    ckpt_path = os.path.join(os.getcwd(), config.wandb.name, "ckpt")
    ckpt_mngr = create_checkpoint_manager(config.saving, ckpt_path)

    # Initialize W&B
    wandb_config = config.wandb
    wandb.init(project=wandb_config.project, name=wandb_config.name)

    # jit warm up
    start_time = time.time()  # Initialize before the loop
    print("Waiting for JIT...")
    init_state = model.state
    for step in range(config.training.max_steps):

        batch = next(res_sampler)
        model.state, loss, loss_dict = model.step(model.state, batch)

        if config.pseudo_time.strategy == "dynamic":
            if pseudo_time_update(step):
                model.state = model.update_pts_weights(model.state, init_state, batch)

        # Update weights if necessary
        if config.loss_weighting.strategy == "dynamic":
            if loss_update(step):
                model.state = model.update_loss_weights(model.state, batch)

        # Log training metrics, only use host 0 to record results
        if jax.process_index() == 0:
            if step % config.logging.log_every_steps == 0:
                end_time = time.time()
                # Compute evaluation metrics and log to W&B
                log_dict = evaluator(model, model.state, loss_dict, batch, u_ref)
                wandb.log(log_dict, step)

                # Report training metrics
                logger.log_iter(step, start_time, end_time, log_dict)
                start_time = time.time()

        # Save checkpoint
        if config.saving.save_every_steps > 0:
            if (step + 1) % config.saving.save_every_steps == 0 or (
                    step + 1
            ) == config.training.max_steps:
                save_checkpoint(ckpt_mngr, model.state)

    # Save final checkpoint
    print("Training finished, saving final checkpoint...")
    if config.saving.save_every_steps > 0:
        save_checkpoint(ckpt_mngr, model.state)
        ckpt_mngr.wait_until_finished()
