# Generalization cases of LDC

The 5 new cases of LDC in Fig. 2 of the paper, one folder per case.

| File | Content |
|---|---|
| `problem.md` | problem statement of the case |
| `meta.json` | notes on the case and its reference solution |
| `ref_data.csv` | reference solution |
| `scorer.py` | `score(predict_fn, params)` returns the relative L2 error of a trained solver |
| `solver_retrained.py` | discovered solver of LDC with the problem definition changed to the case ("Retrained from scratch" in Fig. 2) |
| `solver_retrained.diff` | that change |

Cases: ldc_Re1000, ldc_Re1600, ldc_Re400, ldc_Re5000, ldc_Re7500.
