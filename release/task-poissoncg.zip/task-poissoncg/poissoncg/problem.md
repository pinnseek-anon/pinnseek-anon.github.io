# POISSONCG — 3D Poisson in a complex geometry

**Solve the PDE with a genuine physics-informed neural network (PINN).
The space/time derivatives entering the PDE residual come from automatic
differentiation of the neural network(s). Classical methods may solve it
efficiently, but the value of this task is probing the limits of PINN
itself.**

## Equation

3D screened Poisson equation for $u(x, y, z)$:

$$
-(u_{xx} + u_{yy} + u_{zz}) + k(z)^2 \, u - f(x, y, z) = 0
$$

where the screening wavenumber is piecewise constant across $z = 0.5$,

$$
k(z) = \begin{cases} 8 & z < 0.5 \\ 10 & z \ge 0.5 \end{cases}
$$

and the source is

$$
f(x, y, z) =
20 \, e^{\sin(\pi x) + \sin(10 \pi y) + \sin(5 \pi z)}
\frac{x^2 + y^2 + z^2 - 1}{x^2 + y^2 + z^2 + 1}
+ 100 \, \sin(\pi x) \sin(10 \pi y) \sin(5 \pi z).
$$

## Domain

Unit cube $(x, y, z) \in [0, 1]^3$ with two spheres of radius $0.2$
centred at $(0.4, 0.3, 0.6)$ and $(0.6, 0.7, 0.6)$ removed. The geometry
is analytic: the domain is every point of the cube lying outside both
spheres, and no level set is shipped.

## Boundary conditions

Homogeneous Neumann $\partial u / \partial n = 0$ on every boundary — the
six cube faces and both sphere surfaces.

Every boundary is analytic — no boundary data file is shipped.

## Initial condition

None (steady-state problem; no time variable).

## Scoring

Score is the relative L2 error (rRMSE) on the field $u$ over the 65,202
reference points (every point counts, no boundary override). Lower is
better.

## Environment

Two GPUs (A6000 class). PINNs must be built on the frozen JAX stack
pinned in `pyproject.toml`; extensions via `uv add` if the pins survive.

## Time budget

**60 s of wall clock for the whole training process** (`TRAIN_TIME =
60.0`, frozen header — mechanics and margin discipline live in
`baseline.py`).
