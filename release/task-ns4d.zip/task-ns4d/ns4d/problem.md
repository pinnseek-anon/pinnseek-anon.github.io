# NS4D — 3D unsteady Navier-Stokes

**Solve the PDE with a genuine physics-informed neural network (PINN).
The space/time derivatives entering the PDE residual come from automatic
differentiation of the neural network(s). Classical methods may solve it
efficiently, but the value of this task is probing the limits of PINN
itself.**

## Equation

Incompressible Navier-Stokes in vorticity-velocity form for the velocity
$\mathbf{u}(t, x, y, z)$, with $\mathbf{w} = \nabla \times \mathbf{u}$:

$$
\begin{aligned}
\mathbf{w}_t + (\mathbf{u} \cdot \nabla)\mathbf{w}
- (\mathbf{w} \cdot \nabla)\mathbf{u}
- \nu \nabla^2 \mathbf{w} - \mathbf{f} &= 0 \\
\nabla \cdot \mathbf{u} &= 0
\end{aligned}
$$

where $\nu = 0.05$ and the forcing is
$f_x = -6 e^{-18\nu t} \sin(4y)\sin(2z)$,
$f_y = -6 e^{-18\nu t} \sin(4x)\sin(2z)$,
$f_z = 6 e^{-18\nu t} \sin(4x)\sin(4y)$.
The vorticity is not a network output: it is $\nabla \times \mathbf{u}$,
so $\nabla^2 \mathbf{w}$ is a third derivative of the velocity.

## Domain

$(t, x, y, z) \in [0, 5] \times [0, 2\pi] \times [0, 2\pi] \times [0, 2\pi]$.

## Boundary conditions

Periodic in $x$, $y$ and $z$ with period $2\pi$:
$\mathbf{u}(t, 0, y, z) = \mathbf{u}(t, 2\pi, y, z)$ and likewise in $y$
and $z$ (and all spatial derivatives).

## Initial condition

$\mathbf{u}(0, x, y, z)$ and $\mathbf{w}(0, x, y, z)$ are the exact fields
at $t = 0$, supplied as `task/ns4d_ic.csv`
(`x, y, z, u, v, w, wx, wy, wz`) on a $32^3$ grid.

## Scoring

Score is the relative L2 error (rRMSE) on the vorticity field, averaged
over its three components $w_x, w_y, w_z$, on the $20^4$ grid
($t = 0, \ldots, 5$ and each of $x, y, z$ over $[0, 2\pi]$, 160,000
points; every point counts, no boundary override). Lower is better.

## Environment

Two GPUs (A6000 class). PINNs must be built on the frozen JAX stack
pinned in `pyproject.toml`; extensions via `uv add` if the pins survive.

## Time budget

**300 s of wall clock for the whole training process** (`TRAIN_TIME =
300.0`, frozen header — mechanics and margin discipline live in
`baseline.py`).
