# Source data of the figures

The data plotted in the figures of the paper, as JSON. Each folder holds the data of one figure:
`figN` of Fig. N, `edfigN` of Extended Data Fig. N and `sfig1` of Supplementary Figs. 1-18.
