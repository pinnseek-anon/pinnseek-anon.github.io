# GL — Ginzburg-Landau

**Solve the PDE with a genuine physics-informed neural network (PINN).
The space/time derivatives entering the PDE residual come from automatic
differentiation of the neural network(s). Classical methods may solve it
efficiently, but the value of this task is probing the limits of PINN
itself.**

## Equation

2D complex Ginzburg-Landau equation for the amplitude $A = u + i v$, in
its real components $u(t, x, y)$ and $v(t, x, y)$:

$$
\begin{aligned}
u_t - \epsilon (u_{xx} + u_{yy}) - k \left( u - u (u^2 + v^2) + c\, v (u^2 + v^2) \right) &= 0 \\
v_t - \epsilon (v_{xx} + v_{yy}) - k \left( v - v (u^2 + v^2) - c\, u (u^2 + v^2) \right) &= 0
\end{aligned}
$$

where $\epsilon = 0.004$ is the diffusivity, $k = 10$ the reaction rate and
$c = 1.5$ the nonlinear phase coefficient, i.e. $A_t = \epsilon \nabla^2 A
+ k (A - (1 + i c) |A|^2 A)$.

## Domain

$(t, x, y) \in [0, 0.79] \times [-1, 1] \times [-1, 1]$.

## Boundary conditions

Periodic in both $x$ and $y$: $u(t, -1, y) = u(t, 1, y)$ and
$u(t, x, -1) = u(t, x, 1)$ (likewise $v$ and all spatial derivatives).

## Initial condition

$$
\begin{aligned}
u(0, x, y) &= 10\, x \exp\left(-25 \left(x^2 + y^2\right)\right) \\
v(0, x, y) &= 10\, y \exp\left(-25 \left(x^2 + y^2\right)\right)
\end{aligned}
$$

supplied as `task/gl_ic.csv` (`x, y, u, v`) on the full $200 \times 200$
grid.

## Scoring

Score is the relative L2 error (rRMSE) on the amplitude field
$[u; v]$ over the 80 reference snapshots ($t = 0, 0.01, \ldots, 0.79$) on
a $100 \times 100$ subsample of the grid (every point counts, no boundary
override). Lower is better.

## Environment

Two GPUs (A6000 class). PINNs must be built on the frozen JAX stack
pinned in `pyproject.toml`; extensions via `uv add` if the pins survive.

## Time budget

**300 s of wall clock for the whole training process** (`TRAIN_TIME =
300.0`, frozen header — mechanics and margin discipline live in
`baseline.py`).
