# PINNSeek plugin

Skills and hooks that teach a coding agent the `pinnseek` command-line workflow for authoring and
running tasks.

| Path | Content |
|---|---|
| `skills/` | four skills |
| `hooks/` | session-start hook |
| `cursor/`, `opencode/`, `AGENTS.md` | the same workflow for Cursor, OpenCode and other agents |

Do not copy `AGENTS.md` or any other instruction file to the root of a PINNSeek checkout, since
every discovery round would read it.
