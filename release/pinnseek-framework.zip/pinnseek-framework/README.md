# PINNSeek

Source code of the PINNSeek framework described in the Methods.

| Path | Content |
|---|---|
| `pinnseek/` | orchestrator and command-line tool |
| `pinnseek/kb1/` | literature base |
| `pinnseek/prompts/` | charter of a discovery round and the prompts for distilling notes and authoring tasks |
| `plugin/` | skills and hooks for coding agents |
| `tasks/` | four example tasks, without their reference solutions |
| `tests/` | tests |

```bash
uv sync
uv run pinnseek task list
uv run pinnseek run start -t ks -n 5
uv run pytest tests/ -q
```
