"""Built-in runtime adapters."""
