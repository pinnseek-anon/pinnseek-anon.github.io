# Generalization cases of KS

The 10 new cases of KS in Fig. 2 of the paper, one folder per case.

| File | Content |
|---|---|
| `problem.md` | problem statement of the case |
| `meta.json` | notes on the case and its reference solution |
| `ref_data.csv` | reference solution |
| `ks_ic.csv` | input data of the case |
| `scorer.py` | `score(predict_fn, params)` returns the relative L2 error of a trained solver |
| `solver_retrained.py` | discovered solver of KS with the problem definition changed to the case ("Retrained from scratch" in Fig. 2) |
| `solver_retrained.diff` | that change |

Cases: ks_L12, ks_L20, ks_ic1, ks_ic2, ks_ic3, ks_ic4, ks_ic5, ks_ic6, ks_ic7, ks_ic8.
