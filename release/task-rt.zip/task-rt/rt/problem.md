# RT — Rayleigh-Taylor instability

**Solve the PDE with a genuine physics-informed neural network (PINN).
The space/time derivatives entering the PDE residual come from automatic
differentiation of the neural network(s). Classical methods may solve it
efficiently, but the value of this task is probing the limits of PINN
itself.**

## Equation

2D buoyancy-driven Boussinesq flow for the velocity $u(t, x, y)$,
$v(t, x, y)$, the pressure $p(t, x, y)$ and the temperature
$T(t, x, y)$:

$$
\begin{aligned}
u_t + u \, u_x + v \, u_y + p_x - \sqrt{\tfrac{Pr}{Ra}} (u_{xx} + u_{yy}) &= 0 \\
v_t + u \, v_x + v \, v_y + p_y - \sqrt{\tfrac{Pr}{Ra}} (v_{xx} + v_{yy}) - T &= 0 \\
u_x + v_y &= 0 \\
T_t + u \, T_x + v \, T_y - \tfrac{1}{\sqrt{Pr\,Ra}} (T_{xx} + T_{yy}) &= 0
\end{aligned}
$$

where $T$ is the density proxy under the Boussinesq approximation, with
$Pr = 0.71$ and $Ra = 10^6$, so the viscous coefficient is
$\sqrt{Pr/Ra} = 8.426150 \times 10^{-4}$ and the thermal one is
$1/\sqrt{Pr\,Ra} = 1.186782 \times 10^{-3}$.

## Domain

$(t, x, y) \in [0, 4.75] \times [0, 1] \times [0, 2]$.

## Boundary conditions

Periodic in $x$ with period $1$: $u(t, 0, y) = u(t, 1, y)$ (likewise $v$,
$p$, $T$ and all $x$-derivatives). Dirichlet $u = v = T = 0$ on the
bottom and top walls ($y = 0$ and $y = 2$).

## Initial condition

$u(0, x, y)$, $v(0, x, y)$ and $T(0, x, y)$ are the reference fields at
$t = 0$, supplied as `task/rt_ic.csv` (`x, y, u, v, T`) on the full
$100 \times 200$ grid.

## Scoring

Score is the relative L2 error (rRMSE) on the temperature field $T$ over
the 20 reference snapshots ($t = 0, 0.25, \ldots, 4.75$) on the full
$100 \times 200$ grid (every point counts, no boundary override). Lower
is better.

## Environment

Two GPUs (A6000 class). PINNs must be built on the frozen JAX stack
pinned in `pyproject.toml`; extensions via `uv add` if the pins survive.

## Time budget

**480 s of wall clock for the whole training process** (`TRAIN_TIME =
480.0`, frozen header — mechanics and margin discipline live in
`baseline.py`).
