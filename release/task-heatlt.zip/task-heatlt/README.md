# Heat-LT task package

The task package of Heat-LT (Long-time heat equation) used in the discovery runs, with its reference solution. The
problem is defined in Supplementary Note 1 of the paper.

| File | Content |
|---|---|
| `problem.md` | problem statement given to the agent |
| `baseline.py` | standard PINN solver from which each discovery run starts |
| `eval.py` | evaluation tool that trains a solver and reports its relative L2 error |
| `ref_data.csv` | reference solution |
| `heat_ic.csv` | input data of the problem |

## Running a solver

On Linux with Python 3.11 and the packages pinned in `pyproject.toml` of the framework:

```bash
mkdir -p project/blocks/b01
cp -r task-heatlt/heatlt project/task
cp discovered-solvers/heatlt.py project/blocks/b01/
cd project && python task/eval.py blocks/b01/heatlt.py --gpu 0 --seed 1
```

The last line printed is the evaluation record, with the relative L2 error as `rRMSE`.
