# HEATLT — Heat 2D long time

**Solve the PDE with a genuine physics-informed neural network (PINN).
The space/time derivatives entering the PDE residual come from automatic
differentiation of the neural network(s). Classical methods may solve it
efficiently, but the value of this task is probing the limits of PINN
itself.**

## Equation

2D heat equation with a source that is nonlinear in the solution, for
$u(t, x, y)$:

$$
u_t - D\,(u_{xx} + u_{yy})
- A \sin(u^2)\,\bigl(1 + 2 \sin(\pi t / 4)\bigr)\,
\sin(4 \pi x) \sin(2 \pi y) = 0
$$

where $D = 0.001$ is the diffusivity and $A = 5$ the source amplitude.
The source's time factor has period $8$, so the window spans $12.5$
forcing cycles.

## Domain

$(t, x, y) \in [0, 100] \times [0, 1] \times [0, 1]$.

## Boundary conditions

Dirichlet $u = 0$ on all four sides ($x = 0, 1$ and $y = 0, 1$).

## Initial condition

$$
u(0, x, y) = \sin(4 \pi x) \sin(3 \pi y)
$$

supplied as `task/heat_ic.csv` (`x, y, u`) on a $128 \times 128$ grid.

## Scoring

Score is the relative L2 error (rRMSE) on the field $u$ over the 501
reference snapshots ($t = 0, 0.2, \ldots, 100$) on the COMSOL mesh of
$16 \times 12$ nodes, $96{,}192$ points in all (every point counts, no
boundary override). Lower is better.

## Environment

Two GPUs (A6000 class). PINNs must be built on the frozen JAX stack
pinned in `pyproject.toml`; extensions via `uv add` if the pins survive.

## Time budget

**180 s of wall clock for the whole training process** (`TRAIN_TIME =
180.0`, frozen header — mechanics and margin discipline live in
`baseline.py`).
