# Generalization cases of KF

The 5 new cases of KF in Fig. 2 of the paper, one folder per case.

| File | Content |
|---|---|
| `problem.md` | problem statement of the case |
| `meta.json` | notes on the case and its reference solution |
| `ref_data.csv` | reference solution |
| `kf_ic.csv` | input data of the case |
| `scorer.py` | `score(predict_fn, params)` returns the relative L2 error of a trained solver |
| `solver_retrained.py` | discovered solver of KF with the problem definition changed to the case ("Retrained from scratch" in Fig. 2) |
| `solver_retrained.diff` | that change |

Cases: kf_Re1000_ic0, kf_Re2000_t2, kf_Re2000_t4, kf_Re2000_t6, kf_Re4000_ic0.
