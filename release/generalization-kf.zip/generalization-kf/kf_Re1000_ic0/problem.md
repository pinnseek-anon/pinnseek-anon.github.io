# KF — Kolmogorov Flow

**Solve the PDE with a genuine physics-informed neural network (PINN).
The space/time derivatives entering the PDE residual come from automatic
differentiation of the neural network(s). Classical methods may solve it
efficiently, but the value of this task is probing the limits of PINN
itself.**

## Equation

2D unsteady incompressible Navier-Stokes with Kolmogorov forcing for
$u(t, x, y)$, $v(t, x, y)$, $p(t, x, y)$:

$$
\begin{aligned}
u_t + u \, u_x + v \, u_y + p_x - \nu (u_{xx} + u_{yy}) - f(y) &= 0 \\
v_t + u \, v_x + v \, v_y + p_y - \nu (v_{xx} + v_{yy}) &= 0 \\
u_x + v_y &= 0
\end{aligned}
$$

where the body force is $f(y) = 2 \sin(4 \pi y)$, acting on the
$x$-momentum only, and $\nu = 1/\text{Re}$, $\text{Re} = 1000$
($\nu = 1 \times 10^{-3}$).

## Domain

$(t, x, y) \in [0, 0.75] \times [0, 1] \times [0, 1]$.

## Boundary conditions

Periodic in both $x$ and $y$: $u(t, 0, y) = u(t, 1, y)$ and
$u(t, x, 0) = u(t, x, 1)$ (likewise $v$, $p$, and all spatial
derivatives).

## Initial condition

$u(0, x, y)$ and $v(0, x, y)$ are the reference velocity field at
$t = 0$, supplied as `task/kf_ic.csv` (`x, y, u, v`) on the full
$256 \times 256$ grid.

## Scoring

Score is the relative L2 error (rRMSE) on the velocity field $[u; v]$
over the 16 reference snapshots ($t = 0, 0.05, \ldots, 0.75$) on a
$128 \times 128$ subsample of the grid (every point counts, no boundary
override). Lower is better.

## Environment

Two GPUs (A6000 class). PINNs must be built on the frozen JAX stack
pinned in `pyproject.toml`; extensions via `uv add` if the pins survive.

## Time budget

**300 s of wall clock for the whole training process** (`TRAIN_TIME =
300.0`, frozen header — mechanics and margin discipline live in
`baseline.py`).
