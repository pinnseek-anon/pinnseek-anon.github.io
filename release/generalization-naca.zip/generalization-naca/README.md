# Generalization cases of NACA

The 6 new cases of NACA in Fig. 2 of the paper, one folder per case.

| File | Content |
|---|---|
| `problem.md` | problem statement of the case |
| `meta.json` | notes on the case and its reference solution |
| `ref_data.csv` | reference solution |
| `collocation.csv` | input data of the case |
| `scorer.py` | `score(predict_fn, params)` returns the relative L2 error of a trained solver |
| `solver_retrained.py` | discovered solver of NACA with the problem definition changed to the case ("Retrained from scratch" in Fig. 2) |
| `solver_retrained.diff` | that change |

Cases: naca_a0_Re1000, naca_a2_Re1000, naca_a4_Re1000, naca_a6_Re1000, naca_a7_Re500, naca_two_a7_Re500.
