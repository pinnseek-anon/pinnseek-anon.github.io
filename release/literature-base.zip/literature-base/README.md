# Literature base

The 130 notes of the literature base, one per paper. The Methods describe how the papers were
selected and the notes distilled.
